#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Escape the Backrooms 原版还原工具（无第三方依赖，Python 3.8+）

作用：把「ETBNightmareMod 安装后」的游戏目录恢复到 Steam 原版状态。
原则：**只移动、不删除**。所有被移走的东西都会进入带时间戳的备份文件夹，随时可用 --undo 还原。

    完全原版模式（默认）：移走 dwmapi.dll + 整个 ue4ss 文件夹
    仅禁用模组模式：保留加载器，只移走 Mods\\ETBNightmareMod，并把 mods.txt 换成干净版本
    检查模式：只报告，不做任何改动
    撤销：--undo，把最近一次备份的东西搬回去

用法：
    python ETB_Restore_Vanilla.py --check
    python ETB_Restore_Vanilla.py --mode full --dry-run
    python ETB_Restore_Vanilla.py --mode full
    python ETB_Restore_Vanilla.py --mode loader
    python ETB_Restore_Vanilla.py --undo
    python ETB_Restore_Vanilla.py --path "D:/.../Binaries/Win64" --mode full
"""

import argparse
import glob
import os
import re
import shutil
import sys
import time
from pathlib import Path

EXE_NAMES = ("Backrooms-Win64-Shipping.exe", "EscapeTheBackrooms-Win64-Shipping.exe")
LOADER = "ue4ss"
PROXY = "dwmapi.dll"
MOD_FOLDER = "ETBNightmareMod"
BACKUP_PREFIX = "_ETB_mod_backup_"
CLEAN_DIR = "干净文件"
STEAM_SUFFIX = Path("steamapps") / "common" / "EscapeTheBackrooms" / "EscapeTheBackrooms" / "Binaries" / "Win64"


def out(msg=""):
    print(msg, flush=True)


def find_win64(explicit=""):
    """定位 Binaries\\Win64。显式路径 > 环境变量 > Steam 库 > 全盘搜索。"""
    if explicit:
        p = Path(explicit).expanduser().resolve()
        return p if p.is_dir() else None

    env = os.environ.get("ETB_WIN64", "").strip()
    candidates = []
    if env:
        candidates.append(Path(env))
    steam = os.environ.get("STEAMPATH", "").strip()
    if steam:
        candidates.append(Path(steam) / STEAM_SUFFIX)
    for base in (r"C:\Program Files (x86)\Steam", r"C:\Program Files\Steam",
                 r"D:\Steam", r"D:\SteamLibrary", r"E:\SteamLibrary",
                 r"X:\SteamLibrary"):
        candidates.append(Path(base) / STEAM_SUFFIX)
    for p in candidates:
        try:
            if p.is_dir():
                return p.resolve()
        except OSError:
            pass

    if sys.platform == "win32":
        import string
        for letter in string.ascii_uppercase:
            root = Path(letter + ":\\")
            if not root.exists():
                continue
            for p in root.glob(str(STEAM_SUFFIX).replace("\\", "/")):
                if p.is_dir():
                    return p.resolve()
    return None


def validate(win64):
    """确认这真的是游戏 Binaries\\Win64，而不是随便一个同名文件夹。"""
    if not isinstance(win64, Path) or not win64.is_dir():
        return "目录不存在"
    if win64.name.lower() != "win64":
        return "目录名不是 Win64"
    if len(win64.parts) < 5:
        return "路径层级太浅，疑似选错目录"
    if not any((win64 / n).is_file() for n in EXE_NAMES):
        return "找不到游戏主程序（Backrooms-Win64-Shipping.exe），不是正确的 Binaries\\Win64"
    return ""


def game_root(win64):
    """两层 EscapeTheBackrooms 里，内层工程目录就是备份放在的地方。"""
    return win64.parents[1]


def new_backup(root, dry_run):
    name = BACKUP_PREFIX + time.strftime("%Y%m%d_%H%M%S")
    target = root / name
    if not dry_run:
        target.mkdir(parents=True, exist_ok=False)
    return target, name


def move_to(src, backup, dry_run):
    if not src.exists():
        out("   - 跳过（不存在）：%s" % src.name)
        return False
    dst = backup / src.name
    if dst.exists():
        out("   [!] 备份里已有同名项，跳过：%s" % src.name)
        return False
    out("   %s %s -> %s" % ("[试运行] 移动" if dry_run else "移动", src.name, backup.name))
    if not dry_run:
        shutil.move(str(src), str(dst))
    return True


def clean_mods_txt(existing: bytes, bundled: Path):
    """优先用包内干净 mods.txt；没有就逐行过滤掉本 Mod。"""
    if bundled.is_file():
        return bundled.read_bytes(), "包内干净文件"
    text = existing.decode("utf-8", "ignore")
    lines = [ln for ln in text.splitlines()
             if MOD_FOLDER.lower() not in ln.lower()]
    return ("\n".join(lines) + "\n").encode("utf-8"), "逐行过滤"


def status(win64):
    out("目标目录：%s" % win64)
    out("  dwmapi.dll（加载器代理）: %s" % ("存在" if (win64 / PROXY).exists() else "不存在"))
    out("  ue4ss\\（加载器目录）    : %s" % ("存在" if (win64 / LOADER).is_dir() else "不存在"))
    mod = win64 / LOADER / "Mods" / MOD_FOLDER
    out("  噩梦模组目录            : %s" % ("存在" if mod.is_dir() else "不存在"))
    leftovers = list(win64.glob("*.etbn-backup"))
    out("  残留备份文件            : %d 个" % len(leftovers))
    roots = game_root(win64)
    backups = sorted(roots.glob(BACKUP_PREFIX + "*")) if roots.is_dir() else []
    out("  已有还原备份            : %d 个（最近：%s）" %
        (len(backups), backups[-1].name if backups else "无"))


def do_restore(win64, mode, dry_run, reset_settings):
    here = Path(__file__).resolve().parent
    bundled_dir = here / CLEAN_DIR
    backup, name = new_backup(game_root(win64), dry_run)
    out("备份位置：%s" % backup)
    out("（注意：这里是「移动到备份」，不是删除，随时可用 --undo 还原）")
    moved = 0

    if mode == "full":
        for rel in (PROXY, LOADER):
            if move_to(win64 / rel, backup, dry_run):
                moved += 1
        for f in win64.glob("*.etbn-backup"):
            if move_to(f, backup, dry_run):
                moved += 1
    else:
        mods = win64 / LOADER / "Mods"
        if mods.is_dir():
            if move_to(mods / MOD_FOLDER, backup, dry_run):
                moved += 1
            mods_txt = mods / "mods.txt"
            if mods_txt.is_file():
                data, how = clean_mods_txt(mods_txt.read_bytes(), bundled_dir / "mods.txt")
                out("   %s mods.txt（%s）" % ("[试运行] 重写" if dry_run else "重写", how))
                if not dry_run:
                    mods_txt.write_bytes(data)
        else:
            out("   - 没有 ue4ss\\Mods，跳过模组清理")
        if reset_settings:
            ini_src = bundled_dir / "UE4SS-settings.ini"
            ini_dst = win64 / LOADER / "UE4SS-settings.ini"
            if ini_src.is_file() and ini_dst.is_file():
                out("   %s UE4SS-settings.ini（恢复原版默认值）" %
                    ("[试运行] 重写" if dry_run else "重写"))
                if not dry_run:
                    shutil.copy2(str(ini_src), str(ini_dst))

    if dry_run:
        out("\n[试运行] 未做任何实际改动。确认无误后去掉 --dry-run 再执行一次。")
    else:
        out("\n完成：移动了 %d 项到 %s" % (moved, backup.name))
        out("现在启动游戏即为原版（无任何 Mod / 加载器）。")
        out("想恢复模组：python %s --undo" % Path(__file__).name)


def do_undo(win64):
    roots = game_root(win64)
    backups = sorted(roots.glob(BACKUP_PREFIX + "*"))
    if not backups:
        out("没有找到备份文件夹，无事可做。")
        return
    backup = backups[-1]
    out("使用备份：%s" % backup)
    for src in sorted(backup.iterdir()):
        dst = win64 / src.name
        if dst.exists():
            out("   [!] 目标已存在，为安全起见跳过：%s" % dst.name)
            continue
        out("   还原：%s" % src.name)
        shutil.move(str(src), str(dst))
    out("完成。若游戏仍有异常，重复执行 --undo 可继续恢复更早的备份。")


def main():
    ap = argparse.ArgumentParser(description="Escape the Backrooms 原版还原工具（只移动不删除）")
    ap.add_argument("--path", default="", help="显式指定 Binaries\\Win64 路径")
    ap.add_argument("--mode", choices=("full", "loader"), default="full",
                    help="full=完全原版（默认）；loader=只禁用模组，保留加载器")
    ap.add_argument("--check", action="store_true", help="只检查状态，不做改动")
    ap.add_argument("--dry-run", action="store_true", help="只演示将做什么")
    ap.add_argument("--reset-settings", action="store_true",
                    help="loader 模式下同时把 UE4SS-settings.ini 换回原版默认值")
    ap.add_argument("--undo", action="store_true", help="从最近的备份还原")
    args = ap.parse_args()

    win64 = find_win64(args.path)
    if not win64:
        out("[X] 找不到游戏目录。请手动指定：--path \"D:/.../Binaries/Win64\"")
        return 2
    err = validate(win64)
    if err:
        out("[X] 目录校验失败：%s\n    路径：%s" % (err, win64))
        return 2

    out("=" * 60)
    out("Escape the Backrooms · 原版还原工具")
    out("=" * 60)
    if args.check:
        status(win64)
    elif args.undo:
        do_undo(win64)
    else:
        status(win64)
        out("")
        do_restore(win64, args.mode, args.dry_run, args.reset_settings)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        out("[X] 出错：%s" % e)
        sys.exit(1)
