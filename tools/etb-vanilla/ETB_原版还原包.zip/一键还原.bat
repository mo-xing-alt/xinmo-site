@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PY="
where py >nul 2>nul
if %ERRORLEVEL%==0 set "PY=py -3"
if not defined PY (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 set "PY=python"
)
if not defined PY (
  echo Python 3 is not installed. Install it or use the AI guide.
  pause
  exit /b 1
)

%PY% ETB_Restore_Vanilla.py --check
echo.
echo Type full = vanilla / loader = keep UE4SS only / undo = restore backup
echo Press Enter to cancel.
set "ANS="
set /p ANS=Choice: 

if /I "%ANS%"=="full"   %PY% ETB_Restore_Vanilla.py --mode full
if /I "%ANS%"=="loader" %PY% ETB_Restore_Vanilla.py --mode loader
if /I "%ANS%"=="undo"   %PY% ETB_Restore_Vanilla.py --undo
if /I "%ANS%"=="check"  %PY% ETB_Restore_Vanilla.py --check

echo.
pause
