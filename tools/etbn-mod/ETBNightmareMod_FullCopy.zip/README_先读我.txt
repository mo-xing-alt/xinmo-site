﻿ETBNightmareMod  ——  完整复制版联机包
================================================================
★ 只发这一个压缩包给朋友。之前那两个包（TeamPack / CopyPaste）已作废，
  它们缺少 UE4SS 内置 Mod 和 UEHelpers.lua，会导致「控制台都出不来」。

本包 = 房主本机「已验证可正常运行」的整套文件，效果完全一致。


【一、装到哪个文件夹】(最容易出错的一步)
----------------------------------------------------------------
目标不是 Steam 根目录，注意中间有两层 EscapeTheBackrooms：

  <Steam库>\steamapps\common\EscapeTheBackrooms\EscapeTheBackrooms\Binaries\Win64

例如装在 D 盘默认位置就是：
  D:\Steam\steamapps\common\EscapeTheBackrooms\EscapeTheBackrooms\Binaries\Win64

怎么确认找对了：这个 Win64 文件夹里应该能看到
  Backrooms-Win64-Shipping.exe  （约 85 MB）
如果只看到 Backrooms.exe，说明还差一层，再往里进。


【二、安装步骤】(不用运行任何脚本，纯复制粘贴)
----------------------------------------------------------------
1. 完全退出游戏（Steam 里也确认进程已关）。
2. 把本压缩包【全部解压】到桌面任意文件夹。
3. ★ 如果之前装过旧包：先打开 Win64，把里面已有的 ue4ss 文件夹
   改名成 ue4ss_旧版备份（不要删，方便还原）。
   全新没装过的跳过这步。
4. 打开解压出来的文件夹，应该能看到 3 项：
      dwmapi.dll
      ue4ss\            （文件夹，里面有一堆官方内置 Mod）
      README_先读我.txt （本说明）
   按 Ctrl+A 全选、Ctrl+C 复制。
5. 打开上面【一】里说的 Win64 文件夹，Ctrl+V 粘贴。
   弹出「覆盖 / 替换」提示时，一律选「是 / 替换」。
   （如果第 3 步已改名备份，这里就是全新复制，不会有覆盖提示。）
6. 完成。整个 Win64 目录下应该多出 dwmapi.dll 和 ue4ss\。


【三、怎么确认成功了】
----------------------------------------------------------------
1. 启动游戏，会额外弹出一个【黑色文字窗口】，这是 UE4SS 的日志控制台，
   属于正常现象，最小化即可，不要觉得是报错。
2. 进入任意关卡后，按 ~ （波浪键，Esc 下面）打开游戏控制台。
   中文键盘按不出来时，改试 , （逗号）或 F10，三个键都能开。
3. 输入  etbn status  然后回车。
   看到类似下面这行，就说明 Mod 完整加载了：
     模式=normal | 倍率=3.0 | 无限体力=true | Juice=false | 联机同步=false ...
     联机: NetMode=3 (客户端 Client) | 服务端=false | 角色 本地1/远端3 ...
     皮肤: 预设=off | 安全模式=true (防崩溃：不自动应用/不主动加载资产) ...
4. 输入  etbn help  可以列出所有命令。
5. 如果控制台里没有任何输出，去看 Win64\ue4ss\UE4SS.log，
   搜索 "ETBNightmare" 和 "error"，把这几行发给房主排查。


【四、按键与命令】
----------------------------------------------------------------
  G     手枪扳机（朝准星发射致命射线）—— ★ 已由 F 改成 G
  F6    普通无限体力奔跑模式 —— 原版速度 + 无限体力锁满
  F7    噩梦模式 —— 3 倍跑步速度（同样无限体力）
  F8    循环切换场景/实体皮肤：原版 -> 圣诞经典 -> 冰雪奇境 -> 糖果工坊 -> 金色庆典
        ★ 默认停在「原版」（稳定优先）；想开皮肤进关几秒后再按，详见【四之七】

★ F 是游戏原生「交互 / 开门 / 拾取」键，千万不要用 F 当扳机。
  旧版把 F 绑成扳机，按 F 开锁 / 开窗户时 Mod 会同时开枪，
  把 bp_lock_5_c、bp_windowpicker_c 这些交互道具当成"实体"打没 ——
  这就是「碰到某样东西它自动消失」。本版已换 G 并加绝对保护名单。

  etbn status                 查看当前状态
  etbn mode normal            普通无限体力奔跑模式（= F6）
  etbn mode sprint            同上，别名
  etbn mode nightmare         切 3 倍速（= F7）
  etbn fixspeed               应急：回到原版速度 + 无限体力
  etbn gun                    直接给自己发一把手枪
  etbn spawn                  立刻在附近刷新手枪
  etbn scan [all]             列出场上 Pawn 类名 + 判定原因；all 额外扫全场 Actor
  etbn hits                   最近 12 次射线命中了什么（排查「瞄了却打不死」）
  etbn protect <类名>          立刻临时保护某类名不被销毁
  etbn entity <关键词>         临时补进实体白名单（排查「打不死的怪」）
  etbn killall                手动清掉场上所有实体（漏网兜底）
  etbn dump                   输出每个角色的体力/速度数值（排错用）
  etbn net                    显示本机是房主还是客户端 + 3 倍速配对提示
  etbn perf                   查看缓存命中率 / 全对象扫描次数 / 当前频率
  etbn tick 150              即时调整主循环间隔（毫秒，越大越省性能）
  etbn skin list             列出全部场景 / 实体皮肤
  etbn skin christmas        圣诞经典（★ 默认 off，需手动开启）
  etbn skin frost|candy|gold 冰雪奇境 / 糖果工坊 / 金色庆典
  etbn skin off              一键还原游戏原版外观
  etbn skin apply            重新应用当前皮肤（换关后手动补一次）
  etbn skin status           查看皮肤统计 / 资产加载情况
  etbn skin props on|off      开关圣诞装饰植入
  etbn skin scene on|off      场景染色（★ 默认关，防止墙面变灰）
  etbn skin assets           逐个列出游戏内圣诞资产能否加载
  etbn skin fallback on|off   引擎灰材质兜底（★ 默认关）
  etbn skin safe on|off       安全模式（★ 默认 on，防崩溃；别关）
  etbn sync on|off            全房 3 倍速同步（★ 默认关，防止队友跑不动）
  etbn help                   全部命令

※ F6 现在会：强制把速度写回游戏原版 + 强制开启无限体力并立刻钉满。
  一旦加速停不下来，按 F6 或输入 etbn fixspeed 即可。
  实在不行重启一次游戏即可彻底重置（速度是运行时属性，不会跨进程保留）。

※ 遇到「有的实体杀不掉」：
  1) 开枪时日志会打印命中的类名；控制台输入 etbn scan 可列出全场 Pawn 类名。
  2) 默认已开启「任何非玩家 Pawn 都算实体」+「射线穿透场景遮挡」，
     隔着玻璃 / 栏杆 / 隐形碰撞体也能打到后面的实体。
  3) 仍漏网的用 etbn killall 手动清场；把日志里那个类名发给房主，
     加进 config.lua 的 EntityPatterns 即可永久解决。
  4) 联机时客户端本地销毁可能被服务端同步回来，让房主射击更可靠。


【四之二、帧率 / 性能】（本版已优化）
----------------------------------------------------------------
旧版掉帧的原因：20Hz 主循环每次做 2 次 FindAllOf 全对象扫描，加上
「每个角色每帧」的移动钩子里反复重查服务端与本地角色判定 —— 三重叠加，
很吃游戏线程。本版已做：

  · 全局查询按 UWorld + TTL 缓存（换关自动失效），角色列表 0.5s 刷一次；
    主路径命中时不再做第二次 PlayerController 全扫。
    实测 20 次 tick 的全对象扫描从 40 次降到 5 次。
  · 每帧移动钩子节流到最多约 10Hz；钩子装不上时改为每 5 秒才重试一次，
    最多 12 次（旧版每 50ms 就重扫一次）。
  · 主循环默认 100ms（10Hz），并改成软件节流：etbn tick 150/200 可即时调，
    不用重启游戏。
  · 默认关闭「射线穿透非实体」日志（UE4SS 的 print 是同步磁盘 I/O，
    连发时会卡）；要排错就把 config.lua 的 LogPenetrationHits 改成 true。
  · 联机加载期的 BeginPlay 钩子节流到每 0.25s 检查一次。

如果还觉得卡，按顺序试：
  1) 控制台  etbn perf  看缓存命中率与扫描次数（命中率应远高于扫描次数）。
  2) 输入  etbn tick 150  或  etbn tick 200（立即生效，越大越省 CPU）。
  3) 把 config.lua 的 FrameHookThrottleMs 改 200、CharacterCacheMs 改 800，
     然后 etbn reload。
  4) 关闭准星自动击杀模式（etbn killmode trigger），aim 模式会每 200ms 射一次线。
  5) 仍不行把 UE4SS.log 和 etbn perf 的输出发给房主排查。


【四之三、碰到某样东西它就自动消失】（本版已修复）
----------------------------------------------------------------
这是旧版最烦人的 bug。日志里查到被"击杀"的其实是
  bp_lock_5_c（锁） 和  bp_windowpicker_c（窗户选择器）
它们是关卡交互道具，不是怪物。四个原因叠在一起：

  1) F 既是游戏原生「交互 / 开门 / 拾取」键，又被旧版绑成手枪扳机。
     你按 F 想开锁 / 开窗户，Mod 同时朝准星发了致命射线。
  2) 这些交互物在游戏里派生自 Pawn / Character（为了能接收输入），
     于是被 KillAnyNonPlayerPawn 的「任何 Pawn 都算实体」兜底误判。
  3) 保护白名单里没有 lock / window / picker / door 这些词。
  4) RequirePistolFallback=true 让玩家【空手】也能开枪。

本版的四层修复：
  · 默认扳机键 F -> G（F 留给游戏交互），并加 200ms 扳机节流防连发。
  · 新增 NeverKillPatterns 绝对保护名单（锁、窗户、门、按钮、阀门、
    键盘、面板、家具、道具等 60+ 关键词）。它优先级高于一切实体判定，
    连 Pawn 兜底也越不过去；销毁函数里还有最后一道硬闸。
  · 检测 Actor 是否带交互组件字段（bCanInteract / InteractionComponent 等），
    带就不算实体。
  · 持枪判定改成双态：确认持有信号枪才放开 Pawn 兜底；检测不到背包时
    只允许击杀「明确在白名单里的实体」，宁可漏杀也不误杀交互物。

注意：名单里故意【没有】wire / party / roaming 等词，因为 bp_wire、
partygoer、roamingparty 是真实实体，不能被误保护。

再遇到新的误杀 / 漏杀，用控制台即时处理（都不用重启）：
  etbn scan                 列出场上 Pawn 类名 + 判定原因
  etbn protect bp_xxx_c     立刻保护某个类名（本次游戏有效）
  etbn entity  <关键词>     把打不死的怪临时加进实体白名单
要永久生效，把关键词写进 config.lua 的 NeverKillPatterns / EntityPatterns。


【四之四、细菌打不死】（本版已修复）
----------------------------------------------------------------
从游戏 pak 索引里查到，细菌确实是真实实体，资产包括：
  bacteria_bp / bacteria_roaming_bp / roamingbacteria /
  bacteriajumpscare / bacteria_aic(AI 控制器) / bacteria_animbp
但旧版 EntityPatterns 里【一个 bacteria 关键词都没有】，所以只能靠
「任何 Pawn 都算实体」的类型兜底；上一版又加了「没确认持枪就禁用兜底」
的严格模式，于是细菌两头都够不着 —— 这就是打不死的原因。

本版：
  · EntityPatterns 补上 4 个精确细菌类名（不用笼统的 "bacteria"，
    避免误杀 bp_bacteria_zone 区域触发器 / bp_bacteria_roompoint 刷新点；
    这两个已加进绝对保护名单）。
  · 取消「严格模式一刀切禁用 Pawn 兜底」。误杀交互物已经由换键 +
    绝对保护名单 + 交互组件探测 + 扳机节流四层挡住，不再需要牺牲
    白名单外的真实体。保守模式现在只在日志里留个标记。

★ 如果换包重启后【仍然】打不死，多半是射线根本没打到细菌本体
  （细菌可能是贴地网格 / 没有碰撞体，准星打的是地面）。两步定位：
     1) 按 G 朝细菌开一枪，然后输入  etbn hits
        看最近 12 次射线命中的类名：清一色 staticmeshactor 就是没打到本体。
     2) 输入  etbn scan all  扫全场 Actor，确认细菌的类名和判定原因。
  把这两条的输出发给房主，就能精确再补一版。


【四之五、场景 / 实体圣诞皮肤包】（本版新增）
----------------------------------------------------------------
想换一套新外观？本版内置 4 套皮肤，可给实体（尤其是派对客）换材质，
并往关卡里放拐杖糖、星星、彩球等圣诞装饰。

★★ 重要默认值（2026-11-10 崩溃修复 + 防灰墙）：
  ★ 皮肤默认【完全关闭】（SkinPreset=off）：启动和换关时一行皮肤代码都不跑。
    想要圣诞外观，请在【进关几秒后】手动输入 etbn skin christmas 或按 F8。
    换关后 4 秒内会拒绝应用，等画面稳定再 etbn skin apply。
    原因见【四之七】：换关瞬间自动跑全场扫描 + 同步加载资产会崩游戏。
  场景染色 = 关，引擎灰材质兜底 = 关：墙面、地板、家具一律保持游戏原版。
  本版不再主动 LoadAsset，只读内存里已加载的对象（多数 MISS，
  对应物件保持原版外观，属正常现象）。
  想自己试染色：先 etbn skin assets 看资产是否加载得到，
  再 etbn skin scene on；不想要了 etbn skin scene off 立刻还原。

  etbn skin list              列出全部皮肤
  etbn skin christmas         圣诞经典：派对客 = 拐杖糖红白，
                              其它实体 = 雪天使白
  etbn skin frost             冰雪奇境：雪翼 / 吹雪冷色调
  etbn skin candy             糖果工坊：所有实体统一拐杖糖条纹
  etbn skin gold              金色庆典：陶瓷金白 + 发光材质
  etbn skin off               一键还原全部游戏原版外观
  etbn skin apply             换关后手动重新应用一次
  etbn skin status            查看换了多少个、安全模式、场景染色开关、失败数
  etbn skin props on|off      开关圣诞装饰植入
  etbn skin scene on|off      场景染色（默认关）
  etbn skin assets           逐个列出游戏内圣诞资产能否加载
  etbn skin fallback on|off   允许引擎灰材质兜底（默认关，别开）
  etbn skin safe on|off       安全模式（默认 on；off 会恢复换关自动重套，别关）
  F8                          不打字，直接循环切换

★ 素材全部来自【游戏本体自带】的圣诞 / 冬季资产（pak 索引里实有）：
    /Game/Costumes/HolidayUpdate/   节日漫游者、Jolly、驯鹿装
    /Game/Club/InteriorProps/       拐杖糖模型与材质、暖光发光材质
    /Game/Entity/SnowAngel/         雪天使身体 / 翅膀 / 眼睛材质
    /Game/Effects/Materials/Snow/   吹雪材质
    /Game/Hotel/MailBoxes/          星星、彩球装饰
  运行时给组件换材质（SetMaterial）和换模型（SetStaticMesh），
  不重绘贴图、不新增模型文件，所以离线联机都能加载。

技术边界（说清楚，免得期待错）：
  · 这是「材质级 / 模型级」换肤，不是重画贴图或做新角色模型。
    真正重绘贴图要 Unreal Editor 生成 cooked .uasset 再打 .pak，
    本机没有编辑器，做不到。
  · 换材质不改碰撞体，手枪击杀判定完全不受影响；
    皮肤只碰外观，交互道具、玩家角色、细菌区域一律不碰。
  · 材质不是联机同步属性：每个玩家都要装本包并各自开皮肤，
    才能在自己屏幕上看到效果（速度 / 体力那套不受影响）。

观感调法（config.lua，改完 etbn reload）：
  SkinPreset                默认 "off"（★ 稳定优先，手动开才生效）
  SkinSafeMode              默认 true = 禁止换关/启动自动应用、换关 4 秒宽限
  SkinApplyOnLevel          默认 false = 换关不自动重套
  SkinLevelGraceMs          默认 4000 = 换关后这段时间内拒绝应用
  SkinSceneEnabled          默认 false = 场景保持原版（★ 防灰墙）
  SkinAllowEngineFallback   默认 false = 资产加载失败就保持原版（★ 防灰块）
  SkinSceneRatio            0.25 = 每 4 个场景物件点缀 1 个
  SkinPropsEnabled          false = 不放拐杖糖 / 星星 / 彩球
  SkinMaxProps              装饰数量上限（默认 12）
  SkinMaxActors             单次遍历 Actor 上限（默认 150）
  SkinBudgetMs              单次时间预算（默认 150ms）

性能：皮肤【只在你手动切换时】执行一次，带 150ms 时间预算和数量上限，
不进主循环、不进每帧钩子，所以不会像旧版那样掉帧。
换关【不会】自动重新应用（这是防崩溃的关键）；想在新关卡继续用皮肤，
等画面稳定后手动 etbn skin apply。etbn skin off 随时完整还原材质和模型。

★ 如果日志打印「失败/不支持」或 etbn skin assets 里出现 MISS：
  说明这些游戏内资产在当前关卡 / 当前机器上加载不到，属于正常现象，
  Mod 会保持原版外观、不会崩，也不会刷成灰块。
  输入 etbn skin status 看统计；想彻底关掉就 etbn skin off。


【四之六、墙面变灰 / 蜘蛛触手怪杀不掉 / 队友跑不起来】（本版修复）
----------------------------------------------------------------
这三个是上一版皮肤包带出来的实机问题，本版都已修好：

1) 「墙面一半灰一半原版」
   根因：旧版给 60 个场景物件换材质，但游戏内资产大多加载不到，
   于是降级用了引擎内置 DefaultMaterial，把墙面刷成灰色 / 发光灰块。
   修复：默认 SkinSceneEnabled=false 完全不染场景；
        SkinAllowEngineFallback=false 禁用灰材质兜底，加载失败就保持原版。
   一键确认：etbn skin assets（看 MISS）、etbn skin status（看 染色=关）。
   想试染色再 etbn skin scene on，不想要了 etbn skin scene off。

2) 「蜘蛛 / 触手怪都杀不掉」
   根因：从 pak 索引重新提取 /Game/Entity/ 下 56 个 BP_ 蓝图后，
   发现玩家俗称的蜘蛛 / 触手怪实际叫 bp_membri / bp_clump /
   bp_clump_poolrooms，旧白名单里一个都没有。而且通用场景名单里的
   staticmeshactor / trigger / volume 等词会先命中，把明确在白名单里的
   真实体也挡成「场景物件」。
   修复：补 membri / clump / bp_moth / moths / hydroplague / bonethief /
        hoard2 / fish_scare / smiler_dash 等白名单；
        并把「明确实体白名单」的判定顺序提到「通用场景白名单」之前。
        配套的区域 / 刷新器（clumpmovezone / smilermovezone /
        membri_manager / roaming_volume / attack_zone ...）加绝对保护，
        不会被顺手打没。
   仍漏网的：按 G 开一枪 -> etbn hits 看命中类名 -> etbn scan all
        看判定原因 -> etbn entity <关键词> 临时补，把类名发给房主永久补。

3) 「别人来我房间跑不起来」
   根因：房主开噩梦时旧版会放大【服务端上的队友角色】，
   而 healRemote 又把队友的 MaxWalkSpeed 无条件写回 WalkSpeed(275)，
   UE4 的服务端移动校验于是把对方的 Shift 冲刺按走路速度拉回。
   修复：SyncNightmareToClients 默认 false —— 房主按 F7 只加速自己，
        速度字段一个都不写队友；healRemote 只清残留的 IsBurnedOut
        和「我们确实改过的」MaxAcceleration，绝不碰队友 MaxWalkSpeed。
   ★ 想让全房都 3 倍速，必须显式 opt-in：
       第 1 步：所有玩家（含房主）各自按 F7；
       第 2 步：房主输入 etbn sync on；
       第 3 步：用完 etbn sync off 关掉（或房主按一次 F6 撤销残留）。
     没按 F7 的人会被服务端拉回，所以别只开一半。


【四之七、游戏老崩溃 / 闪退】（本版重点修复）
----------------------------------------------------------------
症状：玩十几分钟、换几次关卡就崩，Windows 弹出崩溃报告或直接闪退。

实机证据（本机 %LOCALAPPDATA%\EscapeTheBackrooms\Saved\Crashes\）：
  两次 UE4 Minidump 的 CrashContext.runtime-xml 都是
    Unhandled Exception: EXCEPTION_ACCESS_VIOLATION
  一次是 reading address 0xffffffffffffffff（无效 UObject 指针），
  一次是 writing address 0x...（写只读代码段）。
  两次的 PCallStack 里都是同一串 UE4SS Lua VM 帧
  （33cebe / 24224a / 846db5 / 91fe9a / 92a6db ... 重复三组），
  说明崩在「Lua 回调 -> 访问 UObject」这条链上，不是单纯的显卡/驱动问题。
  同时 UE4SS.log 显示每次换关 +1.5~2 秒都有一次
    [皮肤] ... 耗时=500ms
  和 Asset loaded —— 正好是旧版自动重套皮肤的时刻。

根因（三条叠在 UE4 关卡加载期）：
  1) 换关回调里 Core.Delay(1500) 自动重套皮肤，此时 LoadMap 正在
     批量销毁 / 重建 UObject，FindAllOf("Actor") 拿到的很多是悬空指针。
  2) resolve() 里的 LoadAsset 会【同步加载 cooked 资产】，与引擎的
     异步加载 / GC 抢资源，是访问违例的典型来源。
  3) 上一版新增的 scanComponents() 把最多 600 个组件 UObject 缓存在
     Lua 表里，换关后全部悬空，再 c:GetOwner() 就是读已释放内存。
  另外每次都跑满 500ms 预算（400 Actor × 600 组件反查），加载期压力很大。

本版的修复（都已做成打包硬拦截，防止以后改回去）：
  · 默认 SkinPreset=off、SkinApplyOnLevel=false、SkinSafeMode=true：
    启动 / 换关【完全不自动跑皮肤】，皮肤只由你手动命令或 F8 触发。
  · 删除 LoadAsset：只读内存里已加载的对象（StaticFindObject / FindObject）。
    代价是多数游戏内材质查不到 -> 保持原版外观，这本来就是安全默认。
  · 删除全组件扫描 + GetOwner 反查：只探测 Actor 自身组件字段，
    探测不到就跳过，不再缓存任何跨关卡 UObject。
  · 还原表每条记录带 UWorld 地址戳，世界变了一律丢弃，
    绝不拿旧材质 / 模型指针去调 SetMaterial / SetStaticMesh。
  · 换关后 4 秒宽限期内拒绝应用皮肤；预算 500ms->150ms、
    Actor 上限 400->150，并取消启动时 Core.Delay(3500) 的自动应用。

★ 换包后仍崩怎么办（按顺序做 A/B 验证，别急着改配置）：
  1) 确认两台都换了本版新包、都完全退出游戏重启过。
  2) 输入 etbn status，确认「皮肤 预设=off 安全模式=true」。
     如果还开着皮肤，先 etbn skin off 玩一局对比。
  3) 还是崩 -> 用 联机诊断\1_DISABLE_MOD_test_lan.bat 临时关掉整个
     加载器（只改 dwmapi.dll 的名字，不删文件），再玩一局：
       能稳 = 问题在 Mod/加载器，把 UE4SS.log 最后 100 行发房主；
       还崩 = 与 Mod 无关，是游戏本体 / 显卡驱动 / 联机版本问题。
     本机还有一次更早的崩溃转储里完全没有 UE4SS 栈帧，说明游戏本体
     本身也偶发崩溃，所以这个 A/B 是必要的。
  4) 别在换关加载的瞬间狂按 F8；想开皮肤等进关画面稳定几秒后再按。
  5) 想恢复「换关自动重套」：etbn skin safe off 且把 config.lua 的
     SkinApplyOnLevel 改成 true —— 但这就是旧崩溃路径，不建议开。


【五、联机时谁要装 + 3 倍速 / Shift 的正确用法】
----------------------------------------------------------------
★ 建议全房都装，且都用「同一个这个包」，两台都重启游戏后再联机。

  · 手枪刷新、实体击杀：房主端执行并同步，只房主装也生效。
  · 无限体力：只作用于【本机自己的角色】，所以每人都得装才有。
    Mod 不再碰队友的体力字段，房主不会把别人的 Shift 冲刺关掉。
  · 圣诞皮肤包：纯本地视觉，材质不跨机器同步，每人各自按 F8 /
    etbn skin christmas 开启才看得到。★ 默认 off 且换关不自动重套
    （防崩溃），想在新关卡继续用就等稳定后 etbn skin apply。详见【四之五】【四之七】。
  · 3 倍速度：UE4 的移动是服务端权威的。客户端单方面改 MaxWalkSpeed
    会被服务端按原速校验纠正回来 —— 这就是「进别人世界三倍速没用」。

  ★ 本版默认：房主按 F7【只加速自己】，速度字段一个都不写队友。
    这是为了避免「别人进我的世界跑不起来」。全房 3 倍速改成显式开启：
      1) 所有玩家（含房主）各自按一次 F7；
      2) 房主输入 etbn sync on（同步服务端上的队友角色，让校验认可）；
      3) 两边输入 etbn status 确认 模式=nightmare、联机同步=true；
      4) 用完 etbn sync off 关掉。
    ★ 只要有一个人没按 F7，那个人就会被服务端按原速校验拉回，
      表现为「跑不动」。所以要么全员配对，要么就别开 sync on。

  别人进你的世界 Shift 不能加速 / 跑不起来：
    旧版有两个叠加 bug：给所有角色写 IsBurnedOut=true（游戏原生 Juice，
    把速度锁成 675 且关掉 Shift 冲刺），以及 healRemote 把队友服务端
    MaxWalkSpeed 无条件写回 WalkSpeed(275)，被移动校验按走路速度拉回。
    本版已彻底改成「只写本地角色」，房主正常模式完全不碰队友，
    healRemote 也绝不写队友 MaxWalkSpeed。
    换包后按一次 F6（或 etbn fixspeed）：房主会清掉队友身上残留的
    Juice 状态和放大值，之后 Shift 立即恢复原版。详见【四之六】。

  排错三连（两边都做，把输出发房主）：
    etbn status   -> 看模式是否一致
    etbn net      -> 看自己是客户端还是房主
    etbn dump     -> 看每个角色的 IsBurnedOut / MaxWalkSpeed

想统一默认模式，把房主的
  ue4ss\Mods\ETBNightmareMod\Scripts\config.lua
发给朋友覆盖同名文件即可，主要看 SpeedMode 这一行
（normal / nightmare）。改完在游戏里输入 etbn reload 可热重载。


【六、常见问题】
----------------------------------------------------------------
Q: 游戏老崩溃 / 玩一会儿就闪退？
A: 八成是上一版换关时自动重套皮肤撞上关卡加载期。本版已默认关闭皮肤
   自动应用、移除同步资产加载与跨关卡 UObject 缓存。先确认两台都换包并
   重启、etbn status 里「皮肤 预设=off 安全模式=true」；仍崩就用
   联机诊断\1_DISABLE_MOD_test_lan.bat 关掉整个加载器做 A/B 对比
   （能稳=Mod 问题，还崩=游戏本体/驱动）。详见【四之七】。

Q: 按 ~ 没反应？
A: 试 , 或 F10；确认第 3 步没有留下旧的残缺 ue4ss 文件夹；
   确认 mods.txt 里 ConsoleEnablerMod : 1 这行还在。

Q: 控制台开了但输入 etbn status 没输出？
A: 说明本 Mod 没加载。检查 Win64\ue4ss\Mods\ETBNightmareMod\Scripts\
   下是否有 7 个 .lua 文件（含 skins.lua）；检查 mods.txt 是否有
   ETBNightmareMod : 1；再看 UE4SS.log 里的报错。

Q: 杀毒软件报毒 / 文件被删？
A: dwmapi.dll 是 DLL 代理注入，常被误报。把整个 Win64 目录加入信任，
   然后重新解压粘贴一次。

Q: 进别人世界三倍速没用 / 别人进我的世界 Shift 不能加速、跑不起来？
A: 必须用本新版包、两台都重启。本版默认房主 F7 只加速自己、不碰队友，
   所以队友的 Shift 一定是原版正常速度；房主按 F6 可清掉旧版残留的
   Juice / 3 倍速度。要全房 3 倍速：所有人先各按 F7，房主再 etbn sync on，
   用完 etbn sync off。详见【四之六】【五】；etbn net / etbn dump 看数值。

Q: 墙面一半灰一半原版 / 有些墙变成灰色方块？
A: 上一版把场景物件降级成了引擎内置灰色材质。本版默认
   SkinSceneEnabled=false、SkinAllowEngineFallback=false，墙面永远保持
   游戏原版。先 etbn skin status 确认「染色=关」，再 etbn skin assets
   看资产状态；想彻底关掉皮肤就 etbn skin off。详见【四之五】【四之六】。

Q: 蜘蛛 / 触手怪打不死？
A: 本版已把 bp_membri / bp_clump / bp_clump_poolrooms 等真实蓝图类名
   补进实体白名单，并把实体白名单判定提到场景白名单之前。换包重启即可。
   仍漏网就按 G 开一枪 -> etbn hits -> etbn scan all，把类名发给房主
   或用 etbn entity <关键词> 临时补。详见【四之六】。

Q: 帧率变低 / 游戏变卡？
A: 用本版新包（已做缓存与节流），两台都重启。还卡就 etbn perf 看统计，
   再 etbn tick 150 或 200 即时降频；详见【四之二】。别开 aim 自动击杀模式。

Q: 走近 / 按 F 交互时，门锁、窗户之类的东西自动消失了？
A: 换本版新包并重启。旧版 F 与游戏交互键冲突 + 交互物被误判成实体；
   现在扳机是 G、交互物有绝对保护名单。详见【四之三】。
   还有漏网的用 etbn protect <类名> 立刻保护，并把类名发给房主。

Q: 某个怪打不死了？（例如细菌）
A: 细菌类名已补进白名单，用本版新包并重启即可。仍打不死就按 G 开一枪，
   再输入 etbn hits 看准星到底打到了什么，然后 etbn scan all 查细菌类名
   与判定原因；用 etbn entity <关键词> 临时补白名单，或写进
   config.lua 的 EntityPatterns 永久生效。详见【四之四】。

Q: 皮肤没生效 / 派对客没换新外观？
A: ★ 本版默认 off（稳定优先），先手动 etbn skin christmas 或按 F8 开启，
   且要等进关画面稳定几秒（换关后 4 秒内会拒绝应用）。
   再 etbn skin status 看当前预设和统计，etbn skin assets 看资产是否 MISS：
   MISS 时本版保持原版外观（不刷灰块），这是正常的 —— 本版不再主动
   LoadAsset，只读内存里已加载的对象。
   换关不会自动重套，想继续用就 etbn skin apply。
   联机时材质不会跨机器同步，每个玩家都要装本包并各自开启才看得到。
   详见【四之五】【四之七】。

Q: 想换回原来的画面？
A: 输入 etbn skin off，会把所有材质和模型完整还原成游戏原版。
   config.lua 的 SkinPreset 默认已经是 "off"，不用改。

Q: 开了皮肤会不会又掉帧 / 又崩溃？
A: 本版皮肤只在你【手动切换】时执行一次，150ms 时间预算 + 150 Actor 上限，
   不进主循环也不进每帧钩子；换关不再自动跑（这正是防崩溃的关键）。
   若仍卡，按【四之二】用 etbn perf 排查；若仍崩，按【四之七】做 A/B 验证。

Q: 想卸载？
A: 删掉 Win64 下的 dwmapi.dll 和 ue4ss\ 文件夹即可，游戏本体未被改动。
   （ue4ss\Mods 里如果有自己的其它 Mod，删之前先备份。）


【七、注意】
----------------------------------------------------------------
· 建议只在自己开的私人 / 好友房使用，别去公开房影响别人。
· 本包内容来自 UE4SS for Escape the Backrooms 社区 fork（Nexus mod 138,
  v1.3.0）及其自带 Mod，LICENSE 见 ue4ss\LICENSE。
