--[[
    ETBNightmareMod - 「无限体力」+「普通无限体力奔跑 / 噩梦」速度
    ---------------------------------------------------------------
    1) 无限体力默认用「每帧把 Stamina 钉满」，不碰 IsBurnedOut。
       社区 juice.lua 证实 IsBurnedOut=true 会把 MaxWalkSpeed 锁成 675
       并让 Shift 冲刺失效；而且房主端写队友角色会经复制同步过去，
       把对方的冲刺系统关掉 —— 这就是「别人进我的世界 Shift 无法加速」。
       所以：无限体力与体力字段【只作用于本地角色】。
    2) 速度采用「基准值 + 显式撤销」模型：
         baseSpeed = 游戏自己写入的 MaxWalkSpeed（走路/跑步基准）
         applied   = 我们写入的放大值
       噩梦：target = baseSpeed × 倍率（绝不用当前值，避免 3x→9x→27x 累积）
       正常：撤销放大值后完全放手交给游戏
    3) ★ 联机作用域（UE4 移动是服务端权威）：
         - 客户端：只改自己的本地角色；本地 3 倍速会被服务端按原速校验纠正，
           必须房主也开噩梦模式 + 自己也按 F7 才真正生效。
         - 房主 + 噩梦：额外把服务端上其它玩家角色也放大，让校验认可。
         - 房主 + 正常：完全不碰队友角色（只撤销历史残留），保证 Shift 正常。
    4) 主循环 20Hz + 每帧 Hook，双路径保证生效。
--]]

local Core = require("core")

local Movement = {}

local CFG = nil
local applied   = {}   -- [角色地址] = 我们写入的放大值
local baseSpeed = {}   -- [角色地址] = 游戏写入的基准 MaxWalkSpeed
local baseAccel = {}   -- [角色地址] = 原始 MaxAcceleration
local healed    = {}   -- [角色地址] = 已做过一次「旧版残留」清理

-- 启动后第一次看到的「未经我们修改」的 MaxWalkSpeed，作为最后的硬基准。
-- 用途：etbn fixspeed / 切回正常模式时，即使 baseSpeed 被清空或丢失，
--       也能把速度绝对拉回原版，彻底杜绝 3x -> 9x -> 27x 残留。
-- 只在正常模式、且当前值不是我们写入的值时捕获，绝不捕获放大后的值。
local originalSpeed = nil

local function isNightmare()
    return CFG and CFG.SpeedMode == "nightmare"
end

local function restoreAccel(mov, key)
    local a = baseAccel[key]
    if a and a > 0 then
        Core.Set(mov, "MaxAcceleration", a)
    end
end

-- 旧版给「所有」角色写过 IsBurnedOut=true（游戏原生 Juice，锁速 675 +
-- 关掉 Shift 冲刺）和 3 倍 MaxWalkSpeed，房主端写队友角色会复制同步到对方客户端。
-- 这里在服务端对「每个远端角色只清一次」：把 IsBurnedOut 清回 false。
--
-- ★★ 2026-11-10 实机反馈「别人来我房间跑不起来」：
--   旧版还把队友服务端角色的 MaxWalkSpeed 无条件写回 WalkSpeed(275)。
--   WalkSpeed 是【走路】速度，队友按 Shift 时客户端本地是 675，
--   服务端按 275 校验会把客户端移动反复拉回 —— 表现就是跑不动。
--   现在速度字段一个字节都不写，完全交还游戏自己的 sprint 状态机；
--   只撤销我们自己确实改过的 MaxAcceleration（restoreAccel 有基准保护）。
local function healRemote(char, key)
    if healed[key] then return end
    healed[key] = true

    if Core.Get(char, "IsBurnedOut") == true then
        Core.Set(char, "IsBurnedOut", false)
        Core.Log("已清除队友角色残留的 Juice 状态 (IsBurnedOut=true -> false)")
    end

    local mov = Core.Get(char, "CharacterMovement")
    if Core.Valid(mov) then
        restoreAccel(mov, key)
    end
end

-- 撤销之前给「远端玩家角色」写过的放大值，然后彻底放手。
-- 房主从噩梦切回正常时必须做一次，否则队友角色会残留 3 倍速度。
local function restoreRemote(char, key)
    if applied[key] == nil and baseAccel[key] == nil and baseSpeed[key] == nil then
        return
    end
    local mov = Core.Get(char, "CharacterMovement")
    if Core.Valid(mov) then
        local base = baseSpeed[key] or originalSpeed
        if base then Core.Set(mov, "MaxWalkSpeed", base) end
        restoreAccel(mov, key)
    end
    applied[key]   = nil
    baseAccel[key] = nil
    baseSpeed[key] = nil
end

-- 无条件恢复：本地角色一律写回原版速度；
-- 远端角色只有「服务端 + 我们以前确实碰过」才撤销，绝不主动去写队友。
local function restoreAll()
    local chars  = Core.GetAllCharacters()
    local server = Core.IsServerStrict()
    local n = 0
    for _, c in ipairs(chars) do
        local k   = Core.Address(c)
        local mov = Core.Get(c, "CharacterMovement")
        if Core.Valid(mov) and k then
            if not Core.IsLocalCharacter(c) then
                if server then
                    if applied[k] ~= nil or baseAccel[k] ~= nil or baseSpeed[k] ~= nil then
                        restoreRemote(c, k)
                        n = n + 1
                    end
                    healRemote(c, k)
                end
                -- 客户端看到的远端角色 = 复制代理，一个字段都不写
            else
                local base = baseSpeed[k] or originalSpeed
                if not base then
                    local ws = Core.Get(c, "WalkSpeed")
                    if type(ws) == "number" and ws > 0 then base = ws end
                end
                if base then
                    Core.Set(mov, "MaxWalkSpeed", base)
                    n = n + 1
                end
                restoreAccel(mov, k)
            end
        end
    end
    return n
end

function Movement.ApplyOne(char)
    if not Core.Valid(char) then return end
    local key = Core.Address(char)
    if not key then return end

    local isLocal = Core.IsLocalCharacter(char)
    local server  = Core.IsServerStrict()

    ---------------------------------------------------------------
    -- 1) 无限体力：只对「本机自己控制的角色」生效。
    --    房主端去写队友角色的 IsBurnedOut / Stamina 会经复制同步过去，
    --    把对方的体力系统与 Shift 冲刺一起关掉（旧版联机 bug 的根因）。
    ---------------------------------------------------------------
    if isLocal and CFG.InfiniteStamina then
        local cap = Core.Get(char, "MaxStamina") or CFG.StaminaCap
        if type(cap) ~= "number" then cap = CFG.StaminaCap end
        -- 只在确实掉了体力时写，避免每帧无意义地触碰可能被复制的属性
        local cur = Core.Get(char, "Stamina")
        if type(cur) ~= "number" or cur < cap - 0.5 then
            Core.Set(char, "Stamina", cap)
        end
        pcall(function()
            if char.ShouldLowerStamina ~= nil then char.ShouldLowerStamina = false end
        end)
        -- 默认保留游戏原生 sprint；只有显式开 JuiceMode 才锁成 675。
        -- 值已经正确时不写，避免和游戏自己的状态机打架。
        local wantBurned = (CFG.UseJuiceMode == true)
        if Core.Get(char, "IsBurnedOut") ~= wantBurned then
            Core.Set(char, "IsBurnedOut", wantBurned)
        end
    end

    ---------------------------------------------------------------
    -- 2) 远端玩家角色的作用域
    ---------------------------------------------------------------
    if not isLocal then
        if not server then
            -- 客户端看到的别人角色 = 复制代理，一个字段都不能写
            return
        end
        if not isNightmare() or not CFG.SyncNightmareToClients then
            -- 房主「正常模式」：清一次旧版残留（IsBurnedOut / 残留速度），
            -- 然后彻底放手，保证对方 Shift 冲刺由游戏自己控制。
            healRemote(char, key)
            restoreRemote(char, key)
            return
        end
        -- 房主 + 噩梦模式：继续往下，把服务端角色也放大，
        -- 否则服务端按原速校验，会把客户端的 3 倍速纠正回去。
    end

    ---------------------------------------------------------------
    -- 3) 速度
    ---------------------------------------------------------------
    local mov = Core.Get(char, "CharacterMovement")
    if not Core.Valid(mov) then return end

    local cur = Core.Get(mov, "MaxWalkSpeed")
    if type(cur) ~= "number" then return end

    local last = applied[key]
    local oursStillThere = (last ~= nil) and (math.abs(cur - last) < 0.75)

    -- 只有「游戏自己写入的新值」才算基准；残留的放大值绝不能当基准
    if not oursStillThere then
        baseSpeed[key] = cur
        -- 首次看到游戏自己的速度值时，存一份硬基准（供 fixspeed 使用）
        if not originalSpeed and cur > 0 then originalSpeed = cur end
    end
    local base = baseSpeed[key] or originalSpeed or cur

    if not isNightmare() then
        -- 正常模式：撤销上一次写入的放大值，然后完全交还给游戏
        if oursStillThere or last ~= nil or baseAccel[key] then
            if oursStillThere then
                Core.Set(mov, "MaxWalkSpeed", base)
                Core.Debug(string.format("恢复正常速度: %.1f -> %.1f", cur, base), CFG)
            end
            restoreAccel(mov, key)
            applied[key] = nil
            baseAccel[key] = nil
        end
        return
    end

    -- 噩梦模式：以「基准」为基数，绝不拿当前值连乘
    local mult = CFG.NightmareMultiplier or 3.0
    if mult < 1.0 then mult = 1.0 end
    local target = base * mult
    if math.abs(cur - target) > 0.75 then
        Core.Set(mov, "MaxWalkSpeed", target)
        Core.Debug(string.format("噩梦速度: 基准 %.1f -> %.1f (x%.1f)", base, target, mult), CFG)
    end
    applied[key] = target

    -- 加速度同步放大，避免 3 倍极速下起步/转向迟钝
    if CFG.BoostAcceleration then
        local acc = Core.Get(mov, "MaxAcceleration")
        if type(acc) == "number" then
            if not baseAccel[key] or baseAccel[key] <= 0 then
                baseAccel[key] = acc
            end
            local want = baseAccel[key] * mult
            if math.abs(acc - want) > 1.0 then
                Core.Set(mov, "MaxAcceleration", want)
            end
        end
    end
end

function Movement.ApplyAll()
    local chars = Core.GetAllCharacters()
    for _, c in ipairs(chars) do
        Core.Safe(Movement.ApplyOne, c)
    end
    return #chars
end

-- 每帧 Hook：BPCharacter_Demo 的 CheckForwardMovementInput
-- ★ 帧率修复：这个回调是「每个角色每帧」触发的，旧版在这里完整跑一遍
-- ApplyOne（含多次 UEHelpers 查询与 pcall），60fps × N 角色非常吃游戏线程。
-- 现在节流到最多 ~10Hz；速度/体力的持续维持由 10Hz 主循环兜底，
-- 游戏的 sprint 状态机并非逐帧覆盖 MaxWalkSpeed，10Hz 足够跟手。
local lastHookAt = 0

function Movement.OnCharacterTick(Context)
    local t = os.clock()
    local throttle = (CFG and tonumber(CFG.FrameHookThrottleMs) or 100) / 1000.0
    if (t - lastHookAt) < throttle then return end
    lastHookAt = t
    if not Context then return end
    local ok, char = pcall(function() return Context:get() end)
    if ok then Core.Safe(Movement.ApplyOne, char) end
end

function Movement.SetMode(mode)
    if mode ~= "normal" and mode ~= "nightmare" then return false end
    CFG.SpeedMode = mode
    -- 关键：不要清空 applied！ApplyOne 需要它来识别并撤销上一次的放大值。
    Movement.ApplyAll()
    return true
end

-- 应急 / 切回正常模式：本地角色无条件写回原版速度；远端角色只撤销
-- 我们以前写过的放大值并清掉 Juice 残留，之后彻底放手。
-- 与 SetMode("normal") 的区别：SetMode 依赖 applied 标记做「撤销」，
-- 而 ForceRestore 不管当前值是谁写的，本地一律写回基准，最稳。
-- 返回 (恢复的角色数, 使用的原版基准值)。
function Movement.ForceRestore()
    -- 让 F6 / etbn fixspeed 每次都能重新清一次队友身上的旧版残留
    healed = {}
    local n = restoreAll()
    applied = {}
    baseSpeed = {}
    baseAccel = {}
    -- originalSpeed 故意保留：下次再恢复时仍然有可靠的绝对基准
    if CFG then CFG.SpeedMode = "normal" end
    return n, originalSpeed
end

-- F6「普通无限体力奔跑模式」：
-- 强制把无限体力重新打开，并立刻给【本机自己的角色】钉满体力
-- （ApplyOne 里只写本地角色的 Stamina / ShouldLowerStamina / IsBurnedOut）。
-- 速度写回原版由 ForceRestore 负责。队友角色由他们自己的客户端负责。
function Movement.EnableInfiniteSprint()
    if CFG then CFG.InfiniteStamina = true end
    Movement.ApplyAll()
    return true
end

function Movement.GetMode()
    return CFG and CFG.SpeedMode or "normal"
end

function Movement.Init(cfg)
    CFG = cfg
end

function Movement.Reload(cfg)
    -- 换配置（可能改倍率）前先把旧放大值撤销，否则旧 target 会被误当成新基准
    restoreAll()
    applied = {}
    baseSpeed = {}
    baseAccel = {}
    healed = {}
    CFG = cfg
end

---------------------------------------------------------------
-- 联机诊断：把 NetMode / 服务端 / 本地角色判定打出来，方便定位
-- 「进别人世界 3 倍速没用」到底是哪一端没配对。
---------------------------------------------------------------
local NETMODE_NAME = {
    [0] = "单机 Standalone", [1] = "专用服 Dedicated",
    [2] = "监听服/房主 ListenServer", [3] = "客户端 Client",
}

function Movement.NetInfo()
    local nm = Core.NetModeValue()
    local server = Core.IsServerStrict()
    local chars = Core.GetAllCharacters()
    local localN, remoteN = 0, 0
    for _, c in ipairs(chars) do
        if Core.IsLocalCharacter(c) then localN = localN + 1 else remoteN = remoteN + 1 end
    end
    return {
        netmode = nm,
        netname = (nm and NETMODE_NAME[nm]) or "未知(用 HasAuthority 兜底)",
        server  = server,
        count   = #chars,
        localN  = localN,
        remoteN = remoteN,
    }
end

function Movement.LogNet(prefix)
    local i = Movement.NetInfo()
    Core.Log(string.format(
        "%s NetMode=%s (%s) | 服务端=%s | 角色总数=%d 本地=%d 远端=%d | 模式=%s | Juice=%s | 同步噩梦到队友=%s",
        prefix or "[联机]", tostring(i.netmode), tostring(i.netname),
        tostring(i.server), i.count, i.localN, i.remoteN,
        tostring(Movement.GetMode()), tostring(CFG and CFG.UseJuiceMode),
        tostring(CFG and CFG.SyncNightmareToClients)))
    if not i.server then
        Core.Log("[联机] 当前是【客户端】：3 倍速要生效，房主也必须装本 Mod 并按 F7；"
            .. "客户端单方面改速度会被服务端按原速校验纠正回来。")
    else
        Core.Log("[联机] 当前是【房主/单机】：噩梦模式会同步放大服务端上的队友角色；"
            .. "正常模式完全不碰队友，Shift 冲刺保持原版。")
    end
    return i
end

-- 排错用：把角色体力/速度字段打进控制台
function Movement.Dump()
    Movement.LogNet("[DUMP]")
    local chars = Core.GetAllCharacters()
    Core.Log("原版速度基准 = " .. tostring(originalSpeed))
    for i, c in ipairs(chars) do
        local mov = Core.Get(c, "CharacterMovement")
        local k = Core.Address(c)
        Core.Log(string.format(
            "#%d %s [%s] | Stamina=%s IsBurnedOut=%s WalkSpeed=%s MaxWalkSpeed=%s 基准=%s 放大值=%s Sprint=%s Accel=%s",
            i, Core.ShortName(c),
            Core.IsLocalCharacter(c) and "本地" or "远端",
            tostring(Core.Get(c, "Stamina")),
            tostring(Core.Get(c, "IsBurnedOut")),
            tostring(Core.Get(c, "WalkSpeed")),
            Core.Valid(mov) and tostring(Core.Get(mov, "MaxWalkSpeed")) or "n/a",
            k and tostring(baseSpeed[k]) or "n/a",
            k and tostring(applied[k]) or "n/a",
            Core.Valid(mov) and tostring(Core.Get(mov, "bIsSprinting")) or "n/a",
            Core.Valid(mov) and tostring(Core.Get(mov, "MaxAcceleration")) or "n/a"))
    end
end

return Movement
