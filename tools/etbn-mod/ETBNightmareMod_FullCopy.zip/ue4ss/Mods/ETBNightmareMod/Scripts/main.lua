--[[
    ETBNightmareMod  |  Escape the Backrooms (Steam / UE4)
    ===============================================================
    功能：
      · 每关随机出现可击杀实体的手枪（数量与出现时机均随机）
      · 所有玩家跑步速度：正常模式（原版） / 噩梦模式（3 倍）
      · 所有玩家无限体力
    依赖：UE4SS fork for Escape the Backrooms (Nexus mod 138, v1.3.0+)
    作者：WorkBuddy
--]]

local okCore, Core = pcall(require, "core")
if not okCore or type(Core) ~= "table" then
    print("[ETBNightmare] 致命错误：UEHelpers 不可用，请确认已安装 ETB 专用 UE4SS fork\n")
    return
end

local okCfg, initialCfg = pcall(require, "config")
local CFG = (okCfg and type(initialCfg) == "table") and initialCfg or {}

-- 配置缺项兜底，避免用户删掉某行后整个 Mod 报错
local DEFAULTS = {
    SpeedMode = "normal", NightmareMultiplier = 3.0, BoostAcceleration = true,
    InfiniteStamina = true, StaminaCap = 45.0, UseJuiceMode = false,
    SyncNightmareToClients = false,
    PistolItemName = "flaregun", PistolsPerLevelMin = 1, PistolsPerLevelMax = 3,
    SpawnDelayMinSec = 3, SpawnDelayMaxSec = 20, GivePistolToHostOnSpawn = false,
    KillMode = "trigger", TriggerKey = "G", TriggerThrottleMs = 200,
    RequirePistol = true, RequirePistolFallback = true,
    KillRange = 50000.0, AimIntervalMs = 200,
    -- 旧 config.lua 没有这一项时也必须带上保护，否则交互道具仍会被误杀
    NeverKillPatterns = {
        "lock", "window", "picker", "door", "frame", "glass", "mirror",
        "button", "lever", "switch", "valve", "keypad", "panel", "console",
        "terminal", "generator", "elevator", "ladder", "vent", "handle",
        "knob", "wheel", "pad", "combination", "puzzle", "code", "hinge",
        "gate", "interact", "pickup", "item", "key", "note", "paper",
        "flashlight", "battery", "prop", "tool", "inventory", "chest",
        "crate", "cabinet", "drawer", "shelf", "table", "box", "barrel",
        "pipe", "phone", "radio", "tv", "screen", "monitor", "clock",
        "sign", "poster", "lamp", "speaker", "camera", "projector",
        "decor", "furniture", "bacteria_zone", "bacteria_roompoint",
    },
    KillAnyNonPlayerPawn = true, PenetrateScenery = true, MaxPenetration = 6,
    AlwaysLogHit = true, LogPenetrationHits = false,
    TickIntervalMs = 100, CharacterCacheMs = 500, FrameHookThrottleMs = 100,
    Debug = false,
    -- 皮肤包缺项兜底（老 config.lua 没这些项时仍能正常工作）
    -- ★ 崩溃修复后的安全默认：off + 不自动应用 + 安全模式开 + 小预算
    SkinPreset = "off", SkinApplyOnLevel = false, SkinPropsEnabled = true,
    SkinSafeMode = true, SkinLevelGraceMs = 4000,
    SkinSceneEnabled = false, SkinAllowEngineFallback = false,
    SkinSceneTint = false, SkinSceneRatio = 0.25, SkinMaxActors = 150,
    SkinMaxScene = 60, SkinMaxProps = 12, SkinBudgetMs = 150,
    -- config.lua 缺项时的核心兜底（正常安装不会用到）
    EntityPatterns = {
        "bp_entity", "entity974", "smiler", "clown", "hound", "faceling",
        "partygoer", "partypooper", "partyhost", "darkparty",
        "skinstealer", "wretch", "creature_1", "handmonster",
        "bp_roaming", "monster", "plasticclown", "stalker",
        "bp_wire", "deathmoth", "cheatparty", "hidingparty", "roamingparty",
        "scratcher", "cave_moth", "bp_mothjelly",
        "bacteria_bp", "bacteria_roaming", "roamingbacteria", "bacteriajumpscare",
    },
    SafePatterns = {
        "bpcharacter_demo", "player", "droppeditem", "itemspawner",
        "staticmeshactor", "chair", "wall", "floor", "painting", "rug",
        "lock", "window", "picker", "door", "frame", "button", "prop",
        "bacteria_zone", "bacteria_roompoint",
    },
}
for k, v in pairs(DEFAULTS) do
    if CFG[k] == nil then CFG[k] = v end
end

local Movement = require("movement")
local Pistol   = require("pistol")
local WorldMod = require("world")
local Skins    = require("skins")

math.randomseed(os.time() + (os.clock() * 1000) % 100000)

local hooksInstalled = false

---------------------------------------------------------------
-- 配置热重载
---------------------------------------------------------------
local function ReloadConfig()
    package.loaded["config"] = nil
    local ok, fresh = pcall(require, "config")
    if not ok or type(fresh) ~= "table" then
        Core.Warn("config.lua 读取失败，继续沿用当前配置: " .. tostring(fresh))
        return false
    end
    CFG = fresh
    for k, v in pairs(DEFAULTS) do
        if CFG[k] == nil then CFG[k] = v end
    end
    Movement.Reload(CFG)
    Pistol.Reload(CFG)
    WorldMod.Reload(CFG)
    Skins.Reload(CFG)
    if Core.SetCharacterCacheMs then Core.Safe(Core.SetCharacterCacheMs, CFG.CharacterCacheMs) end
    if Core.InvalidateCache then Core.Safe(Core.InvalidateCache) end
    Core.Log("配置已重载")
    return true
end

---------------------------------------------------------------
-- 每帧 Hook（增强用；失败也不影响主循环）
---------------------------------------------------------------
local hookRetryAt = 0
local hookTries = 0

local function TryInstallFrameHook()
    if hooksInstalled then return true end
    if type(RegisterHook) ~= "function" then return false end

    -- ★ 帧率修复：钩子装不上时（BP 类还没进内存）旧版会在每个主循环 tick
    -- 都做一次 FindFirstOf 全对象扫描 + RegisterHook 尝试。
    -- 现在最多试 12 次、每次至少间隔 5 秒。
    local t = os.clock()
    if hookTries >= 12 or t < hookRetryAt then return false end
    hookRetryAt = t + 5.0
    hookTries = hookTries + 1

    -- BP 类必须先存在于内存，否则 RegisterHook 会静默失败
    local inst = nil
    if type(FindFirstOf) == "function" then
        local ok, r = pcall(FindFirstOf, "BPCharacter_Demo_C")
        if ok then inst = r end
    end
    if not Core.Valid(inst) then return false end

    local ok, err = pcall(function()
        RegisterHook(Core.PLAYER_CLASS .. ":CheckForwardMovementInput",
            Movement.OnCharacterTick)
    end)
    if ok then
        hooksInstalled = true
        Core.Log("已绑定每帧移动钩子（速度更跟手）")
    else
        Core.Debug("每帧钩子暂不可用: " .. tostring(err), CFG)
    end
    return ok
end

---------------------------------------------------------------
-- 控制台命令
---------------------------------------------------------------
local HELP = [[
ETBNightmareMod 命令：
  etbn help                 显示本帮助
  etbn status               查看当前模式 / 本关已刷手枪数
  etbn mode normal          普通无限体力奔跑模式（原版速度 + 无限体力）
  etbn mode sprint          同上，别名
  etbn mode nightmare       噩梦模式（3 倍跑步速度）
  etbn spawn [数量]          立刻刷新手枪（默认按配置随机数量）
  etbn gun                  直接给自己发一把手枪
  etbn shoot                向准星发射一次致命射线
  etbn scan [all]           列出场上 Pawn 类名 + 判定原因；all 额外扫全场 Actor
  etbn hits                 最近 12 次射线命中了什么（排查"瞄了却打不死"）
  etbn protect <类名>        立刻临时保护某类名不被销毁（本次游戏有效）
  etbn entity <关键词>       临时补进实体白名单（排查"打不死的怪"）
  etbn killall              手动清掉场上所有实体（漏网兜底）
  etbn killmode trigger|aim 切换扳机模式 / 准星自动模式
  etbn debug on|off         开关详细日志
  etbn reload               重新读取 config.lua
  etbn dump                 输出角色体力/速度字段（排错用）
  etbn net                  显示本机是房主还是客户端、联机速度配对提示
  etbn perf                 查看缓存命中率 / 扫描次数 / 当前频率（帧率排错）
  etbn tick 50..1000        即时调整主循环间隔（毫秒，越大越省性能）
  etbn fixspeed             应急：立刻把速度拉回原版并切到正常模式
  etbn skin list            列出全部场景 / 实体皮肤（圣诞主题）
  etbn skin <预设>          切换皮肤 christmas / frost / candy / gold / off
  etbn skin apply           重新应用当前皮肤（换关后手动补一次）
  etbn skin status          查看皮肤统计与资产加载情况
  etbn skin props on|off    开关拐杖糖 / 星星 / 彩球装饰植入
  etbn skin scene on|off    开关场景染色（默认关，防止墙面变灰）
  etbn skin assets          逐个列出游戏内圣诞资产是否能加载
  etbn skin safe on|off     安全模式（默认开；关掉才允许换关自动重套）
  etbn sync on|off          全房 3 倍速同步（默认关，避免队友跑不动）
  etbn_shoot                单独命令，可用 fork 的 bind 绑到任意按键

热键：
  G      手枪扳机（向准星发射致命射线）—— 已由 F 改成 G
  F6     普通无限体力奔跑模式（原版速度 + 无限体力锁满）
  F7     噩梦模式（3 倍跑步速度）
  F8     循环皮肤：原版 -> 圣诞经典 -> 冰雪奇境 -> 糖果工坊 -> 金色庆典

★ F 是游戏原生「交互 / 开门 / 拾取」键。旧版把 F 当扳机，按 F 开锁、
  开窗户时 Mod 会同时开枪，把交互道具当成实体打没 —— 这就是「碰到
  某样东西它自动消失」。现在默认 G，且交互物有绝对保护名单。
  遇到新的误杀：etbn scan 查类名，etbn protect <类名> 立刻保护，
  再把类名写进 config.lua 的 NeverKillPatterns 永久生效。

联机速度规则（2026-11-10 修正）：
  ★ 默认【房主开噩梦只影响自己】，绝不写队友的速度 / 加速度。
    旧版房主单方面同步放大会让没按 F7 的队友被服务端反复拉回、跑不起来。
  想全房 3 倍速：所有玩家先各自按 F7，再由房主输入 etbn sync on；
    用完 etbn sync off 关掉。正常模式（F6）永远不碰队友。
  F6 / etbn fixspeed 只清队友残留的 Juice 状态，不再写任何速度字段。

皮肤说明（场景 + 实体换肤）：
  素材全部来自游戏本体自带的圣诞/冬季资产（拐杖糖、雪天使、暖光、
  星星、彩球），运行时换材质 / 换模型；不改碰撞体，不影响手枪击杀。
  派对客有专属皮肤；etbn skin off 一键还原全部原版外观。
  ★ 场景染色默认关闭：UE4SS 加载不到游戏内材质时，旧版会降级成灰色
    引擎材质，把墙面刷成「一半灰一半原版」。现在加载失败就保持原版。
  ★★ 稳定优先（2026-11-10 崩溃修复）：默认 SkinPreset=off，
    换关 / 启动时【完全不自动跑皮肤】。旧版每次换关 +1.5 秒就做全场
    Actor 扫描 + 同步 LoadAsset，撞上 UE4 关卡加载期，两次崩溃的调用栈
    都是 UE4SS Lua 链上的 ACCESS_VIOLATION。
    想要皮肤：进关后等几秒，手动 etbn skin christmas 或按 F8；
    换关后 4 秒内会拒绝应用，等稳定再 etbn skin apply。
    本版也不再主动 LoadAsset，只读内存里已加载的对象（多数 MISS，
    对应物件保持原版外观，属正常现象）。
  材质不会联机同步，每个玩家都要装本 Mod 并各自开启才看得到。
  皮肤只在你手动切换时执行一次，不进主循环，不额外掉帧。
]]

---------------------------------------------------------------
-- F6「普通无限体力奔跑模式」= 原版速度 + 无限体力锁满。
-- ForceRestore 无条件写回原版速度（解掉 3x/9x 残留），
-- EnableInfiniteSprint 强制重新打开无限体力并立刻对所有角色钉满。
---------------------------------------------------------------
local function GoNormal()
    local n, base = Movement.ForceRestore()
    Movement.EnableInfiniteSprint()
    Core.Log(string.format(
        "模式 -> 普通无限体力奔跑（原版速度 + 无限体力）| 已处理 %s 个角色 | 原版基准 %s",
        tostring(n or 0), tostring(base)))
    if Core.IsServerStrict() then
        Core.Log("房主端：已清除队友角色残留的 Juice 状态；速度字段一个都没写，"
            .. "对方 Shift 冲刺由游戏自己控制")
    end
    -- 200ms 后再兜一次：游戏的 sprint 状态机可能在下一帧改回去
    Core.Delay(200, function()
        Core.Safe(Movement.ForceRestore)
        Core.Safe(Movement.EnableInfiniteSprint)
    end)
end

local function GoNightmare()
    Movement.SetMode("nightmare")
    Core.Log("速度模式 -> nightmare (x" .. tostring(CFG.NightmareMultiplier) .. ")")
    if CFG.SyncNightmareToClients then
        Core.Log("[联机] 全房同步已打开：请确认所有玩家都按了 F7，"
            .. "否则没按的队友会被服务端拉回、跑不动。关闭用 etbn sync off")
    elseif Core.IsServerStrict() then
        Core.Log("[联机] 房主默认只加速自己，不碰队友（避免对方跑不动）；"
            .. "要全房 3 倍速：所有人先按 F7，房主再 etbn sync on")
    else
        Core.Log("[联机] 你是客户端：本地 3 倍速可能被服务端按原速纠正；"
            .. "让房主也按 F7，全员按完 F7 后由房主输入 etbn sync on")
    end
end

local function Dispatch(FullCommand, Parameters, Ar)
    -- 让 Core.Log 同时回显到游戏内控制台（UE4SS 的 print 只写日志文件）
    Core.OutputDevice = Ar
    local sub = string.lower(tostring(Parameters[1] or "help"))
    local arg = tostring(Parameters[2] or "")

    if sub == "help" then
        Core.Log(HELP)

    elseif sub == "mode" then
        if arg == "normal" or arg == "sprint" then
            GoNormal()
        elseif arg == "nightmare" then
            GoNightmare()
        else
            Core.Log("用法: etbn mode normal | sprint | nightmare")
        end

    elseif sub == "fixspeed" then
        GoNormal()
        Core.Log("已回到普通无限体力奔跑模式。若仍感觉异常，重启游戏即可彻底重置（速度不会跨进程保留）。")

    elseif sub == "spawn" then
        local n = tonumber(arg)
        if not n then
            local lo = tonumber(CFG.PistolsPerLevelMin) or 1
            local hi = tonumber(CFG.PistolsPerLevelMax) or 3
            if hi < lo then hi = lo end
            n = math.random(lo, hi)
        end
        Pistol.Spawn(n)

    elseif sub == "gun" then
        Pistol.GiveToLocal()

    elseif sub == "shoot" then
        Pistol.Shoot()

    elseif sub == "scan" or sub == "entities" then
        Pistol.Scan(arg == "all")

    elseif sub == "hits" then
        Pistol.DumpHits()

    elseif sub == "killall" then
        Pistol.KillAll()

    elseif sub == "protect" then
        local cls = arg:lower()
        if cls ~= "" and Pistol.ProtectClass(cls) then
            Core.Log("已临时保护类名: " .. cls
                .. "（本次游戏有效；永久生效请写进 config.lua 的 NeverKillPatterns）")
        else
            Core.Log("用法: etbn protect <类名>   例如 etbn protect bp_windowpicker_c")
        end

    elseif sub == "entity" then
        local pat = arg:lower()
        if pat ~= "" and Pistol.AddEntityPattern(pat) then
            Core.Log("已临时加入实体白名单: " .. pat
                .. "（本次游戏有效；永久生效请写进 config.lua 的 EntityPatterns）")
        else
            Core.Log("用法: etbn entity <关键词>   例如 etbn entity scratcher")
        end

    elseif sub == "killmode" then
        if arg == "trigger" or arg == "aim" then
            CFG.KillMode = arg
            Core.Log("击杀模式 -> " .. arg)
        else
            Core.Log("用法: etbn killmode trigger | aim")
        end

    elseif sub == "debug" then
        CFG.Debug = (arg == "on" or arg == "1" or arg == "true")
        Core.Log("Debug -> " .. tostring(CFG.Debug))

    elseif sub == "reload" then
        ReloadConfig()

    elseif sub == "dump" then
        Movement.Dump()

    elseif sub == "net" then
        Movement.LogNet("[联机]")
        Core.Log("[联机] 排查顺序：两边都 etbn status 确认同一模式 -> 两边都 etbn dump "
            .. "看 IsBurnedOut / MaxWalkSpeed -> 房主按一次 F6 再按 F7")

    elseif sub == "perf" then
        local p = Core.PerfStats and Core.Safe(Core.PerfStats) or {}
        local scans = tonumber(p.scans) or 0
        local hits = tonumber(p.charHits) or 0
        local total = scans + hits
        local tick = tonumber(CFG.TickIntervalMs) or 100
        Core.Log(string.format(
            "[性能] 主循环=%dms (%dHz) | 每帧钩子节流=%dms | 角色缓存=%dms | 全对象扫描=%d 次 | 缓存命中=%d 次 | 命中率=%.1f%%",
            tick, math.floor(1000 / math.max(1, tick)),
            tonumber(CFG.FrameHookThrottleMs) or 100,
            math.floor((tonumber(p.charsTTL) or 0.5) * 1000),
            scans, hits, total > 0 and (100.0 * hits / total) or 0.0))
        Core.Log("[性能] 每帧钩子=" .. tostring(hooksInstalled)
            .. " | 穿透日志=" .. tostring(CFG.LogPenetrationHits)
            .. " | 击杀模式=" .. tostring(CFG.KillMode)
            .. " | 安装尝试=" .. tostring(hookTries))
        Core.Log("[性能] 还卡就输入 etbn tick 150 / 200（立即生效）；"
            .. "或把 config.lua 的 TickIntervalMs、FrameHookThrottleMs 调大后 etbn reload")

    elseif sub == "tick" then
        local ms = tonumber(arg)
        if ms and ms >= 25 and ms <= 1000 then
            CFG.TickIntervalMs = ms
            Core.Log(string.format("主循环间隔 -> %dms (%dHz)，立即生效，无需重启",
                ms, math.floor(1000 / ms)))
        else
            Core.Log("用法: etbn tick 50..1000  （当前 " .. tostring(CFG.TickIntervalMs)
                .. "ms；数值越大越省性能，速度/体力刷新越慢）")
        end

    elseif sub == "sync" then
        local v = arg:lower()
        if v == "on" or v == "1" or v == "true" then
            CFG.SyncNightmareToClients = true
            Core.Log("[联机] 全房 3 倍速同步 -> 开。前提：所有玩家都已按 F7；"
                .. "否则没按的人会被服务端拉回、跑不动。关闭用 etbn sync off")
        elseif v == "off" or v == "0" or v == "false" then
            CFG.SyncNightmareToClients = false
            Core.Log("[联机] 全房 3 倍速同步 -> 关（默认安全）。"
                .. "房主按一次 F6 可撤销队友身上残留的放大值；速度字段不再写队友")
        else
            Core.Log("用法: etbn sync on|off   （当前="
                .. tostring(CFG.SyncNightmareToClients) .. "）")
        end

    elseif sub == "skin" or sub == "skins" then
        local a = arg:lower()
        if a == "" or a == "list" or a == "help" then
            Skins.List()
        elseif a == "status" then
            Skins.Status()
        elseif a == "apply" or a == "refresh" then
            Skins.Apply(Skins.Current(), true)
        elseif a == "assets" then
            Skins.Assets()
        elseif a == "scene" then
            local v = string.lower(tostring(Parameters[3] or ""))
            if v == "on" or v == "off" then
                Skins.SetScene(v == "on")
                Core.Log("[皮肤] 场景染色 -> " .. v
                    .. "（关闭时墙面永远保持原版；开启前建议先 etbn skin assets）"
                    .. "；输入 etbn skin apply 让改动生效")
            else
                Core.Log("用法: etbn skin scene on|off")
            end
        elseif a == "fallback" then
            local v = string.lower(tostring(Parameters[3] or ""))
            if v == "on" or v == "off" then
                Skins.SetFallback(v == "on")
                Core.Log("[皮肤] 引擎灰材质兜底 -> " .. v
                    .. "（默认 off：资产加载失败就保持原版，不会把墙刷灰）")
            else
                Core.Log("用法: etbn skin fallback on|off")
            end
        elseif a == "props" then
            local v = string.lower(tostring(Parameters[3] or ""))
            if v == "on" or v == "off" then
                CFG.SkinPropsEnabled = (v == "on")
                Core.Log("[皮肤] 装饰植入 -> " .. v .. "；输入 etbn skin apply 让改动生效")
            else
                Core.Log("用法: etbn skin props on|off")
            end
        elseif a == "safe" then
            local v = string.lower(tostring(Parameters[3] or ""))
            if v == "on" or v == "off" then
                Skins.SetSafeMode(v == "on")
                Core.Log("[皮肤] 安全模式 -> " .. v
                    .. "（默认 on：启动/换关不自动应用、换关后 4 秒宽限、"
                    .. "不主动 LoadAsset；off 会重新允许换关自动重套，"
                    .. "有崩溃风险，不建议关）")
            else
                Core.Log("用法: etbn skin safe on|off")
            end
        else
            Skins.Apply(a, true)
        end

    elseif sub == "level" then
        WorldMod.ForceFire("manual")

    elseif sub == "status" then
        local ni = Movement.NetInfo()
        Core.Log(string.format(
            "模式=%s | 倍率=%.1f | 无限体力=%s | Juice=%s | 同步噩梦到队友=%s | Pawn兜底=%s | 穿透=%s | 击杀模式=%s | 本关手枪=%d | 每帧钩子=%s",
            tostring(CFG.SpeedMode), tonumber(CFG.NightmareMultiplier) or 3.0,
            tostring(CFG.InfiniteStamina), tostring(CFG.UseJuiceMode),
            tostring(CFG.SyncNightmareToClients), tostring(CFG.KillAnyNonPlayerPawn),
            tostring(CFG.PenetrateScenery), tostring(CFG.KillMode),
            Pistol.SpawnedCount(), tostring(hooksInstalled)))
        Core.Log(string.format(
            "联机: NetMode=%s (%s) | 服务端=%s | 角色 本地%d/远端%d —— 详情输入 etbn net",
            tostring(ni.netmode), tostring(ni.netname), tostring(ni.server),
            ni.localN, ni.remoteN))
        Core.Log(string.format(
            "性能: 主循环=%sms | 钩子节流=%sms | 穿透日志=%s | 每帧钩子=%s —— 详情输入 etbn perf",
            tostring(CFG.TickIntervalMs), tostring(CFG.FrameHookThrottleMs),
            tostring(CFG.LogPenetrationHits), tostring(hooksInstalled)))
        Core.Log(string.format(
            "扳机: 键=%s (F 是游戏交互键，勿用) | 节流=%sms | 绝对保护名单=%d 项 | 击杀模式=%s",
            tostring(CFG.TriggerKey), tostring(CFG.TriggerThrottleMs),
            #(CFG.NeverKillPatterns or {}), tostring(CFG.KillMode)))
        local sk = Skins.Stats()
        Core.Log(string.format(
            "皮肤: 预设=%s | 安全模式=%s (防崩溃：不自动应用/不主动加载资产) | 派对客=%d 其它实体=%d 场景=%d (染色%s) 圣诞装饰=%d —— etbn skin status",
            tostring(sk.preset), tostring(CFG.SkinSafeMode ~= false),
            sk.party, sk.entity, sk.scene,
            (CFG.SkinSceneEnabled == true) and "开" or "关", sk.props))
        Core.Log(string.format(
            "联机同步=%s（默认关；全房 3 倍速需所有人先按 F7 再 etbn sync on）"
            .. " | 实体白名单=%d 项 | 绝对保护=%d 项",
            tostring(CFG.SyncNightmareToClients), #(CFG.EntityPatterns or {}),
            #(CFG.NeverKillPatterns or {})))

    else
        Core.Log("未知子命令: " .. sub .. "  —— 输入 etbn help 查看帮助")
    end
    Core.OutputDevice = nil
    return true
end

if type(RegisterConsoleCommandHandler) == "function" then
    pcall(RegisterConsoleCommandHandler, "etbn", Dispatch)
    pcall(RegisterConsoleCommandHandler, "etbn_shoot", function(FullCommand, Parameters, Ar)
        Core.OutputDevice = Ar
        Core.Safe(Pistol.Shoot)
        Core.OutputDevice = nil
        return true
    end)
else
    Core.Warn("控制台命令 API 不可用，请确认 UE4SS 版本")
end

---------------------------------------------------------------
-- 扳机按键
---------------------------------------------------------------
local function BindTrigger()
    if type(RegisterKeyBind) ~= "function" or type(Key) ~= "table" then
        Core.Warn("按键 API 不可用；可用控制台命令 etbn_shoot 射击")
        return
    end
    local key = Key[CFG.TriggerKey or "G"] or Key.G
    if not key then
        Core.Warn("找不到按键 " .. tostring(CFG.TriggerKey) .. "，请用 etbn_shoot")
        return
    end
    -- 按住不连发：降低误触时连续销毁多个物件的概率
    local lastTriggerAt = 0
    local ok = pcall(RegisterKeyBind, key, function()
        local t = os.clock()
        local gap = (tonumber(CFG.TriggerThrottleMs) or 200) / 1000.0
        if (t - lastTriggerAt) < gap then return end
        lastTriggerAt = t
        if type(ExecuteInGameThread) == "function" then
            ExecuteInGameThread(function() Core.Safe(Pistol.Shoot) end)
        else
            Core.Safe(Pistol.Shoot)
        end
    end)
    if ok then
        Core.Log("扳机键已绑定: " .. tostring(CFG.TriggerKey or "G")
            .. "（F 是游戏交互键，请不要用 F 当扳机）")
    else
        Core.Warn("按键绑定失败，可用控制台命令 etbn_shoot")
    end
end

---------------------------------------------------------------
-- 模式切换热键：F6 正常 / F7 噩梦
---------------------------------------------------------------
local function BindModeKeys()
    if type(RegisterKeyBind) ~= "function" or type(Key) ~= "table" then return end
    local bindings = {
        { Key.F6, "normal",    "F6" },
        { Key.F7, "nightmare", "F7" },
    }
    for _, b in ipairs(bindings) do
        local key, mode, label = b[1], b[2], b[3]
        if key then
            local ok = pcall(RegisterKeyBind, key, function()
                local function apply()
                    -- F6 = 普通无限体力奔跑（写回原版速度 + 锁定无限体力）
                    -- F7 = 噩梦 3 倍速
                    if mode == "normal" then GoNormal() else GoNightmare() end
                end
                if type(ExecuteInGameThread) == "function" then
                    ExecuteInGameThread(function() Core.Safe(apply) end)
                else
                    Core.Safe(apply)
                end
            end)
            if ok then Core.Debug("已绑定 " .. label .. " -> " .. mode, CFG) end
        end
    end

    -- F8：循环切换场景 / 实体皮肤（原版 -> 四套圣诞主题 -> 原版）
    if Key.F8 then
        local okF8 = pcall(RegisterKeyBind, Key.F8, function()
            local function cycle()
                local applied, name = Skins.Cycle()
                if applied then
                    Core.Log("[皮肤] F8 -> " .. tostring(name)
                        .. "（etbn skin list 查看全部，etbn skin off 一键还原原版）")
                end
            end
            if type(ExecuteInGameThread) == "function" then
                ExecuteInGameThread(function() Core.Safe(cycle) end)
            else
                Core.Safe(cycle)
            end
        end)
        if okF8 then Core.Debug("已绑定 F8 -> 循环皮肤", CFG) end
    end
end

---------------------------------------------------------------
-- 启动
---------------------------------------------------------------
if Core.SetCharacterCacheMs then Core.Safe(Core.SetCharacterCacheMs, CFG.CharacterCacheMs) end

Movement.Init(CFG)
Pistol.Init(CFG)
Skins.Init(CFG)
WorldMod.Init(CFG, function()
    Pistol.OnLevelLoaded()
    -- 换关后旧 Actor 已销毁，丢弃还原表并延迟重新套皮肤
    Skins.OnLevelLoaded()
end)
BindTrigger()
BindModeKeys()

-- 主循环：调度器固定 50ms 唤醒一次，但真正的处理按 CFG.TickIntervalMs
-- 做软件节流 —— 这样 etbn tick / etbn reload 能即时改频率，不用重启游戏。
-- 【帧率修复】全局查询已全部走 core.lua 的缓存，这里不再有逐 tick 的
-- FindAllOf 全对象扫描；每帧钩子也做了节流。
-- 【联机加载期保护】地图加载 / 无缝换图时 UObject 数量暴涨，
-- 没有本地可控角色时整帧直接跳过（该判断走缓存，几乎零成本），
-- 让游戏线程专心加载；进入关卡后立刻自动恢复全部功能。
local lastTickAt = 0
Core.Loop(50, function()
    if not Core.GetLocalCharacter() then return end
    local t = os.clock()
    local interval = (tonumber(CFG.TickIntervalMs) or 100) / 1000.0
    if (t - lastTickAt) < interval then return end
    lastTickAt = t

    if not hooksInstalled then Core.Safe(TryInstallFrameHook) end
    Core.Safe(Movement.ApplyAll)
    if CFG.KillMode == "aim" then Core.Safe(Pistol.Tick) end
end)

-- 启动 3 秒后做一次自检，把结果打进日志方便排错
Core.Delay(3000, function()
    local n = Core.Safe(Movement.ApplyAll) or 0
    Core.Log(string.format("自检完成：找到 %d 个玩家角色，速度模式=%s，无限体力=%s，Juice=%s",
        n, tostring(CFG.SpeedMode), tostring(CFG.InfiniteStamina), tostring(CFG.UseJuiceMode)))
    Core.Safe(Movement.LogNet, "[自检]")
end)

-- ★★ 崩溃修复：不再在启动后 / 换关后延迟自动应用皮肤。
--    旧版在启动 3.5 秒后、以及换关回调里延迟自动重套皮肤
--    会在关卡加载期做 FindAllOf("Actor") 全场扫描 + LoadAsset 同步加载
--    cooked 资产，正好撞上 UE4 的 LoadMap / GC，两次 Minidump 的调用栈
--    都落在 UE4SS Lua 调用链上（EXCEPTION_ACCESS_VIOLATION）。
--    现在皮肤【只由玩家显式命令 / F8 触发】，且 Skins.Apply 内还有
--    「换关后 4 秒宽限期」与「世界戳还原保护」两道闸。
Core.Log("[皮肤] 默认关闭（稳定优先）。进关几秒后输入 etbn skin christmas "
    .. "或按 F8 手动开启；etbn skin off 随时还原游戏原版外观")

Core.Log("已加载  |  模式=" .. tostring(CFG.SpeedMode) ..
    "  |  F6 普通无限体力奔跑 / F7 噩梦 3 倍速  |  输入 etbn help 查看命令")
Core.Log("联机版：无限体力只作用于本机角色；房主正常模式不碰队友（Shift 冲刺保持原版）；"
    .. "3 倍速需要房主与客户端同开噩梦模式")
Core.Log("扳机键 = " .. tostring(CFG.TriggerKey or "G")
    .. "（F 是游戏交互键，已停用）；交互/场景物件有绝对保护，误杀用 etbn protect 或 etbn scan 排查")
Core.Log("皮肤包: " .. tostring(Skins.Current())
    .. "  |  F8 循环圣诞皮肤 / etbn skin list 查看 / etbn skin off 还原原版外观")
