--[[
    ETBNightmareMod - 场景 / 实体皮肤包（圣诞主题）
    ===============================================================
    目标：给场景换一套统一风格，给实体（尤其是派对客）换新皮肤，
          并往关卡里植入拐杖糖、星星、彩球等圣诞装饰。

    实现方式：运行时给 UMeshComponent 换材质（SetMaterial）、给
    UStaticMeshComponent 换模型（SetStaticMesh）。所有素材都来自
    游戏本体 pak 里自带的 HolidayUpdate / SnowAngel / Club / Hotel
    资产，不引入任何外部贴图或模型，因此离线、联机都能加载。

    技术边界（务必如实告知用户）：
      · 这是「材质级 / 模型级」换肤，不是重绘贴图或新建角色模型。
        真正重绘贴图需要 Unreal Editor 生成 cooked uasset 再打 .pak，
        本机没有编辑器，做不到。
      · 换材质不会改变碰撞体，所以不影响手枪射线击杀判定。
      · 材质不是 replicated 属性：联机时每个玩家都要装本 Mod 并各自
        开启皮肤，才能在自己屏幕上看到效果。
      · 换模型只挑「能读到原模型」的组件，保证随时可完整还原。

    性能：只在「用户显式切换」时执行一次，不进主循环、不进每帧钩子。
          全场遍历有数量上限和时间预算（默认 150ms），零持续帧开销。
    安全：所有 UE 调用都包 pcall；先还原再应用；etbn skin off 一键回原版。

    ★★ 2026-11-10 崩溃修复（重要，别把这些保护删掉）：
      UE4 Minidump 里两次崩溃都是 UE4SS Lua VM 调用链上的
      EXCEPTION_ACCESS_VIOLATION，且都发生在换关后几分钟。旧实现有三处
      关卡加载期的高危行为，本版全部移除：
        1) 换关回调里延迟自动重套皮肤 —— 正好撞上 LoadMap，
           此时 FindAllOf("Actor") 拿到的很多是正在销毁的 UObject。
        2) resolve() 里的 LoadAsset 会【同步加载 cooked 资产】，
           日志里的 "Asset loaded" 就是它；在关卡加载期同步加载资产
           与引擎的异步加载 / GC 抢资源，是访问违例的典型来源。
           现在只查内存里已加载的对象（StaticFindObject / FindObject）。
        3) 旧的全组件扫描把最多 600 个组件 UObject 长期缓存，
           再用 c:GetOwner() 反查 —— 换关后这些指针全部悬空。
           现在只做 Actor 上的字段探测，探测不到就跳过。
      另外：默认 SkinPreset="off"、SkinApplyOnLevel=false、SkinSafeMode=true，
      换关后 4 秒内拒绝应用皮肤。皮肤只在你手动输入命令 / 按 F8 时执行。
--]]

local Core = require("core")

local Skins = {}

local CFG = nil
local currentPreset = "off"
local originals = {}                 -- 还原表：{ comp, slot, material, mesh, kind, world }
local assetCache = {}                 -- path -> UObject / false（false = 加载失败）
local stats = { entity = 0, party = 0, scene = 0, props = 0, skipped = 0,
                failed = 0, assets = 0, unrestorable = 0 }

-- 崩溃防护：世界戳 + 换关时间戳
-- UE4SS 的 Core.Valid() 只判断指针非空，【不判断 UObject 是否已被 GC】。
-- 换关后旧 Actor / 材质 / 模型的指针仍非 null，直接拿去调 SetMaterial
-- 就会 EXCEPTION_ACCESS_VIOLATION。所以每条还原记录都记下当时的 UWorld
-- 地址，还原时地址不一致就整条丢弃。
local lastLevelAt = 0

local function worldId()
    local ok, w = pcall(function() return Core.GetWorld() end)
    if not ok or not w then return nil end
    local ok2, a = pcall(function() return Core.Address(w) end)
    return ok2 and a or nil
end

---------------------------------------------------------------
-- 1) 素材表
--    路径由 tools/extract_pak_index.py 解析 Full Directory Index 后
--    重建得到，均为游戏本体实有的 /Game/... 资产。
---------------------------------------------------------------
local ASSETS = {
    -- 圣诞 / 冬季
    candy_mat  = "/Game/Club/InteriorProps/Materials/M_CandyCan01",         -- 拐杖糖红白
    candy_mesh = "/Game/Club/InteriorProps/Meshes/SM_CandyCan01",           -- 拐杖糖模型
    light_mat  = "/Game/Club/InteriorProps/Materials/M_CommonLightEmission01", -- 暖光发光
    white_mat  = "/Game/Club/InteriorProps/Materials/M_CommonCeramic01White",
    snow_mat   = "/Game/Effects/Materials/Snow/M_Snow_Blowing_Lit",          -- 吹雪
    snow_body  = "/Game/Entity/SnowAngel/Materials/MI_SnowAngel_Body",       -- 雪天使身体
    snow_wings = "/Game/Entity/SnowAngel/Materials/MI_SnowAngel_Wings",
    snow_eye   = "/Game/Entity/SnowAngel/Materials/MI_SnowAngel_Eye",
    star_mesh  = "/Game/Hotel/MailBoxes/PO_Box_low_Star_low",                -- 星星装饰
    orn_mesh   = "/Game/Hotel/MailBoxes/PO_Box_low_Ornaments_low",           -- 彩球装饰
    simple_mat = "/Game/1_BigAlek/Materials/Masters/M_SimpleColor",          -- 纯色主控
}

-- 引擎内置材质：几乎必然已加载，作为游戏资产加载失败时的保底
local ENGINE = {
    base     = "/Engine/EngineMaterials/DefaultMaterial",
    emissive = "/Engine/EngineMaterials/EmissiveMeshMaterial",
    grid     = "/Engine/EngineMaterials/WorldGridMaterial",
}

---------------------------------------------------------------
-- 2) 皮肤预设
--    party  = 派对客专属皮肤（用户点名要的「派对客新皮肤」）
--    entity = 其它实体的皮肤
--    scene  = 场景点缀材质
--    props  = 循环使用的圣诞装饰模型
---------------------------------------------------------------
local PRESETS = {
    christmas = {
        label = "圣诞经典",
        desc  = "派对客=拐杖糖红白 / 其它实体=雪天使白 / 场景=暖金灯光 + 拐杖糖、星星、彩球",
        party = "candy_mat", entity = "snow_body", scene = "light_mat",
        props = { "candy_mesh", "star_mesh", "orn_mesh" },
        fallback = "emissive",
    },
    frost = {
        label = "冰雪奇境",
        desc  = "派对客=雪翼银白 / 其它实体=雪天使 / 场景=吹雪材质，冷色调",
        party = "snow_wings", entity = "snow_body", scene = "snow_mat",
        props = { "star_mesh", "orn_mesh" },
        fallback = "base",
    },
    candy = {
        label = "糖果工坊",
        desc  = "所有实体统一拐杖糖红白条纹 / 场景=糖果材质，最显眼的一套",
        party = "candy_mat", entity = "candy_mat", scene = "candy_mat",
        props = { "candy_mesh", "orn_mesh" },
        fallback = "grid",
    },
    gold = {
        label = "金色庆典",
        desc  = "派对客=陶瓷金白 / 其它实体=暖光 / 场景=发光材质，偏华丽",
        party = "white_mat", entity = "light_mat", scene = "simple_mat",
        props = { "star_mesh", "orn_mesh" },
        fallback = "emissive",
    },
}

local CYCLE = { "off", "christmas", "frost", "candy", "gold" }

-- 派对客家族（pak 里实有的类名）
local PARTY_PATTERNS = {
    "partygoer", "partyhost", "partypooper", "darkparty", "cheatparty",
    "hidingparty", "roamingparty", "partycrasher",
}

-- 场景里绝对不碰的东西：交互装置、玩家、掉落物、UI 相关
local SKIP_PATTERNS = {
    "bpcharacter_demo", "player", "playercontroller", "gamemode", "gamestate",
    "worldsettings", "droppeditem", "itemspawner", "playerstart",
    "lock", "window", "picker", "door", "keypad", "valve", "button",
    "lever", "switch", "panel", "console", "terminal", "interact",
    "bacteria_zone", "bacteria_roompoint",
}

---------------------------------------------------------------
-- 3) 资产解析：LoadAsset -> StaticFindObject -> FindObject
--    ★ 实机教训（2026-11-10）：这个 UE4SS fork 里游戏内材质基本加载不到
--      （日志 assets=2，全是引擎内置材质）。旧版一失败就降级到灰色
--      DefaultMaterial，把 60 个场景物件刷成灰块 ——「墙面一半灰一半原版」。
--      现在默认「加载失败就保持原版」，绝不擅自降级。
---------------------------------------------------------------
local function valid(obj)
    return Core.Valid(obj)
end

local function resolve(key)
    if not key then return nil end
    local path = ASSETS[key] or ENGINE[key] or key
    if assetCache[path] ~= nil then
        local v = assetCache[path]
        return (v ~= false) and v or nil
    end

    local short = path:match("([^/]+)$") or path
    local obj = nil

    -- ★★ 已移除 LoadAsset：它会在调用线程里【同步加载 cooked 资产】。
    --    旧版每次换关后 1.5 秒自动套皮肤时都会触发，日志里的
    --    "Asset loaded" 就是它；在 UE4 LoadMap 期间同步加载资产，
    --    与引擎异步加载/GC 冲突，是两次 EXCEPTION_ACCESS_VIOLATION 的
    --    主要嫌疑。现在只读内存里【已经加载】的对象，绝不主动加载。
    --    后果：游戏内材质大多查不到 -> 保持原版外观（这本就是安全默认）。

    -- 1) StaticFindObject：完整对象名 / 资产路径 / Class'Path' 三种格式
    if not obj and type(StaticFindObject) == "function" then
        local forms = {
            path .. "." .. short,
            path,
            "Material'" .. path .. "." .. short .. "'",
            "MaterialInstanceConstant'" .. path .. "." .. short .. "'",
            "StaticMesh'" .. path .. "." .. short .. "'",
        }
        for _, f in ipairs(forms) do
            local ok, r = pcall(StaticFindObject, f)
            if ok and valid(r) then
                obj = r
                break
            end
        end
    end

    -- 2) FindObject 按短名兜底（只找已经加载进内存的对象）
    if not obj and type(FindObject) == "function" then
        local classes = { "MaterialInterface", "Material", "StaticMesh", "SkeletalMesh" }
        for _, c in ipairs(classes) do
            local ok, r = pcall(FindObject, c, short)
            if ok and valid(r) then
                obj = r
                break
            end
        end
    end

    if obj then
        assetCache[path] = obj
        stats.assets = stats.assets + 1
    else
        assetCache[path] = false
        stats.failed = stats.failed + 1
    end
    return obj
end

local function materialFor(key, fallbackKey)
    local m = resolve(key)
    if m then return m end
    -- ★ 绝不再把「加载失败」变成一堵灰墙。只有用户显式打开
    --   SkinAllowEngineFallback 才允许用引擎内置材质兜底。
    if CFG.SkinAllowEngineFallback ~= true then return nil end
    return resolve(fallbackKey or "base")
end

-- ★★ 实体（派对客 / 其它实体）专属解析：业务材质加载不到（实机常态，
--   UE4SS 在这个 fork 里读不到未驻留的 cooked 材质）时，回退到引擎
--   内置材质，让实体至少换上「可见的新皮」（发光 / 网格 / 灰），
--   而不是保持原皮、让用户以为 Mod 没生效。
--   场景不进这里 —— 场景大面积染灰正是用户最反感的「灰墙」，严格保持原版。
--   回退顺序优先非灰材质（发光 / 网格），最后才兜底到灰色 DefaultMaterial。
local function materialForEntity(key)
    local m = resolve(key)
    if m then return m end
    for _, k in ipairs({ "emissive", "grid", "base" }) do
        local em = resolve(k)
        if em then return em end
    end
    return nil
end

---------------------------------------------------------------
-- 4) 对象分类
---------------------------------------------------------------
local function className(actor)
    local ok, cls = pcall(function() return actor:GetClass() end)
    if ok and valid(cls) then
        local ok2, n = pcall(function() return cls:GetFName():ToString() end)
        if ok2 and type(n) == "string" then return n:lower() end
    end
    return Core.ShortName(actor)
end

local function matchAny(s, list)
    for _, p in ipairs(list or {}) do
        if type(p) == "string" and p ~= "" and s:find(p, 1, true) then return true end
    end
    return false
end

-- 复用 pistol.lua 的实体判定，保证「皮肤」和「手枪」认的是同一批怪。
-- pistol 不可用时退回自己的白名单 + Pawn 兜底。
local Pistol = nil
do
    local ok, m = pcall(require, "pistol")
    if ok and type(m) == "table" and type(m.IsEntity) == "function" then Pistol = m end
end

local function isEntity(actor, cls)
    if Pistol then
        local ok, yes = pcall(Pistol.IsEntity, actor)
        if ok then return yes == true end
    end
    if matchAny(cls, CFG.EntityPatterns or {}) then return true end
    local pawn = false
    pcall(function()
        pawn = actor:IsA("/Script/Engine.Pawn") == true
            or actor:IsA("/Script/Engine.Character") == true
    end)
    return pawn
end

local function classify(actor)
    if Core.IsPlayerCharacter(actor) then return "skip", "" end
    local cls = className(actor)
    if cls == "" then return "skip", cls end
    if matchAny(cls, SKIP_PATTERNS) then return "skip", cls end
    -- 绝对保护名单同样适用于换肤：不要把锁/窗户染成拐杖糖
    if matchAny(cls, CFG.NeverKillPatterns or {}) then return "skip", cls end
    if isEntity(actor, cls) then
        if matchAny(cls, PARTY_PATTERNS) then return "party", cls end
        return "entity", cls
    end
    return "scene", cls
end

---------------------------------------------------------------
-- 5) 组件访问
---------------------------------------------------------------
local COMPONENT_FIELDS = {
    "Mesh", "SkeletalMeshComponent", "StaticMeshComponent",
    "CharacterMesh0", "BodyMesh", "RootComponent",
}

-- ★★ 2026-11-10 崩溃修复：已【删除】旧的全组件扫描 + 按 owner 反查逻辑。
--    旧版把最多 600 个组件 UObject
--    缓存在 Lua 表里，跨关卡后这些指针全部悬空，再对它们调用 UFunction
--    就是典型的 ACCESS_VIOLATION；而且 400 Actor × 600 组件的 GetOwner
--    反查是每次换关跑满 500ms 预算的元凶。
--    现在只探测 Actor 自身的组件字段，探测不到就安全跳过（保持原版外观）。
local function componentsOf(actor)
    local out, seen = {}, {}
    for _, f in ipairs(COMPONENT_FIELDS) do
        local ok, c = pcall(function() return actor[f] end)
        if ok and valid(c) then
            local id = Core.Address(c)
            if not (id and seen[id]) then
                if id then seen[id] = true end
                out[#out + 1] = c
            end
        end
    end
    return out
end

local function collectActors()
    local out, seen = {}, {}
    local limit = math.max(1, tonumber(CFG.SkinMaxActors) or 400)
    local list = nil
    if type(FindAllOf) == "function" then
        local ok, r = pcall(FindAllOf, "Actor")
        if ok and type(r) == "table" then list = r end
    end
    if not list then return out end
    for _, a in ipairs(list) do
        if #out >= limit then break end
        if valid(a) then
            local id = Core.Address(a)
            if not (id and seen[id]) then
                if id then seen[id] = true end
                out[#out + 1] = a
            end
        end
    end
    return out
end

---------------------------------------------------------------
-- 6) 换材质 / 换模型（都先保存原值，保证可还原）
---------------------------------------------------------------
local function applyMaterial(actor, kind, key, fallbackKey)
    -- 场景严格走 materialFor（MISS 即保持原版，杜绝灰墙）；
    -- 实体（派对客 / 其它实体）走 materialForEntity：业务材质加载不到时
    -- 回退引擎内置材质，让实体至少换上可见新皮，而不是保持原皮。
    local mat = (kind == "scene") and materialFor(key, fallbackKey)
                or materialForEntity(key)
    if not mat then return false end
    for _, comp in ipairs(componentsOf(actor)) do
        -- 读不到原材质也允许换，但记录下来，还原时会尝试置空恢复默认
        local got, orig = pcall(function() return comp:GetMaterial(0) end)
        if not got then orig = nil end
        local ok = pcall(function() comp:SetMaterial(0, mat) end)
        if ok then
            originals[#originals + 1] = {
                comp = comp, slot = 0, material = orig, kind = kind,
                hadOriginal = got and orig ~= nil, world = worldId(),
            }
            if not (got and orig ~= nil) then
                stats.unrestorable = stats.unrestorable + 1
            end
            return true
        end
    end
    return false
end

local function applyProp(actor, preset)
    if CFG.SkinPropsEnabled == false then return false end
    local list = preset.props or {}
    if #list == 0 then return false end
    local key = list[(stats.props % #list) + 1]
    local mesh = resolve(key)
    if not mesh then return false end
    for _, comp in ipairs(componentsOf(actor)) do
        -- 不再依赖 IsA("StaticMeshComponent")（实机里该判定经常返回 false，
        -- 日志里「圣诞装饰=0」就是这么来的）。能读到原模型就说明可换。
        -- ★ 必须能读到原模型才换，否则无法还原，宁可跳过
        local got, orig = pcall(function() return comp:GetStaticMesh() end)
        if got and valid(orig) then
            local ok = pcall(function() comp:SetStaticMesh(mesh) end)
            if ok then
                originals[#originals + 1] = {
                    comp = comp, mesh = orig, kind = "prop", world = worldId(),
                }
                return true
            end
        end
    end
    return false
end

---------------------------------------------------------------
-- 7) 还原 / 应用
---------------------------------------------------------------
function Skins.Restore()
    local n = 0
    local wid = worldId()
    for i = #originals, 1, -1 do
        local r = originals[i]
        -- ★ 跨关卡的旧记录一律丢弃：Core.Valid() 只查指针非空，
        --   换关后旧 UObject 已被 GC，拿去调 UFunction 就是访问违例。
        local sameWorld = (r.world == nil) or (wid ~= nil and r.world == wid)
        if sameWorld and valid(r.comp) then
            if r.kind == "prop" then
                -- 原模型必须仍然有效才写回，绝不把悬空指针交给引擎
                if valid(r.mesh) and pcall(function() r.comp:SetStaticMesh(r.mesh) end) then
                    n = n + 1
                end
            elseif r.material ~= nil and valid(r.material) then
                if pcall(function() r.comp:SetMaterial(r.slot or 0, r.material) end) then
                    n = n + 1
                end
            end
            -- r.material == nil（当初读不到原材质）时【不写空指针】，
            -- 保持现状等换关由引擎自己重建，比冒险调用安全。
        end
        originals[i] = nil
    end
    return n
end

local function resetStats()
    stats.entity, stats.party, stats.scene, stats.props = 0, 0, 0, 0
    stats.skipped, stats.failed, stats.unrestorable = 0, 0, 0
end

function Skins.Apply(name, force)
    name = string.lower(tostring(name or currentPreset or "off"))
    local preset = PRESETS[name]

    -- 先无条件还原，避免连续切换时把「已换过的材质」当成原版存下来
    local restored = Skins.Restore()
    resetStats()

    if name == "off" or name == "original" or name == "none" then
        currentPreset = "off"
        if restored > 0 then
            Core.Log("[皮肤] 已还原游戏原版外观（" .. tostring(restored) .. " 处）")
        else
            Core.Log("[皮肤] 当前为游戏原版外观（未启用皮肤包）")
        end
        return true
    end
    if not preset then
        Core.Log("[皮肤] 未知预设: " .. name .. " —— 输入 etbn skin list 查看可用皮肤")
        return false
    end

    currentPreset = name

    -- ★★ 崩溃防护（2026-11-10）：关卡切换后的宽限期内，绝不做全场扫描。
    --   旧版每次换关 +1.5 秒就自动跑一次 FindAllOf("Actor")，正好撞上
    --   LoadMap 期间 UObject 批量销毁/重建，是两次 ACCESS_VIOLATION 的
    --   触发路径。现在默认 SkinSafeMode=true：只在你手动输入命令 / 按 F8
    --   且关卡已经稳定之后才执行。
    if CFG.SkinSafeMode ~= false then
        local graceSec = (tonumber(CFG.SkinLevelGraceMs) or 4000) / 1000.0
        if lastLevelAt > 0 and (os.time() - lastLevelAt) < graceSec then
            Core.Log("[皮肤] 关卡刚切换，暂不应用（防止加载期访问 UObject 导致崩溃）；"
                .. "请等几秒后输入 etbn skin apply")
            return false
        end
        if not Core.GetLocalCharacter() then
            Core.Log("[皮肤] 还没进入关卡，已记住「" .. preset.label .. "」；"
                .. "进关稳定后输入 etbn skin apply")
            return true
        end
    end

    if not force and not Core.GetLocalCharacter() then
        Core.Log("[皮肤] 已选择「" .. preset.label .. "」，进入关卡后输入 etbn skin apply 应用")
        return true
    end

    local actors = collectActors()
    if #actors == 0 then
        Core.Log("[皮肤] 场上没有可处理的 Actor，进入关卡后输入 etbn skin apply 重试")
        return true
    end

    local t0 = os.clock()
    local maxScene   = math.max(0, tonumber(CFG.SkinMaxScene) or 60)
    local maxProps   = math.max(0, tonumber(CFG.SkinMaxProps) or 12)
    local ratio      = tonumber(CFG.SkinSceneRatio) or 0.25
    if ratio <= 0 then ratio = 0.25 end
    if ratio > 1 then ratio = 1 end
    local step       = math.max(1, math.floor(1 / ratio + 0.5))
    if CFG.SkinSceneTint == true then step = 1 end
    local sceneSeen  = 0
    local budgetMs   = math.max(50, tonumber(CFG.SkinBudgetMs) or 500)

    local processed = 0
    for _, actor in ipairs(actors) do
        processed = processed + 1
        if (os.clock() - t0) * 1000 > budgetMs then
            stats.skipped = #actors - processed + 1
            break
        end
        local kind = classify(actor)
        if kind == "skip" then
            -- 不计数，纯跳过
        elseif kind == "party" or kind == "entity" then
            local key = (kind == "party") and preset.party or preset.entity
            if applyMaterial(actor, kind, key, preset.fallback) then
                stats[kind] = stats[kind] + 1
            else
                stats.failed = stats.failed + 1
            end
        else
            sceneSeen = sceneSeen + 1
            -- ★ 默认完全不给场景换材质：实机里游戏资产加载不到，
            --   旧版把 60 个场景物件降级成灰色 DefaultMaterial，变成
            --   「墙面一半灰一半原版」。只有 etbn skin scene on 才打开。
            if CFG.SkinSceneEnabled == true and stats.scene < maxScene
                and (sceneSeen % step == 0) then
                if applyMaterial(actor, "scene", preset.scene, preset.fallback) then
                    stats.scene = stats.scene + 1
                else
                    stats.failed = stats.failed + 1
                end
            end
            -- 装饰植入独立开关；游戏资产加载不到时 applyProp 会自动跳过
            if stats.props < maxProps and applyProp(actor, preset) then
                stats.props = stats.props + 1
            end
        end
    end

    Core.Log(string.format(
        "[皮肤] %s 已应用 | 派对客=%d 其它实体=%d 场景=%d (染色%s) 圣诞装饰=%d | 资产=%d 失败=%d | 耗时=%dms",
        preset.label, stats.party, stats.entity, stats.scene,
        (CFG.SkinSceneEnabled == true) and "开" or "关",
        stats.props, stats.assets, stats.failed, math.floor((os.clock() - t0) * 1000)))
    if stats.failed > 0 then
        Core.Log("[皮肤] 部分游戏内资产无法加载，这些物件保持原版外观（不再降级成灰块）；"
            .. "输入 etbn skin assets 查看每个资产状态")
    end
    return true
end

---------------------------------------------------------------
-- 8) 对外接口
---------------------------------------------------------------
function Skins.Init(cfg)
    CFG = cfg or {}
    -- ★ 默认 "off"：启动 / 换关时零皮肤调用，把崩溃风险降到最低。
    --   想要圣诞皮肤由玩家在关卡稳定后手动 etbn skin christmas / F8 开启。
    currentPreset = string.lower(tostring(CFG.SkinPreset or "off"))
    if not PRESETS[currentPreset] and currentPreset ~= "off" then
        currentPreset = "off"
    end
    -- 0 = 还没经历过换关；宽限期只在真正的 LoadMap 之后才启动。
    -- 启动阶段靠 Core.GetLocalCharacter() 判断是否已经进关卡。
    lastLevelAt = 0
end

function Skins.Reload(cfg)
    CFG = cfg or CFG or {}
end

function Skins.Current() return currentPreset end

function Skins.IsEnabled() return currentPreset ~= "off" end

function Skins.PresetNames() return CYCLE end

function Skins.List()
    Core.Log("可用皮肤（etbn skin <名字> 切换，F8 循环）：")
    for _, n in ipairs(CYCLE) do
        local p = PRESETS[n]
        if p then
            Core.Log(string.format("  %-10s %s | %s%s", n, p.label, p.desc,
                (n == currentPreset) and "  <== 当前" or ""))
        else
            Core.Log(string.format("  %-10s 游戏原版外观（还原全部材质/模型）%s", n,
                (n == currentPreset) and "  <== 当前" or ""))
        end
    end
    Core.Log("素材全部来自游戏本体自带的圣诞/冬季资产，联机时每人各自开启即可看到效果。")
    Core.Log("★ 默认 off（游戏原版）：稳定优先。想开皮肤请在【进关几秒后】"
        .. "输入 etbn skin christmas 或按 F8。")
    Core.Log("etbn skin off 一键还原 | etbn skin apply 重新应用 | etbn skin status 查看统计")
end

function Skins.Cycle()
    local idx = 1
    for i, n in ipairs(CYCLE) do
        if n == currentPreset then idx = i break end
    end
    local nextName = CYCLE[(idx % #CYCLE) + 1]
    return Skins.Apply(nextName), nextName
end

function Skins.Status()
    local p = PRESETS[currentPreset]
    Core.Log(string.format(
        "[皮肤] 当前=%s (%s) | 派对客=%d 其它实体=%d 场景=%d 圣诞装饰=%d",
        currentPreset, p and p.label or "原版",
        stats.party, stats.entity, stats.scene, stats.props))
    Core.Log(string.format(
        "[皮肤] 已用资产=%d | 失败/不支持=%d | 无法读到原材质=%d（还原时会置空回默认）| 已记录可还原项=%d",
        stats.assets, stats.failed, stats.unrestorable, #originals))
    Core.Log(string.format(
        "[皮肤] 配置: 场景染色=%s | 引擎灰材质兜底=%s | 换关自动=%s | 装饰植入=%s | 上限 Actor=%s 场景=%s 装饰=%s",
        tostring(CFG.SkinSceneEnabled == true),
        tostring(CFG.SkinAllowEngineFallback == true),
        tostring(CFG.SkinApplyOnLevel ~= false), tostring(CFG.SkinPropsEnabled ~= false),
        tostring(CFG.SkinMaxActors), tostring(CFG.SkinMaxScene),
        tostring(CFG.SkinMaxProps)))
    Core.Log(string.format(
        "[皮肤] 安全模式=%s（防崩溃：默认开，禁止换关/启动自动应用）| 换关宽限=%sms | 时间预算=%sms",
        tostring(CFG.SkinSafeMode ~= false), tostring(CFG.SkinLevelGraceMs),
        tostring(CFG.SkinBudgetMs)))
end

-- 诊断：逐个列出游戏内圣诞资产的加载结果。
-- 实机里大多数是 MISS（UE4SS 加载不到未驻留的 cooked 资产），
-- 这种情况下 Mod 会保持原版外观，而不是把墙面刷成灰色。
function Skins.Assets()
    local keys = { "candy_mat", "candy_mesh", "light_mat", "white_mat",
                   "snow_mat", "snow_body", "snow_wings", "snow_eye",
                   "star_mesh", "orn_mesh", "simple_mat" }
    Core.Log("[皮肤] 资产加载状态（OK=可用 / MISS=加载不到，物件保持原版）：")
    for _, k in ipairs(keys) do
        local ok = resolve(k) ~= nil
        Core.Log(string.format("  %-12s %-5s %s", k, ok and "OK" or "MISS",
            tostring(ASSETS[k])))
    end
    Core.Log("[皮肤] 场景染色=" .. tostring(CFG.SkinSceneEnabled == true)
        .. " | 允许引擎灰材质兜底=" .. tostring(CFG.SkinAllowEngineFallback == true))
    Core.Log("[皮肤] MISS 是正常现象：本版只读内存里已加载的对象，"
        .. "不主动 LoadAsset（避免关卡加载期同步加载资产导致崩溃）。")
end

function Skins.SetScene(on)
    CFG.SkinSceneEnabled = (on == true)
    return CFG.SkinSceneEnabled
end

function Skins.SetFallback(on)
    CFG.SkinAllowEngineFallback = (on == true)
    return CFG.SkinAllowEngineFallback
end

-- 高级开关：关掉安全模式才会恢复「换关自动重套」（需同时把
-- SkinApplyOnLevel 设为 true）。默认不要关，这是防崩溃的核心保护。
function Skins.SetSafeMode(on)
    CFG.SkinSafeMode = (on == true)
    if CFG.SkinSafeMode then lastLevelAt = os.time() end
    return CFG.SkinSafeMode
end

-- 换关后旧 Actor / 材质 / 模型已销毁：直接丢弃所有缓存的 UObject 指针。
-- ★★ 绝不在这里调用 Restore()，也【默认不再排任何延迟应用任务】。
--    旧版在换关 1.5 秒后自动重套皮肤 = 在 LoadMap 期间做全场扫描 +
--    同步加载资产，是两次崩溃的直接触发路径。
function Skins.OnLevelLoaded()
    for i = #originals, 1, -1 do originals[i] = nil end
    assetCache = {}
    resetStats()
    lastLevelAt = os.time()

    -- 只有用户【显式】关掉安全模式并打开换关自动应用，才恢复旧行为；
    -- 即便如此也把延迟拉到 6 秒，Apply 里的宽限期守卫仍然生效。
    if currentPreset == "off" or CFG.SkinApplyOnLevel == false
        or CFG.SkinSafeMode ~= false then return end
    Core.Delay(6000, function()
        Core.Safe(Skins.Apply, currentPreset)
    end)
end

function Skins.Stats()
    return {
        preset = currentPreset, party = stats.party, entity = stats.entity,
        scene = stats.scene, props = stats.props, failed = stats.failed,
        assets = stats.assets, records = #originals,
    }
end

return Skins
