--[[
    ETBNightmareMod - 通用工具层
    所有对 Unreal 对象的访问都做防御式包装：某个字段在别的游戏版本里
    不存在时，只记日志、不影响其它功能。
--]]

local UEHelpers = require("UEHelpers")

local Core = {}

local TAG = "[ETBNightmare] "
Core.PLAYER_CLASS = "/Game/Game/BPCharacter_Demo.BPCharacter_Demo_C"
Core.PISTOL_DROP  = "BP_DroppedItem_FlareGun"

-- 控制台命令回调期间由 main.lua 设置，让日志同时回显到游戏内控制台。
-- 回调结束后必须清空，否则 userdata 可能失效（所有调用都包了 pcall）。
Core.OutputDevice = nil

function Core.Log(msg)
    local line = TAG .. tostring(msg)
    print(line .. "\n")
    if Core.OutputDevice then
        pcall(function() Core.OutputDevice:Log(line) end)
    end
end

function Core.Warn(msg)
    print(TAG .. "[WARN] " .. tostring(msg) .. "\n")
end

function Core.Debug(msg, cfg)
    if cfg and cfg.Debug then Core.Log("[DEBUG] " .. tostring(msg)) end
end

function Core.Safe(fn, ...)
    local ok, result = pcall(fn, ...)
    if not ok then
        Core.Warn("调用被跳过: " .. tostring(result))
        return nil
    end
    return result
end

function Core.Valid(obj)
    if obj == nil then return false end
    local ok, res = pcall(function() return obj:IsValid() end)
    return ok and res == true
end

function Core.Name(obj)
    if not Core.Valid(obj) then return "<invalid>" end
    local ok, n = pcall(function() return obj:GetFullName() end)
    if ok and type(n) == "string" then return n end
    return "<unnamed>"
end

-- 只取 FName 短名，比 GetFullName() 便宜得多。
-- 联机加入房间时 BeginPlay 会对成千上万个 Actor 触发；在那个关键路径上
-- 拼完整对象路径会明显拖慢加载，甚至导致客户端加入超时被踢。
function Core.ShortName(obj)
    if obj == nil then return "" end
    -- 不做 Core.Valid() 前置（又是一次 pcall）；pcall 本身已能捕获无效对象。
    -- 关键：失败时绝不回退到 Core.Name()/GetFullName() ——
    -- BeginPlay 钩子在加载期会对成千上万 Actor 触发，拼完整对象路径极慢。
    local ok, n = pcall(function() return obj:GetFName():ToString() end)
    if ok and type(n) == "string" then return n:lower() end
    return ""
end

function Core.Address(obj)
    if not Core.Valid(obj) then return nil end
    local ok, a = pcall(function() return obj:GetAddress() end)
    if ok then return tostring(a) end
    return nil
end

-- 安全读取一个可能不存在的属性
function Core.Get(obj, field)
    if not Core.Valid(obj) then return nil end
    local ok, v = pcall(function() return obj[field] end)
    if ok then return v end
    return nil
end

-- 安全写入一个可能不存在的属性
function Core.Set(obj, field, value)
    if not Core.Valid(obj) then return false end
    local ok, err = pcall(function() obj[field] = value end)
    if not ok and Core.Verbose then
        Core.Warn("写 " .. field .. " 失败: " .. tostring(err))
    end
    return ok
end

-- 取本地玩家控制器（UEHelpers 在 ETB fork 中一定存在）
function Core.GetPlayerController()
    local ok, pc = pcall(function() return UEHelpers.GetPlayerController() end)
    if ok and Core.Valid(pc) then return pc end
    return nil
end

function Core.GetWorld()
    local ok, w = pcall(function() return UEHelpers.GetWorld() end)
    if ok and Core.Valid(w) then return w end
    return nil
end

---------------------------------------------------------------
-- ★ 性能缓存层（帧率修复的核心）
---------------------------------------------------------------
-- UE4SS 的 FindAllOf / UEHelpers.GetWorld() / GetPlayerController()
-- 都要遍历全局 UObject 数组或走 Lua<->C++ 桥接，非常贵。
-- 旧版有三重叠加开销，这正是帧率暴跌的原因：
--   1) 20Hz 主循环 × 2 次 FindAllOf 全对象扫描（角色 + PlayerController）
--   2) 每帧移动钩子 × 每个角色 × IsServerStrict()（HasAuthority 兜底时
--      还要 UEHelpers.GetGameModeBase()）
--   3) 每帧移动钩子 × 每个角色 × IsLocalCharacter()（GetPlayerController
--      + 两次 GetAddress + IsLocallyControlled）
-- 新版把「全局查询」按 UWorld + TTL 缓存；换关由 world.lua 调
-- Core.InvalidateCache() 主动失效，NetMode 变化也能被周期性刷新捕捉。
---------------------------------------------------------------
local cache = {
    chars = nil, charsAt = 0, charsTTL = 0.5,
    localChar = nil, localAddr = nil, localAt = 0, localTTL = 1.0,
    netMode = nil, netAt = 0, netTTL = 2.0,
    server = nil, serverAt = 0, serverTTL = 1.0,
    scans = 0, charHits = 0,
}

local function clock() return os.clock() end

-- 换关 / 进出联机房间时调用：所有缓存立即失效
function Core.InvalidateCache()
    cache.chars = nil
    cache.charsAt = 0
    cache.localChar = nil
    cache.localAddr = nil
    cache.localAt = 0
    cache.netAt = 0
    cache.serverAt = 0
end

function Core.SetCharacterCacheMs(ms)
    local v = tonumber(ms) or 500
    if v < 100 then v = 100 end
    if v > 5000 then v = 5000 end
    cache.charsTTL = v / 1000.0
end

function Core.PerfStats()
    return {
        scans = cache.scans,
        charHits = cache.charHits,
        charsTTL = cache.charsTTL,
        cachedNet = cache.netAt > 0,
        cachedServer = cache.serverAt > 0,
        cachedLocal = cache.localAt > 0,
    }
end

-- 只有房主 / 监听服务器 / 单机负责刷枪，避免联机时每人各刷一份。
-- UWorld.NetMode: 0=单机 1=专用服 2=监听服 3=客户端
function Core.IsAuthority()
    local nm = Core.NetModeValue()
    if nm then return nm ~= 3 end
    local ok, gm = pcall(function() return UEHelpers.GetGameModeBase() end)
    if ok and Core.Valid(gm) then return true end
    -- 两者都探测不到时，按单机/房主处理（可用 etbn debug on 观察）
    return true
end

-- 枚举当前世界里的所有玩家角色（"所有玩家"的关键）
-- 缓存 0.5s：新队友加入最多延迟 0.5s 被识别，换来 40 倍的全扫削减。
function Core.GetAllCharacters()
    local t = clock()
    if cache.chars and cache.charsAt > 0 and (t - cache.charsAt) < cache.charsTTL then
        cache.charHits = cache.charHits + 1
        return cache.chars
    end

    local out, seen = {}, {}

    local function add(c)
        if c == nil or not Core.Valid(c) then return end
        local key = Core.Address(c)
        if key and seen[key] then return end
        if key then seen[key] = true end
        out[#out + 1] = c
    end

    -- 主路径：按蓝图类找实例（联机时服务端能拿到全部角色）。
    -- 这是唯一必需的一次全对象扫描。
    local ok, list = pcall(FindAllOf, "BPCharacter_Demo_C")
    if ok and type(list) == "table" then
        for _, c in ipairs(list) do add(c) end
    end

    -- 只有主路径一个角色都没找到时，才做第二次全扫兜底。
    -- 旧版无条件做这第二次，等于每 50ms 白扫一遍整个 UObject 数组。
    if #out == 0 then
        local ok2, pcs = pcall(FindAllOf, "PlayerController")
        if ok2 and type(pcs) == "table" then
            for _, pc in ipairs(pcs) do
                if Core.Valid(pc) then
                    add(Core.Get(pc, "Character"))
                    add(Core.Get(pc, "Pawn"))
                end
            end
        end
    end

    -- 本地角色从缓存补上（不触发全扫）
    add(Core.GetLocalCharacter())

    cache.chars = out
    cache.charsAt = t
    cache.scans = cache.scans + 1
    return out
end

-- 本地角色缓存 1s；返回 nil 时只用 0.25s，避免加载期反复问 UEHelpers，
-- 同时进关卡后最多 0.25s 就能恢复全部功能。
function Core.GetLocalCharacter()
    local t = clock()
    if cache.localAt > 0 then
        local ttl = cache.localChar and cache.localTTL or 0.25
        if (t - cache.localAt) < ttl then
            if cache.localChar == nil then return nil end
            if Core.Valid(cache.localChar) then return cache.localChar end
        end
    end

    local c = nil
    local pc = Core.GetPlayerController()
    if pc then
        c = Core.Get(pc, "Character") or Core.Get(pc, "Pawn")
        if not Core.Valid(c) then c = nil end
    end
    cache.localChar = c
    cache.localAddr = c and Core.Address(c) or nil
    cache.localAt = t
    return c
end

-- 当前世界的 NetMode 数值：0=单机 1=专用服 2=监听服(房主) 3=客户端
-- 读不到时返回 nil（枚举可能被 UE4SS 包成 userdata，不猜）。
function Core.NetModeValue()
    local t = clock()
    if cache.netAt > 0 and (t - cache.netAt) < cache.netTTL then
        return cache.netMode
    end
    local nm = nil
    local w = Core.GetWorld()
    if w then
        local v = Core.Get(w, "NetMode")
        if type(v) == "number" then nm = v end
    end
    cache.netMode = nm
    cache.netAt = t
    return nm
end

-- ★ 严格的服务端判定，专门给「速度/体力作用域」用。
-- 与 IsAuthority() 的区别：IsAuthority 给刷枪用，探测不到时乐观地当房主
-- （保证单机也能刷枪）；这里探测不到时保守地当客户端 —— 宁可少做事，
-- 也绝不能让客户端越权去改别的玩家的复制角色。
-- 判定结果缓存 1s，避免每帧钩子里的 HasAuthority / GetGameModeBase 兜底。
function Core.IsServerStrict()
    local t = clock()
    if cache.serverAt > 0 and (t - cache.serverAt) < cache.serverTTL then
        return cache.server == true
    end

    local result = false
    local nm = Core.NetModeValue()
    if nm then
        result = (nm ~= 3)
    else
        local decided = false
        local pc = Core.GetPlayerController()
        if pc then
            local ok, has = pcall(function() return pc:HasAuthority() end)
            if ok and type(has) == "boolean" then
                result, decided = has, true
            end
        end
        if not decided then
            -- AGameModeBase 只在服务端有实例
            local ok2, gm = pcall(function() return UEHelpers.GetGameModeBase() end)
            if ok2 and Core.Valid(gm) then result = true end
        end
    end

    cache.server = result
    cache.serverAt = t
    return result
end

-- 这个角色是不是「本机玩家自己控制的角色」。
-- 房主端 GetAllCharacters() 会返回全房角色，必须用它区分本地 / 远端。
-- 缓存本地角色地址后，热路径只需对目标角色做一次 GetAddress；
-- 地址两边都拿到时直接比对返回，不再每帧调 IsLocallyControlled()。
function Core.IsLocalCharacter(actor)
    if actor == nil then return false end
    local lc = Core.GetLocalCharacter()
    if lc ~= nil then
        local b = cache.localAddr
        if not b then
            b = Core.Address(lc)
            cache.localAddr = b
        end
        local a = Core.Address(actor)
        if a and b then return a == b end
    end
    local ok, r = pcall(function() return actor:IsLocallyControlled() end)
    if ok and r == true then return true end
    return false
end

function Core.IsPlayerCharacter(actor)
    if not Core.Valid(actor) then return false end
    local ok, res = pcall(function()
        return actor:IsA(Core.PLAYER_CLASS)
    end)
    if ok and res then return true end
    return Core.Name(actor):lower():find("bpcharacter_demo", 1, true) ~= nil
end

-- 关卡内可作为随机刷新点的 Actor 位置。
-- 按 UWorld 地址缓存：联机时客户端也会调用这段，绝不能在加载期反复全场景遍历。
local spawnCache = { world = nil, points = nil }

function Core.GetSpawnPoints()
    local wid = Core.Address(Core.GetWorld())
    if wid and spawnCache.world == wid and spawnCache.points then
        return spawnCache.points
    end

    local pts = {}
    local ok, actors = pcall(FindAllOf, "Actor")
    if ok and type(actors) == "table" then
        for _, a in ipairs(actors) do
            if Core.Valid(a) then
                local n = Core.ShortName(a)   -- 短名，不拼完整路径
                if n:find("itemspawner", 1, true)
                    or n:find("playerstart", 1, true)
                    or n:find("targetpoint", 1, true)
                    or n:find("roompoint", 1, true) then
                    local ok2, loc = pcall(function() return a:K2_GetActorLocation() end)
                    if ok2 and loc and loc.X then
                        pts[#pts + 1] = { X = loc.X, Y = loc.Y, Z = loc.Z + 40.0 }
                    end
                end
            end
            if #pts >= 16 then break end   -- 16 个点足够随机撒枪，不必扫全场
        end
    end

    if wid then
        spawnCache.world = wid
        spawnCache.points = pts
    end
    return pts
end

-- 在玩家附近随机取一个落点（没有刷新点 Actor 时使用）
function Core.RandomNearPlayer(minR, maxR)
    local c = Core.GetLocalCharacter()
    if not c then return nil end
    local ok, loc = pcall(function() return c:K2_GetActorLocation() end)
    if not ok or not loc or not loc.X then return nil end
    local ang = math.random() * math.pi * 2.0
    local r = minR + math.random() * (maxR - minR)
    return {
        X = loc.X + math.cos(ang) * r,
        Y = loc.Y + math.sin(ang) * r,
        Z = loc.Z + 60.0,
    }
end

-- 兼容不同 UE4SS 版本的延时/循环 API
function Core.Delay(ms, fn)
    if type(ExecuteInGameThreadWithDelay) == "function" then
        return pcall(ExecuteInGameThreadWithDelay, ms, fn)
    elseif type(ExecuteWithDelay) == "function" then
        return pcall(ExecuteWithDelay, ms, fn)
    elseif type(ExecuteInGameThread) == "function" then
        return pcall(ExecuteInGameThread, fn)
    end
    return pcall(fn)
end

function Core.Loop(ms, fn)
    if type(LoopInGameThreadWithDelay) == "function" then
        return pcall(LoopInGameThreadWithDelay, ms, fn)
    elseif type(LoopAsync) == "function" then
        return pcall(LoopAsync, ms, function() pcall(fn) end)
    end
    Core.Warn("当前 UE4SS 没有定时循环 API，部分功能降级为仅在换关时生效")
    return false
end

return Core
