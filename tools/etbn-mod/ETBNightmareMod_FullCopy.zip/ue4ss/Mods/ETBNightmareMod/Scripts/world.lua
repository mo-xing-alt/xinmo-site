--[[
    ETBNightmareMod - 关卡切换检测
    ---------------------------------------------------------------
    ETB 的每个 Level 是独立 umap（Level0 / LevelFun / Hotel / CaveLevel ...）。
    三条检测路径互相兜底，确保「每关」都能触发一次随机刷枪：
      1) RegisterLoadMapPostHook       单机/常规换图
      2) RegisterLoadMapMPPostHook    ETB 社区 UE4SS fork 专为联机加的钩子
      3) 每秒比对当前 UWorld 地址    流式加载/子关卡切换
    回到主菜单（GM_MainM / Lobby_GM）时重置状态，避免重复刷枪。
--]]

local Core = require("core")

local World = {}

local CFG = nil
local onLevelChanged = nil
local currentWorldId = nil
local lastFireAt = 0

local function fire(reason)
    -- ★ 换关 / 进出联机房间：所有 UObject 查询缓存必须立刻失效，
    --   否则 NetMode、本地角色、角色列表会沿用上一个世界的旧值。
    if Core.InvalidateCache then Core.InvalidateCache() end

    local w = Core.GetWorld()
    local id = Core.Address(w)
    if id then currentWorldId = id end

    -- 主菜单 / 过场里没有可控制的角色，不要误判成"进入关卡"
    if not Core.GetLocalCharacter() then
        Core.Debug("世界变化但尚未进入关卡，跳过刷枪 (" .. tostring(reason) .. ")", CFG)
        return
    end

    local now = os.clock()
    if now - lastFireAt < 2.0 then return end   -- 多个钩子同时触发时去重
    lastFireAt = now

    Core.Log("检测到进入新关卡 (" .. tostring(reason) .. ")")
    if onLevelChanged then Core.Safe(onLevelChanged) end
end

function World.Init(cfg, callback)
    CFG = cfg
    onLevelChanged = callback

    ---------------------------------------------------------------
    -- 1) 常规换图
    ---------------------------------------------------------------
    if type(RegisterLoadMapPostHook) == "function" then
        local ok = pcall(RegisterLoadMapPostHook, function(Engine, WorldParam)
            local w = WorldParam and WorldParam.get and WorldParam:get() or nil
            currentWorldId = Core.Address(w) or currentWorldId
            Core.Safe(fire, "LoadMap")
        end)
        if not ok then Core.Warn("RegisterLoadMapPostHook 注册失败（将依赖轮询兜底）") end
    end

    ---------------------------------------------------------------
    -- 2) 联机换图（ETB 社区 fork 专有）
    ---------------------------------------------------------------
    if type(RegisterLoadMapMPPostHook) == "function" then
        local ok = pcall(RegisterLoadMapMPPostHook, function(NewURL, NewWorld)
            local w = NewWorld and NewWorld.get and NewWorld:get() or nil
            currentWorldId = Core.Address(w) or currentWorldId
            Core.Safe(fire, "LoadMapMP")
        end)
        if not ok then Core.Warn("RegisterLoadMapMPPostHook 注册失败（将依赖轮询兜底）") end
    else
        Core.Debug("此 UE4SS 版本无 LoadMapMP 钩子，联机换关靠轮询检测", CFG)
    end

    ---------------------------------------------------------------
    -- 3) 主菜单识别 + 角色类就绪（用于安装每帧 Hook）
    ---------------------------------------------------------------
    if type(RegisterBeginPlayPostHook) == "function" then
        -- ★ 帧率修复：这个回调在加载期会对成千上万个 Actor 触发。
        --   节流到最多每 0.25 秒检查一次，主菜单 GameMode 在好几帧里都有
        --   Actor BeginPlay，不会被漏掉；同时把加载期开销砍掉几个数量级。
        local lastBeginPlayCheck = 0
        pcall(RegisterBeginPlayPostHook, function(ContextParam)
            local now = os.clock()
            if now - lastBeginPlayCheck < 0.25 then return end
            lastBeginPlayCheck = now

            local ok, actor = pcall(function() return ContextParam:get() end)
            if not ok or not Core.Valid(actor) then return end
            -- 必须用短名：GetFullName() 的完整路径拼接会把地图加载拖慢，
            -- 可能导致客户端加入超时。和官方 ETBCommandsMod 做法一致。
            local n = Core.ShortName(actor):sub(1, 8)
            if n == "gm_mainm" or n == "lobby_gm" then
                currentWorldId = nil
                lastFireAt = 0
            end
        end)
    end

    ---------------------------------------------------------------
    -- 4) 轮询兜底：世界对象变了就当作换关
    ---------------------------------------------------------------
    Core.Loop(1000, function()
        local w = Core.GetWorld()
        local id = Core.Address(w)
        if id and id ~= currentWorldId then
            currentWorldId = id
            Core.Safe(fire, "WorldChanged")
        end
    end)
end

function World.Reload(cfg)
    CFG = cfg
end

function World.ForceFire(reason)
    lastFireAt = 0
    Core.Safe(fire, reason or "manual")
end

return World
