--[[
    ETBNightmareMod - 每关随机刷新的「致命手枪」
    ---------------------------------------------------------------
    游戏本体只有信号枪 FlareGun（物品 ID: flaregun），所以 Mod 复用它的
    模型/拾取/背包逻辑，再补上一击必杀实体的射线判定。

    · 每关加载后，按配置的随机数量 + 随机延迟，由房主用服务端函数
      DropItem_SERVER 生成，全房可见、可拾取。
    · 生成后随机散落到关卡里的 ItemSpawner / PlayerStart / TargetPoint，
      找不到刷新点就随机撒在玩家附近。
    · 持有手枪时按扳机键（默认 G，F 是游戏交互键会误杀道具）
      => 从相机发出射线，命中实体即刻销毁；交互/场景物件有绝对保护。
--]]

local Core = require("core")
local UEHelpers = require("UEHelpers")

local Pistol = {}

local CFG = nil
local spawnedThisLevel = 0
local lastShootLog = 0

---------------------------------------------------------------
-- 实体判定
---------------------------------------------------------------
-- 只取「类名」，绝不拿完整对象路径去匹配。
-- GetFullName() 形如 "BP_Audience_Chair_C /Game/Maps/Level974.Level974:..."，
-- 若拿整串匹配 "974"，关卡里所有椅子/墙都会被当成实体销毁。
function Pistol.ClassNameOf(actor)
    local ok, cls = pcall(function() return actor:GetClass() end)
    if ok and Core.Valid(cls) then
        local ok2, n = pcall(function() return cls:GetFName():ToString() end)
        if ok2 and type(n) == "string" then return n:lower() end
    end
    local full = Core.Name(actor)
    return ((full:match("^([^%s]+)") or full)):lower()
end

---------------------------------------------------------------
-- ★★ 绝对保护：交互道具 / 场景物件【绝不销毁】
---------------------------------------------------------------
-- 日志里实测被误杀的 bp_lock_5_c（锁）、bp_windowpicker_c（窗户选择器）
-- 都是关卡交互物。它们派生自 Pawn/Character（为了接收输入），
-- 所以旧版 KillAnyNonPlayerPawn 的「任何 Pawn 都算实体」兜底会命中它们。
-- 这个名单优先级高于一切实体判定，连 Pawn 兜底也越不过去。
local runtimeProtect  = {}   -- etbn protect <类名/关键词> 临时保护
local runtimeEntities = {}   -- etbn entity  <类名/关键词> 临时补进实体白名单

function Pistol.ProtectClass(cls)
    if type(cls) ~= "string" or cls == "" then return false end
    runtimeProtect[cls:lower()] = true
    return true
end

-- 严格模式下发现某怪打不死时，不用重启就能把它加进实体白名单
function Pistol.AddEntityPattern(p)
    if type(p) ~= "string" or p == "" then return false end
    runtimeEntities[p:lower()] = true
    return true
end

-- 返回 (是否被保护, 命中的规则)
function Pistol.IsNeverKill(actor)
    if not Core.Valid(actor) then return false, nil end
    local cls = Pistol.ClassNameOf(actor)
    for _, p in ipairs(CFG.NeverKillPatterns or {}) do
        if type(p) == "string" and p ~= "" and cls:find(p, 1, true) then
            return true, "绝对保护:" .. p
        end
    end
    if runtimeProtect[cls] then return true, "临时保护" end
    return false, nil
end

-- 很多交互物派生自 Pawn，光靠 IsA(Pawn) 会把它们全判成实体。
-- 检查常见的交互标记字段：只有交互物才会有这些属性。
local INTERACT_FIELDS = {
    "bCanInteract", "CanInteract", "bInteractable", "Interactable",
    "InteractionComponent", "InteractableComponent", "InteractComponent",
    "InteractionPrompt", "InteractText", "InteractionText", "InteractMessage",
    "InteractDistance", "InteractionRange",
}

local function hasInteractFlag(actor)
    for _, f in ipairs(INTERACT_FIELDS) do
        if Core.Get(actor, f) ~= nil then return true, f end
    end
    return false, nil
end

-- strictOnly = true 表示「没确认玩家真的持有信号枪」的保守模式。
-- ★ 保守模式【不再】禁用 Pawn 兜底：误杀交互物已经由
--   「F->G 换键 + NeverKillPatterns 绝对保护 + 交互组件探测 + 扳机节流」
--   四层挡住；再一刀切禁用兜底会漏杀 bacteria_bp 这类白名单暂未覆盖的
--   真实体（用户实测「不能杀细菌」）。此参数现在只用于日志标注。
-- 返回 (是否实体, 判定原因)，原因会写进日志和 etbn scan，方便定位误杀。
function Pistol.IsEntity(actor, strictOnly)
    if not Core.Valid(actor) then return false, "无效对象" end
    if Core.IsPlayerCharacter(actor) then return false, "玩家角色" end

    local cls = Pistol.ClassNameOf(actor)

    -- 1) 绝对保护：优先级最高
    local protected, rule = Pistol.IsNeverKill(actor)
    if protected then return false, rule end

    -- 2) 真实实体蓝图类名（关键词具体，忽略过短 / 纯数字关键词：
    --    旧配置里的 "974" 曾让 Level974 的椅子、墙、地毯全被当实体销毁）
    --    ★ 2026-11-10：这一步必须排在 SafePatterns 之前。
    --      通用场景名单里有 staticmeshactor / volume / trigger 等词，
    --      某些怪的类名会命中它们（例如非 Pawn 派生的触手团 / 蜘蛛），
    --      旧顺序会让「已经明确写进白名单的真实体」被当成场景物件漏杀。
    for _, p in ipairs(CFG.EntityPatterns or {}) do
        if type(p) == "string" and #p >= 5 and not p:match("^%d+$") then
            if cls:find(p, 1, true) then return true, "实体名单:" .. p end
        end
    end

    -- 2b) 运行时临时补进来的实体关键词（etbn entity），严格模式也认
    for p in pairs(runtimeEntities) do
        if cls:find(p, 1, true) then return true, "临时实体:" .. p end
    end

    -- 3) 场景 / 道具白名单（低于上面的明确实体白名单）
    for _, p in ipairs(CFG.SafePatterns or {}) do
        if cls:find(p, 1, true) then return false, "安全名单:" .. p end
    end

    -- 4) 保守模式：只给日志加个标记，不再禁用兜底
    --    （原因见函数头注释：禁用兜底会漏杀细菌这类白名单外真实体）
    local tag = strictOnly and "(未确认持枪)" or ""

    -- 5) Pawn / Character 类型兜底（覆盖白名单漏掉的新实体）
    if CFG.KillAnyNonPlayerPawn then
        -- 先排掉带交互组件的物件
        local hasInteract, field = hasInteractFlag(actor)
        if hasInteract then return false, "交互组件:" .. tostring(field) end

        local function isA(c)
            local ok, r = pcall(function() return actor:IsA(c) end)
            return ok and r == true
        end
        if isA("/Script/Engine.Pawn") or isA("/Script/Engine.Character")
            or isA("Pawn") or isA("Character") then
            return true, "Pawn 类型兜底" .. tag
        end
        if cls:find("pawn", 1, true) or cls:find("character", 1, true) then
            return true, "类名含 Pawn/Character" .. tag
        end
    end
    return false, "非实体" .. tag
end

function Pistol.Why(actor)
    local isE, reason = Pistol.IsEntity(actor)
    return (isE and "可击杀" or "不击杀") .. " (" .. tostring(reason) .. ")"
end

---------------------------------------------------------------
-- 是否持有手枪
---------------------------------------------------------------
local HELD_FIELDS = {
    "CurrentItemName", "EquippedItemName", "HeldItemName", "ItemInHandName",
    "CurrentItem", "EquippedItem", "HeldItem", "ItemInHand", "CurrentWeapon",
}

local function nameHasPistol(v)
    if v == nil then return false end
    local s
    if type(v) == "string" then
        s = v
    elseif type(v) == "table" then
        s = tostring(v.ItemName or v.Name or "")
    else
        local ok, n = pcall(function() return v:GetFullName() end)
        if not ok then
            ok, n = pcall(function() return v:ToString() end)
        end
        s = (ok and n) or ""
    end
    s = tostring(s):lower()
    return s:find("flaregun", 1, true) ~= nil
        or s:find("pistol", 1, true) ~= nil
        or s:find("flare_gun", 1, true) ~= nil
end

-- 返回 (是否允许射击, 是否【确认】真的持有信号枪)
-- 第二个值很关键：游戏背包字段名各版本不同，检测不到时按
-- RequirePistolFallback 放行，但这时会用「严格模式」只认白名单实体，
-- 避免一个空手玩家按到扳机键就把面前的交互道具（Pawn 派生）打没。
function Pistol.HasPistol()
    if not CFG.RequirePistol then return true, true end

    local chars = Core.GetAllCharacters()
    for _, c in ipairs(chars) do
        for _, f in ipairs(HELD_FIELDS) do
            local v = Core.Get(c, f)
            if v ~= nil and nameHasPistol(v) then return true, true end
            if type(v) == "table" then
                for _, k in ipairs({ "ItemName", "Name", "Item" }) do
                    if nameHasPistol(v[k]) then return true, true end
                end
            end
        end
    end

    if CFG.RequirePistolFallback and spawnedThisLevel > 0 then
        return true, false
    end
    return false, false
end

---------------------------------------------------------------
-- 生成手枪
---------------------------------------------------------------
local function moveActorTo(actor, loc)
    if not Core.Valid(actor) or not loc then return false end
    local ok = pcall(function()
        actor:K2_SetActorLocation({ X = loc.X, Y = loc.Y, Z = loc.Z }, false, {}, true)
    end)
    if not ok then
        -- 部分版本的 K2_SetActorLocation 参数更少
        ok = pcall(function()
            actor:K2_SetActorLocation({ X = loc.X, Y = loc.Y, Z = loc.Z })
        end)
    end
    return ok
end

local function scatter()
    local ok, actors = pcall(FindAllOf, "Actor")
    if not ok or type(actors) ~= "table" then return 0 end

    local pistols = {}
    for _, a in ipairs(actors) do
        if Core.Valid(a) and Core.Name(a):lower():find("droppeditem_flaregun", 1, true) then
            pistols[#pistols + 1] = a
        end
        if #pistols >= 32 then break end
    end

    if #pistols == 0 then
        Core.Debug("未找到刚生成的信号枪掉落物（保持原掉落位置）", CFG)
        return 0
    end

    local points = Core.GetSpawnPoints()
    local moved = 0
    for _, p in ipairs(pistols) do
        local loc
        if #points > 0 then
            loc = points[math.random(1, #points)]
        else
            loc = Core.RandomNearPlayer(300.0, 2500.0)
        end
        if moveActorTo(p, loc) then moved = moved + 1 end
    end
    return moved
end

local function doSpawn(count)
    local c = Core.GetLocalCharacter()
    if not c then
        Core.Warn("还没进入关卡（找不到玩家角色），本次刷枪跳过")
        return
    end

    if not Core.IsAuthority() then
        Core.Debug("非房主，跳过刷枪（由房主统一生成）", CFG)
        return
    end

    local item = FName(CFG.PistolItemName or "flaregun")
    local made = 0
    for _ = 1, count do
        local ok, err = pcall(function() c:DropItem_SERVER(item) end)
        if ok then made = made + 1 else
            Core.Warn("DropItem_SERVER 失败: " .. tostring(err))
            break
        end
    end

    if made == 0 then
        -- 服务端函数不可用时，退化为直接加入背包（至少保证手枪出现）
        Core.Warn("改用 InvAddByName 兜底发放手枪")
        pcall(function() c:InvAddByName(FName(CFG.PistolItemName or "flaregun")) end)
        made = 1
    else
        Core.Safe(scatter)
    end

    spawnedThisLevel = spawnedThisLevel + made
    Core.Log(string.format("本关随机刷新手枪 x%d（含随机位置）", made))

    if CFG.GivePistolToHostOnSpawn then
        pcall(function() c:InvAddByName(FName(CFG.PistolItemName or "flaregun")) end)
    end
end

function Pistol.Spawn(count)
    count = tonumber(count) or 1
    count = math.max(1, math.min(16, math.floor(count)))
    Core.Safe(function()
        if type(ExecuteInGameThread) == "function" then
            ExecuteInGameThread(function() Core.Safe(doSpawn, count) end)
        else
            doSpawn(count)
        end
    end)
end

-- 换关时调用：随机数量 + 随机延迟
function Pistol.OnLevelLoaded()
    spawnedThisLevel = 0
    if not Core.IsAuthority() then return end

    local lo = tonumber(CFG.PistolsPerLevelMin) or 1
    local hi = tonumber(CFG.PistolsPerLevelMax) or 3
    if hi < lo then hi = lo end
    local count = math.random(lo, hi)

    local dlo = tonumber(CFG.SpawnDelayMinSec) or 3
    local dhi = tonumber(CFG.SpawnDelayMaxSec) or 20
    if dhi < dlo then dhi = dlo end
    local delayMs = math.random(dlo, dhi) * 1000

    Core.Log(string.format("新关卡：将在 %d 秒后随机刷新 %d 把手枪", delayMs / 1000, count))
    Core.Delay(delayMs, function()
        Core.Safe(doSpawn, count)
    end)
end

function Pistol.GiveToLocal()
    local c = Core.GetLocalCharacter()
    if not c then
        Core.Log("当前不在关卡内")
        return
    end
    local ok, err = pcall(function()
        c:InvAddByName(FName(CFG.PistolItemName or "flaregun"))
    end)
    Core.Log(ok and "已发放手枪到背包" or ("发放失败: " .. tostring(err)))
end

---------------------------------------------------------------
-- 致命射线
---------------------------------------------------------------
-- 命中日志带节流：aim 模式每 200ms 开一枪，不能刷屏
local function hitLog(msg)
    if not (CFG.AlwaysLogHit or CFG.Debug) then return end
    local now = os.clock()
    if now - lastShootLog < 0.35 then return end
    lastShootLog = now
    Core.Log(msg)
end

-- ★ 帧率修复：穿透日志默认关闭。
-- UE4SS 的 print() 是同步写磁盘，一次开枪最多 6 层穿透，连发时
-- 会在游戏线程里反复做文件 I/O，造成明显卡顿。需要排查实体识别时
-- 把 config.lua 的 LogPenetrationHits 打开即可。
local function penetrationLog(msg)
    if not (CFG.LogPenetrationHits or CFG.Debug) then return end
    hitLog(msg)
end

---------------------------------------------------------------
-- 最近射线命中记录：排查「明明瞄准了却打不死」。
-- 例如细菌如果是 StaticMeshActor / 没有碰撞体，射线可能只打到地面，
-- 这时 etbn hits 会显示清一色 staticmeshactor，一眼就能看出原因。
---------------------------------------------------------------
local recentHits = {}

function Pistol.RecordHit(cls, why)
    recentHits[#recentHits + 1] = tostring(cls) .. " | " .. tostring(why)
    if #recentHits > 12 then table.remove(recentHits, 1) end
end

function Pistol.DumpHits()
    if #recentHits == 0 then
        Core.Log("最近没有射线命中记录 —— 请先按 G 开一枪，再输入 etbn hits")
        return 0
    end
    Core.Log("=== 最近射线命中（最多 12 条，按时间顺序） ===")
    for i, h in ipairs(recentHits) do
        Core.Log(string.format("  %2d. %s", i, h))
    end
    return #recentHits
end

-- 多重降级销毁。不同 UE 版本 / 联机权限下 K2_DestroyActor 不一定真生效，
-- 所以除了销毁，还把这个实体「作废」：隐身、关碰撞、关 Tick、冻结移动。
local function killActor(actor)
    -- 最后一道硬闸：即使以后实体判定被改坏，交互 / 场景物件也绝不销毁。
    -- 控制台 / aim 模式 / killall 都会经过这里。
    local protected, rule = Pistol.IsNeverKill(actor)
    if protected then
        Core.Log("[保护] 已阻止销毁 " .. Pistol.ClassNameOf(actor)
            .. " | " .. tostring(rule))
        return false
    end

    local destroyed = false
    if pcall(function() actor:K2_DestroyActor() end) then
        destroyed = true
    elseif pcall(function() actor:Destroy() end) then
        destroyed = true
    end

    pcall(function() actor:SetActorHiddenInGame(true) end)
    pcall(function() actor:SetActorEnableCollision(false) end)
    pcall(function() actor:SetActorTickEnabled(false) end)
    pcall(function()
        local m = Core.Get(actor, "CharacterMovement")
        if Core.Valid(m) then Core.Set(m, "MaxWalkSpeed", 0) end
    end)
    -- pak 索引里存在 ReceiveDeathEvent / GenerateDeathEvent，部分实体走死亡事件
    pcall(function()
        if actor.ReceiveDeathEvent ~= nil then actor:ReceiveDeathEvent() end
    end)

    if not Core.IsAuthority() then
        hitLog("[提示] 当前是联机客户端：服务端可能把被销毁的实体同步回来，建议由房主射击")
    end
    return destroyed
end

local function GetActorFromHitResult(hr)
    if not hr then return nil end
    local ok, a = pcall(function()
        if type(UnrealVersion) == "table" and UnrealVersion.IsBelow
            and UnrealVersion:IsBelow(5, 0) then
            return hr.Actor:Get()
        end
        if hr.Actor then return hr.Actor:Get() end
        if hr.HitObjectHandle and hr.HitObjectHandle.Actor then
            return hr.HitObjectHandle.Actor:Get()
        end
    end)
    if ok then return a end
    return nil
end

function Pistol.Shoot()
    local allowed, confirmed = Pistol.HasPistol()
    if not allowed then
        Core.Debug("未持有手枪，射击被忽略", CFG)
        return false
    end

    local pc = Core.GetPlayerController()
    if not pc then return false end
    local pawn = Core.Get(pc, "Pawn") or Core.Get(pc, "Character")
    local cam = Core.Get(pc, "PlayerCameraManager")
    if not Core.Valid(pawn) or not Core.Valid(cam) then
        Core.Warn("相机/角色尚未就绪")
        return false
    end

    local okShot, killed = pcall(function()
        local KSL = UEHelpers.GetKismetSystemLibrary()
        local KML = UEHelpers.GetKismetMathLibrary()
        if not Core.Valid(KSL) or not Core.Valid(KML) then return 0 end

        local start = cam:GetCameraLocation()
        local fwd = KML:GetForwardVector(cam:GetCameraRotation())
        local delta = KML:Multiply_VectorInt(fwd, CFG.KillRange or 50000.0)
        local finish = KML:Add_VectorVector(start, delta)

        local traceColor = { R = 0, G = 0, B = 0, A = 0 }
        local ignore = {}
        local tries = 1
        if CFG.PenetrateScenery then
            tries = math.max(1, math.min(12, tonumber(CFG.MaxPenetration) or 6))
        end

        -- ★ 旧版只射一次、只打第一个命中物：隔着玻璃 / 栏杆 / 隐形碰撞体
        --   就永远打不到后面的实体，看起来正是「这怪物杀不掉」。
        --   现在把命中的非实体加入忽略列表继续往深处射，直到命中实体或用尽次数。
        for _ = 1, tries do
            local hit = {}
            local wasHit = KSL:LineTraceSingle(
                pawn, start, finish,
                0, false, ignore, 0, hit, true,
                traceColor, traceColor, 0.0)
            if not wasHit then break end

            local actor = GetActorFromHitResult(hit)
            if not Core.Valid(actor) then break end
            local name = Pistol.ClassNameOf(actor)

            -- 打到自己 / 队友就停，绝不能穿透玩家去打后面的东西
            if Core.IsPlayerCharacter(actor) then
                Pistol.RecordHit(name, "玩家，停止穿透")
                penetrationLog("射线命中玩家，停止穿透: " .. name)
                break
            end

            -- 没确认持枪时启用严格模式：只认白名单实体，不启用 Pawn 兜底，
            -- 这样空手误触扳机也打不掉交互道具。
            local isEntity, why = Pistol.IsEntity(actor, not confirmed)
            if isEntity then
                local destroyed = killActor(actor)
                Pistol.RecordHit(name, "击杀 | 判定=" .. tostring(why)
                    .. " | 销毁=" .. tostring(destroyed))
                Core.Log("手枪击杀实体: " .. name
                    .. " | 判定=" .. tostring(why)
                    .. " | 持枪确认=" .. tostring(confirmed)
                    .. " | 销毁=" .. tostring(destroyed))
                return 1
            end

            Pistol.RecordHit(name, "穿透 | " .. tostring(why))
            penetrationLog("射线穿透非实体: " .. name .. " | " .. tostring(why))
            ignore[#ignore + 1] = actor
            if #ignore >= 12 then break end
        end
        return 0
    end)

    if not okShot then
        Core.Warn("射线检测失败: " .. tostring(killed))
        return false
    end
    return (killed or 0) > 0
end

-- aim 模式：定时自动对准星目标射击
function Pistol.Tick()
    if CFG.KillMode ~= "aim" then return end
    Core.Safe(Pistol.Shoot)
end

---------------------------------------------------------------
-- 排错 / 兜底命令
---------------------------------------------------------------
-- etbn scan：列出场上所有 Pawn 的类名，并标出哪些会被判为实体。
-- 遇到「杀不掉」的实体时，用这个把它的类名找出来，加进 config.lua 的
-- EntityPatterns 即可；默认开启 KillAnyNonPlayerPawn 后大多数都会显示「可击杀」。
function Pistol.Scan(includeAll)
    local found = {}

    local function addActor(a)
        if not Core.Valid(a) then return end
        local cls = Pistol.ClassNameOf(a)
        local e = found[cls]
        if not e then
            e = { n = 0, why = Pistol.Why(a) }
            found[cls] = e
        end
        e.n = e.n + 1
    end

    local ok, actors = pcall(FindAllOf, "Pawn")
    if ok and type(actors) == "table" then
        for _, a in ipairs(actors) do addActor(a) end
    end

    -- etbn scan all：额外扫全场 Actor，但只列「看起来像实体」的类名，
    -- 否则几万个场景物件会把控制台刷爆。用途：细菌这类可能不是 Pawn
    -- 的实体，用这个确认它到底在不在场、真实类名是什么。
    if includeAll then
        local function interesting(cls)
            if cls:find("bacteria", 1, true) or cls:find("microbe", 1, true) then
                return true
            end
            for _, p in ipairs(CFG.EntityPatterns or {}) do
                if type(p) == "string" and #p >= 4 and cls:find(p, 1, true) then
                    return true
                end
            end
            return false
        end
        local ok2, all = pcall(FindAllOf, "Actor")
        if ok2 and type(all) == "table" then
            local checked = 0
            for _, a in ipairs(all) do
                checked = checked + 1
                if checked > 3000 then break end   -- 手动命令，别扫到卡住
                if Core.Valid(a) then
                    local cls = Pistol.ClassNameOf(a)
                    if interesting(cls) and not found[cls] then addActor(a) end
                end
            end
        end
    end

    local keys = {}
    for k in pairs(found) do keys[#keys + 1] = k end
    table.sort(keys)

    Core.Log("=== 场上候选共 " .. #keys .. " 种（含判定原因）"
        .. (includeAll and " [含全场 Actor 扫描]" or " [仅 Pawn]") .. " ===")
    for _, k in ipairs(keys) do
        Core.Log(string.format("  %-40s x%-3d %s",
            k, found[k].n, found[k].why or "?"))
    end
    Core.Log("=== 「实体名单/安全名单」的类名可加进 config.lua 的 EntityPatterns / NeverKillPatterns ===")
    Core.Log("=== 遇到误杀：etbn protect <类名> 可立刻临时保护（本次游戏有效） ===")
    Core.Log("=== 找不到怪：etbn scan all 扫全场 Actor；etbn hits 看准星最近打到了什么 ===")
    return #keys
end

-- etbn killall：手动清掉场上所有能识别的实体（漏网时的兜底）。
-- 只扫 Pawn / Character，不遍历全场景 Actor，避免卡顿。
function Pistol.KillAll()
    local n, seen = 0, {}
    local function sweep(className)
        local ok, list = pcall(FindAllOf, className)
        if not ok or type(list) ~= "table" then return end
        for _, a in ipairs(list) do
            if Core.Valid(a) then
                local k = Core.Address(a)
                -- 严格模式：手动清场也只清「明确白名单实体」，
                -- 避免把整关的交互道具（Pawn 派生）一起清掉。
                if k and not seen[k] and not Core.IsPlayerCharacter(a)
                    and Pistol.IsEntity(a, true) then
                    seen[k] = true
                    Core.Safe(killActor, a)
                    n = n + 1
                    if n >= 64 then return end
                end
            end
        end
    end
    sweep("Pawn")
    sweep("Character")
    Core.Log("手动清场：已处理实体 x" .. n)
    return n
end

function Pistol.Init(cfg)
    CFG = cfg
end

function Pistol.Reload(cfg)
    CFG = cfg
end

function Pistol.SpawnedCount()
    return spawnedThisLevel
end

return Pistol
