--[[
    ETBNightmareMod - 用户配置文件
    ---------------------------------------------------------------
    改完保存后，在游戏控制台输入  etbn reload  即可热重载，无需重启游戏。
    所有配置项都带默认值；不认识的项会被忽略，不会导致 Mod 崩溃。
--]]

local Config = {

    ---------------------------------------------------------------
    -- 1) 跑步速度模式
    --    "normal"    = 普通无限体力奔跑模式（F6）：原版跑步速度 + 无限体力锁满
    --    "nightmare" = 噩梦模式（F7）：跑步速度为原来的 3 倍
    -- 无限体力在两种模式下都生效；按 F6 会强制把它重新打开并立刻钉满体力。
    -- 游戏内也可用  etbn mode normal / etbn mode sprint / etbn mode nightmare  切换。
    ---------------------------------------------------------------
    SpeedMode              = "normal",
    NightmareMultiplier    = 3.0,

    -- 噩梦模式下同步放大加速度，否则 3 倍极速会很难转向（推荐 true）
    BoostAcceleration      = true,

    ---------------------------------------------------------------
    -- 2) 无限体力（只作用于本机自己的角色，不改队友的角色）
    --    InfiniteStamina = true  = 每帧把 Stamina 钉满，保留游戏原生 Shift 冲刺
    --    UseJuiceMode    = false（默认）= 不用游戏原生 Juice 状态
    --    UseJuiceMode    = true  = 用 IsBurnedOut，但社区 juice.lua 证实它会把
    --                      MaxWalkSpeed 锁成 675 且 Shift 不再加速；联机时房主
    --                      写队友角色会复制给对方，把对方冲刺关掉。别开。
    ---------------------------------------------------------------
    InfiniteStamina        = true,
    StaminaCap             = 45.0,
    UseJuiceMode           = false,

    -- ★ 联机关键：UE4 的移动是「服务端权威」。房主单方面把服务端上队友
    --   角色的 MaxWalkSpeed / MaxAcceleration 放大，会让「没同时按 F7」的
    --   队友客户端与服务端移动预测不一致，表现为被反复拉回、跑不起来。
    --   false（默认，安全）= 房主开噩梦只影响自己，绝不碰队友角色。
    --   true = 全房 3 倍速：必须【所有玩家都先按 F7】，再由房主输入
    --          etbn sync on 打开，否则队友会跑不动。用完 etbn sync off 关掉。
    SyncNightmareToClients = false,

    ---------------------------------------------------------------
    -- 3) 每关随机刷新的手枪
    --    游戏内唯一的枪械是信号枪 FlareGun（物品名 flaregun），
    --    Mod 用它作为"手枪"，并额外赋予一击必杀实体的能力。
    --    每关随机数量 [Min, Max]，随机延迟 [Min, Max] 秒后出现。
    ---------------------------------------------------------------
    PistolItemName         = "flaregun",
    PistolsPerLevelMin     = 1,
    PistolsPerLevelMax     = 3,
    SpawnDelayMinSec       = 3,
    SpawnDelayMaxSec       = 20,

    -- 是否在刷枪时额外直接给房主背包塞一把（方便立刻测试）
    GivePistolToHostOnSpawn = false,

    ---------------------------------------------------------------
    -- 4) 手枪的致命效果
    --    "trigger" = 按扳机键向准星发射致命射线（推荐）
    --    "aim"     = 无需按键，准星对准实体即击杀
    -- 控制台命令 etbn_shoot 可在任意键位绑定（配合 fork 自带的 bind 命令）。
    --
    -- ★★ 默认扳机键已由 F 改成 G ★★
    --    F 是游戏原生的「交互 / 开门 / 拾取」键。旧版把 F 也绑成扳机，
    --    玩家按 F 想开锁 / 开窗户时，Mod 会同时朝准星发致命射线，把
    --    bp_lock_5_c、bp_windowpicker_c 这些交互道具当成"实体"销毁掉 ——
    --    表现就是「碰到某样东西它自动消失」。
    --    想改回 F 也可以，但强烈建议同时把 RequirePistolFallback 设 false。
    ---------------------------------------------------------------
    KillMode               = "trigger",
    TriggerKey             = "G",      -- 见下方 README 的可用键名说明
    TriggerThrottleMs      = 200,      -- 扳机最小间隔，防按住连发误杀
    RequirePistol          = true,     -- 是否需要持有信号枪才致命
    RequirePistolFallback  = true,     -- 检测不到背包时放行；放行时只认白名单实体（见代码）
    KillRange              = 50000.0,  -- 射线最大距离（UE 单位）
    AimIntervalMs          = 200,      -- aim 模式的检测间隔

    -- ★ 默认开启：任何「非玩家的 Pawn / Character」都算实体。
    -- 这是解决「有的实体杀不掉」的关键 —— 光靠类名白名单总会漏掉新版本实体，
    -- 而实体几乎必然是 Pawn，场景墙/椅子/ StaticMeshActor 则不是，不会误伤。
    KillAnyNonPlayerPawn   = true,

    -- ★ 射线默认可以「穿透」挡在前面的场景物件继续往后找实体。
    -- 旧版 LineTraceSingle 只打第一个命中物，隔着玻璃 / 栏杆 / 隐形碰撞体
    -- 就永远打不到后面的实体，看起来就像「这怪物杀不掉」。
    PenetrateScenery       = true,
    MaxPenetration         = 6,        -- 最多忽略几层非实体（1 = 关闭穿透）

    -- 每次开枪都把命中的类名写进日志（带节流，不会刷屏）。
    -- 遇到仍杀不掉的实体，开这个后把日志里那行类名发我即可精确定位。
    AlwaysLogHit           = true,

    ---------------------------------------------------------------
    -- 5) 实体识别（取自游戏 pak 内真实蓝图名，已全部小写）
    ---------------------------------------------------------------
    -- 只匹配「类名」，不匹配完整对象路径（否则 /Game/Maps/Level974 里的
    -- 所有场景物件都会因为 "974" 被误判成实体）。全部是游戏 pak 里真实实体蓝图名。
    -- 已从游戏 pak 索引里核对过，覆盖 BP_KillerClown / BP_Smiler_Dash /
    -- BP_Roaming_Smiler / BP_Entity974 / BP_Hound_Hotel / BP_Faceling /
    -- BP_Partygoer_* / BP_RoamingPartygoer / BP_DarkPartygoer / BP_Partypooper /
    -- BP_Partyhost / BP_SkinStealer_* / BP_Wretch_* / BP_Creature_1 等 57 个类名。
    -- 本轮补上之前漏掉的 BP_Wire / DeathMoth / BP_CheatParty。
    EntityPatterns         = {
        "bp_entity", "entity974", "smiler", "clown", "hound", "faceling",
        "partygoer", "partypooper", "partyhost", "darkparty",
        "skinstealer", "wretch", "creature_1", "handmonster",
        "bp_roaming", "monster", "plasticclown", "stalker",
        "bp_wire", "deathmoth", "cheatparty", "hidingparty", "roamingparty",
        -- 日志里实测击杀过、但旧白名单漏掉的实体
        "scratcher", "cave_moth", "bp_mothjelly",
        -- ★ 细菌（用户反馈「不能杀细菌」）：pak 索引里确认存在
        --   bacteria_bp / bacteria_roaming_bp / roamingbacteria /
        --   bacteriajumpscare / bacteria_aic(AI 控制器)，旧白名单一个都没有。
        --   用精确词而不是笼统的 "bacteria"，避免误杀 bp_bacteria_zone
        --   （区域触发器）和 bp_bacteria_roompoint（刷新点）。
        "bacteria_bp", "bacteria_roaming", "roamingbacteria",
        "bacteriajumpscare",
        -- ★ 2026-11-10 用户反馈「蜘蛛 / 触手怪杀不掉」：
        --   从 pak 的 /Game/Entity/ 目录重新提取全部 56 个 BP_ 蓝图类名后补齐。
        --   bp_membri = 多肢体/触手怪（玩家俗称蜘蛛/触手怪）
        --   bp_clump / bp_clump_poolrooms = Poolrooms 触手团
        --   bp_moth / bp_moths / bp_cave_moth = 飞蛾类
        --   配套的区域/触发器已写进下方 NeverKillPatterns，不会被误杀。
        "membri", "clump", "bp_moth", "moths", "hydroplague",
        "bonethief", "hoard2", "fish_scare", "smiler_dash",
    },
    -- ★★ 绝对保护名单：命中就【绝不销毁】，优先级高于一切实体判定，
    --    连 KillAnyNonPlayerPawn 兜底也越不过去。
    --    来源：UE4SS.log 里实测被误杀的 bp_lock_5_c（锁）与
    --    bp_windowpicker_c（窗户选择器），它们是可交互道具，不是怪物。
    --    「碰到某样东西就自动消失」就是这个名单缺失造成的。
    --    注意：故意没有放 "wire" / "party" / "roaming" 等词，
    --    因为 bp_wire / partygoer / roamingparty 是真实实体。
    NeverKillPatterns      = {
        -- 交互装置 / 机关
        "lock", "window", "picker", "door", "frame", "glass", "mirror",
        "button", "lever", "switch", "valve", "keypad", "panel",
        "console", "terminal", "generator", "elevator", "ladder", "vent",
        "handle", "knob", "wheel", "pad", "combination", "puzzle", "code",
        "hinge", "gate", "interact",
        -- 可拾取物 / 道具
        "pickup", "item", "key", "note", "paper", "flashlight", "battery",
        "prop", "tool", "inventory",
        -- 家具 / 陈设 / 场景装置
        "chest", "crate", "cabinet", "drawer", "shelf", "table", "box",
        "barrel", "pipe", "phone", "radio", "tv", "screen", "monitor",
        "clock", "sign", "poster", "lamp", "speaker", "camera", "projector",
        "decor", "furniture",
        "bacteria_zone", "bacteria_roompoint",
        -- ★ 新补实体配套的「区域 / 刷新器 / 管理器」，绝不能当成怪清掉
        "clumpmovezone", "smilermovezone", "movezone", "doorway_zone",
        "attack_zone", "spawnmembri", "membri_manager", "roaming_volume",
        "cankill_trigger", "retreat",
    },
    -- 这些名字即使命中也绝不当成实体（保护玩家和场景物件）
    SafePatterns           = {
        "bpcharacter_demo", "player", "droppeditem", "itemspawner",
        "playerstart", "worldsettings", "gamemode", "gamestate",
        "staticmeshactor", "bpp_hism", "instancedfoliage", "brush",
        "volume", "light", "trigger", "audience", "chair", "desk",
        "wall", "floor", "painting", "rug", "decal", "postprocess",
        -- 细菌的「区域 / 刷新点」不是实体，别被手枪清掉
        "bacteria_zone", "bacteria_roompoint",
        -- 新补实体配套的区域 / 触发器（双重保险）
        "movezone", "doorway_zone", "attack_zone", "spawnmembri",
        "membri_manager", "roaming_volume", "cankill_trigger", "retreat",
        "lock", "window", "picker", "door", "frame", "glass", "button",
        "lever", "switch", "valve", "keypad", "panel", "console",
        "generator", "elevator", "ladder", "vent", "handle", "knob",
        "wheel", "prop", "note", "poster", "screen", "monitor",
    },

    ---------------------------------------------------------------
    -- 6) 性能（帧率修复）
    --    旧版 20Hz 主循环每次做 2 次 FindAllOf 全对象扫描，加上「每帧钩子」
    --    每个角色每帧都重查 IsServerStrict / IsLocalCharacter，会明显掉帧。
    --    现在全局查询都有缓存，钩子也节流，10Hz 完全够用。
    ---------------------------------------------------------------
    TickIntervalMs         = 100,  -- 主循环间隔（毫秒）。卡顿可改 150/200
    CharacterCacheMs       = 500,  -- 角色列表缓存时长（毫秒）；新队友最多延迟这么久被识别
    FrameHookThrottleMs    = 100,  -- 每帧移动钩子的最小执行间隔（毫秒），设 0 = 不节流
    LogPenetrationHits     = false,-- 是否把「射线穿透非实体」写日志；print 是同步磁盘 I/O，连发会卡
    Debug                  = false, -- 打开后输出详细日志，排错用

    ---------------------------------------------------------------
    -- 7) 场景 / 实体皮肤包（圣诞主题）
    --    素材全部取自游戏本体自带的 HolidayUpdate / SnowAngel / Club /
    --    Hotel 资产：运行时给组件换材质 + 换模型，不需要 Unreal Editor、
    --    不需要 .pak，也不会改碰撞体（手枪判定不受影响）。
    --    预设：off(原版) / christmas / frost / candy / gold
    --    游戏内：etbn skin list / etbn skin christmas / F8 循环 / etbn skin off
    ---------------------------------------------------------------
    -- ★★ 2026-11-10 崩溃修复（「游戏老崩溃」）：
    --   两次 UE4 Minidump 都是 EXCEPTION_ACCESS_VIOLATION，调用栈里
    --   一整串相同的 UE4SS Lua VM 帧；日志显示每次换关 +1.5s 皮肤包都会
    --   做 FindAllOf("Actor") 全场扫描 + LoadAsset 同步加载资产（"Asset loaded"），
    --   且每次跑满 500ms 预算。在 UE4 LoadMap 期间同步加载 cooked 资产 /
    --   访问正在销毁的 UObject，正是这类悬空指针崩溃的典型成因。
    --   因此本版改成「默认完全不自动跑皮肤」：只在你手动输入命令 / 按 F8
    --   且关卡已经稳定（换关后 >= SkinLevelGraceMs）时才执行一次。
    SkinSafeMode           = true,   -- true = 禁止换关/启动时自动应用皮肤（★ 防崩溃）
    SkinLevelGraceMs       = 4000,   -- 换关后这段时间内拒绝应用皮肤，等关卡加载完
    SkinPreset             = "off",  -- ★ 默认游戏原版外观；想要皮肤手动 etbn skin christmas
    SkinApplyOnLevel       = false,  -- ★ 换关不再自动重套（这是崩溃触发路径）
    -- ★ 2026-11-10 实机反馈「墙面一半灰一半原版」：UE4SS 的 LoadAsset 在
    --   这个 fork 里加载不到游戏内材质（日志 assets=2 全是引擎兜底），
    --   60 个场景物件被套上灰色的 DefaultMaterial。默认不再改场景材质。
    SkinSceneEnabled       = false,  -- false = 场景保持原版，只给实体换肤
    SkinAllowEngineFallback= false,  -- false = 游戏资产加载失败就保持原版，绝不降级成灰色
    SkinPropsEnabled       = true,   -- 往场景里植入拐杖糖 / 星星 / 彩球
    SkinSceneTint          = false,  -- true = 场景物件全部染色（更彻底，但容易变纯色块）
    SkinSceneRatio         = 0.25,   -- SkinSceneTint=false 时，每 4 个场景物件点缀 1 个
    SkinMaxActors          = 150,    -- ★ 400 -> 150：减少单次跨语言调用量
    SkinMaxScene           = 60,     -- 最多给多少个场景物件换材质
    SkinMaxProps           = 12,     -- 最多植入多少个圣诞装饰
    SkinBudgetMs           = 150,    -- ★ 500 -> 150：单次应用时间预算（毫秒）
}

return Config
