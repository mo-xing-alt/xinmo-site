# -*- coding: utf-8 -*-
"""
RiskGuard 风控控制台 —— 启动入口。

    python server.py [端口]                     默认 http://127.0.0.1:8791
    python server.py --reset-password 新密码     重置管理员口令（至少 10 位）

首次启动会自动建库、创建管理员（随机口令打印在终端并写入
data/INITIAL_ADMIN.txt，登录后请改密并删除该文件）、灌入演示数据。
环境变量：
    RISKGUARD_DATA             数据目录，默认 ./data
    RISKGUARD_ADMIN_PASSWORD   首次创建管理员时的密码
"""
from __future__ import annotations

import sys


def _reset_password(pwd: str) -> None:
    if len(pwd) < 10:
        print("密码至少 10 位")
        sys.exit(2)
    from app import db
    db.init_db()
    db.change_password("admin", pwd, "cli")
    print("管理员 admin 的密码已重置，所有既有会话已失效。")


if __name__ == "__main__":
    args = sys.argv[1:]
    if args and args[0] == "--reset-password":
        if len(args) < 2:
            print("用法：python server.py --reset-password 新密码")
            sys.exit(2)
        _reset_password(args[1])
    else:
        from app.web import main
        # 不传端口时由 app.web 读取 RISKGUARD_PORT / RISKGUARD_BIND
        main(int(args[0]) if args else None)
