# -*- coding: utf-8 -*-
"""纯标准库统计工具。刻意不依赖 numpy/scipy，便于嵌进风控网关的轻量 sidecar。"""
from __future__ import annotations

import math
from collections import Counter
from typing import Dict, Iterable, Sequence


def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def mean(xs: Sequence[float]) -> float:
    return sum(xs) / len(xs) if xs else 0.0


def pstdev(xs: Sequence[float]) -> float:
    if len(xs) < 2:
        return 0.0
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))


def pearson(xs: Sequence[float], ys: Sequence[float]) -> float:
    """皮尔逊相关；样本不足或常量序列返回 0。"""
    if len(xs) != len(ys) or len(xs) < 3:
        return 0.0
    mx, my = mean(xs), mean(ys)
    num = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
    den = math.sqrt(sum((a - mx) ** 2 for a in xs) * sum((b - my) ** 2 for b in ys))
    return num / den if den > 1e-12 else 0.0


def skewness(xs: Sequence[float]) -> float:
    """样本偏度。真人观看时长通常右偏（>0），截断高斯近似对称（≈0）。"""
    if len(xs) < 4:
        return 0.0
    m, s = mean(xs), pstdev(xs)
    if s < 1e-9:
        return 0.0
    return sum(((x - m) / s) ** 3 for x in xs) / len(xs)


def shannon_entropy(values: Iterable[int], base: int = 10) -> float:
    """归一化到 [0,1] 的香农熵。用于检测小数位是否"过于干净"。"""
    vals = list(values)
    if not vals:
        return 0.0
    counts = Counter(vals)
    n = len(vals)
    h = -sum((c / n) * math.log(c / n) for c in counts.values())
    return clamp(h / math.log(base))


def lag1_autocorr(xs: Sequence[float]) -> float:
    """一阶自相关。真人有状态（疲劳、内容偏好连续），i.i.d. 采样脚本 ≈ 0。"""
    if len(xs) < 6:
        return 0.0
    return pearson(list(xs[:-1]), list(xs[1:]))


def erf(x: float) -> float:
    """Abramowitz & Stegun 7.1.26 近似，最大误差 1.5e-7，够用。"""
    sign = 1.0 if x >= 0 else -1.0
    x = abs(x)
    t = 1.0 / (1.0 + 0.3275911 * x)
    y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t
                - 0.284496736) * t + 0.254829592) * t * math.exp(-x * x)
    return sign * y


def normal_cdf(x: float, mu: float = 0.0, sigma: float = 1.0) -> float:
    if sigma <= 1e-9:
        return 1.0 if x >= mu else 0.0
    return 0.5 * (1.0 + erf((x - mu) / (sigma * math.sqrt(2.0))))


def ks_stat_vs_fitted_normal(xs: Sequence[float]) -> float:
    """
    单样本 KS 统计量（参数由样本估计，属 Lilliefors 近似，仅作弱证据）。
    此处用途特殊：不是要证明"是否正态"，而是识别"拟合得过好"——
    脚本直接 random.gauss() 出来的时长会比真人数据更贴正态。
    """
    if len(xs) < 8:
        return 1.0
    m, s = mean(xs), pstdev(xs)
    if s < 1e-9:
        return 1.0
    ordered = sorted(xs)
    n = len(ordered)
    d = 0.0
    for i, v in enumerate(ordered):
        f = normal_cdf(v, m, s)
        d = max(d, abs((i + 1) / n - f), abs(i / n - f))
    return d


def point_biserial(binary: Sequence[int], continuous: Sequence[float]) -> float:
    """点二列相关，等价于 pearson，单独命名以便阅读。"""
    return pearson([float(b) for b in binary], list(continuous))


def ramp(v: float, low: float, high: float) -> float:
    """把指标线性映射到 0..1；v<=low→0，v>=high→1。"""
    if high <= low:
        return 0.0
    return clamp((v - low) / (high - low))


def decay(v: float, low: float, high: float) -> float:
    """反向映射；v<=low→1，v>=high→0。用于"越小越可疑"的指标。"""
    return 1.0 - ramp(v, low, high)


def merge_metrics(prefix: str, d: Dict[str, float]) -> Dict[str, float]:
    return {f"{prefix}.{k}": round(float(v), 6) for k, v in d.items()}
