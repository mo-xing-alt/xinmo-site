# -*- coding: utf-8 -*-
"""
合成样本生成器：真人 / 贝塞尔拟人脚本 / 固定间隔脚本。

用途：演示、阈值标定、回归测试。**合成数据只用于验证检测器逻辑，
不能替代生产环境的真人标注集**。上线前必须用自有真实流量重新标定阈值。
"""
from __future__ import annotations

import math
import random
from typing import Dict, List, Tuple

from .models import BehaviorWindow, Fingerprint, Swipe, TouchPoint

N_VIDEOS = 40


# ---------------------------------------------------------------- 手势生成
def _bezier(p0, p1, p2, p3, u: float) -> Tuple[float, float]:
    v = 1.0 - u
    x = v ** 3 * p0[0] + 3 * v * v * u * p1[0] + 3 * v * u * u * p2[0] + u ** 3 * p3[0]
    y = v ** 3 * p0[1] + 3 * v * v * u * p1[1] + 3 * v * u * u * p2[1] + u ** 3 * p3[1]
    return x, y


def _human_swipe(rng: random.Random, t0: float) -> Swipe:
    """真人：带生理性微颤、采样抖动、压力随速度变化，且每次轨迹形状都不同。"""
    x0, y0 = rng.uniform(330, 400), rng.uniform(600, 670)
    x1, y1 = x0 + rng.uniform(-35, 35), y0 - rng.uniform(395, 470)
    dx, dy = x1 - x0, y1 - y0
    # 控制点每次随机偏移 —— 真人不会复用同一条曲线
    p0 = (x0, y0)
    p1 = (x0 + 0.28 * dx + rng.uniform(-95, 95), y0 + 0.16 * dy + rng.uniform(-70, 70))
    p2 = (x0 + 0.72 * dx + rng.uniform(-95, 95), y0 + 0.84 * dy + rng.uniform(-70, 70))
    p3 = (x1, y1)

    n = rng.randint(22, 30)
    ts, t = [], t0
    for _ in range(n):
        ts.append(t)
        t += max(8.0, 16.667 + rng.gauss(0, 2.4))
    span = ts[-1] - ts[0]
    phase = rng.uniform(1.0, 3.0)            # 每次手势的回弹相位都不同

    raw = []
    for i, tt in enumerate(ts):
        u = (tt - ts[0]) / span
        # 时间上的缓动（起势加速 / 缓动减速）+ 随机相位的微调回弹
        e = u * u * (3 - 2 * u) + 0.018 * math.sin(u * math.pi * phase)
        x, y = _bezier(p0, p1, p2, p3, max(0.0, min(1.0, e)))
        # 8~12Hz 生理性震颤
        x += rng.gauss(0, 0.62)
        y += rng.gauss(0, 0.95)
        raw.append([x, y])
    # 中途一到两次方向微修正，制造折点
    for _ in range(rng.randint(1, 3)):
        k = rng.randint(3, n - 4)
        raw[k][1] += rng.uniform(-2.6, 2.6)
        raw[k][0] += rng.uniform(-1.5, 1.5)

    pts: List[TouchPoint] = []
    speeds = [math.hypot(raw[i + 1][0] - raw[i][0], raw[i + 1][1] - raw[i][1])
              / max(ts[i + 1] - ts[i], 1e-6) for i in range(n - 1)]
    vmax = max(speeds) or 1.0
    for i in range(n):
        vn = speeds[min(i, n - 2)] / vmax
        # 慢速段按得更实：压力与速度负相关
        pressure = max(0.18, min(1.0, 0.48 + 0.38 * (1 - vn) + rng.gauss(0, 0.022)))
        area = max(1.0, 34 + 24 * (1 - vn) + rng.gauss(0, 2.4))
        pts.append(TouchPoint(raw[i][0], raw[i][1], ts[i], pressure, area, 1))
    return Swipe(pts)


def _bezier_bot_swipe(t0: float) -> Swipe:
    """贝塞尔拟人脚本：解析曲线、恒定采样间隔、压力恒定、每次完全复用同一模板。"""
    p0 = (360.0, 640.0)
    p1 = (352.0, 500.0)
    p2 = (368.0, 320.0)
    p3 = (360.0, 190.0)
    n, dt = 28, 16.0
    pts = []
    for i in range(n):
        u = i / (n - 1)
        e = u * u * (3 - 2 * u)
        x, y = _bezier(p0, p1, p2, p3, e)
        pts.append(TouchPoint(x, y, t0 + i * dt, 1.0, 0.0, 1))
    return Swipe(pts)


def _linear_bot_swipe(t0: float) -> Swipe:
    """最原始脚本：匀速直线、固定 20ms、固定时长。"""
    pts = []
    for i in range(22):
        u = i / 21
        pts.append(TouchPoint(360.0, 640 - 450 * u, t0 + i * 20.0, 1.0, 0.0, 1))
    return Swipe(pts)


# ---------------------------------------------------------------- 设备指纹
def _human_fp(device_id: str, account_id: str) -> Fingerprint:
    return Fingerprint(
        device_id=device_id, account_id=account_id,
        ua=("Mozilla/5.0 (Linux; Android 13; Pixel 7 Build/TQ3A.230901.001) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36"),
        platform="Android", screen_w=1080, screen_h=2400, dpr=2.625,
        webgl_vendor="Qualcomm", webgl_renderer="Adreno (TM) 730",
        timezone="Asia/Shanghai", languages=["zh-CN", "zh", "en"],
        hardware_concurrency=8, device_memory=8.0,
        webdriver=False, plugins_count=0, has_chrome_object=True,
        touch_max_points=5, accelerometer=True, ip_region="CN",
    )


def _farm_fp(device_id: str, account_id: str) -> Fingerprint:
    """群控农场：轮换拼接出来的指纹，交叉一致性必然崩坏。"""
    return Fingerprint(
        device_id=device_id, account_id=account_id,
        ua=("Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/96.0.4664.104 Mobile Safari/537.36"),
        platform="Windows",                      # 与 UA 冲突
        screen_w=1080, screen_h=2400, dpr=3.0,
        webgl_vendor="Google Inc.",
        webgl_renderer="ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11)",  # 桌面 GPU
        timezone="America/New_York", languages=["en-US"],
        hardware_concurrency=6, device_memory=3.0,   # 非标准枚举
        webdriver=True, plugins_count=0, has_chrome_object=False,
        touch_max_points=1, accelerometer=False, ip_region="CN",
    )


# ---------------------------------------------------------------- 场景拼装
def _human_window(seed: int) -> BehaviorWindow:
    rng = random.Random(seed)
    swipes, watches = [], []
    ts = 1_700_000_000.0                 # 观看记录的 unix 秒
    cursor_ms = 1_700_000_000_000.0     # 手势序列的毫秒时间轴
    log_prev = math.log(14.0)
    for i in range(N_VIDEOS):
        # AR(1) 状态 + 对数正态右偏重尾；保留毫秒级连续精度
        log_d = math.log(14.0) + 0.38 * (log_prev - math.log(14.0)) + rng.gauss(0, 0.52)
        log_prev = log_d
        d = round(min(95.0, max(2.2, math.exp(log_d))), 3)
        # 真人的点赞意愿与内容吸引力（这里用停留时长代理）显著正相关
        p_like = min(0.90, 0.002 + 0.024 * d)
        gap = rng.choice([0.4, 0.4, 0.5, rng.uniform(1.5, 22.0)])
        watches.append(_watch(rng, d, i, p_like, ts))
        cursor_ms += d * 1000
        swipes.append(_human_swipe(rng, cursor_ms))
        cursor_ms += gap * 1000
        ts += d + gap
    # 真人会额外快速划过几条（直播/广告），滑看比例不会严格 1:1
    swipes.append(_human_swipe(rng, cursor_ms))
    swipes.append(_human_swipe(rng, cursor_ms + 1000))
    fp = _human_fp("dev-human-01", "u_human")
    return BehaviorWindow(
        window_id="w-human", account_id="u_human", device_id=fp.device_id,
        swipes=swipes, watches=watches, fingerprints=[fp],
        swipe_history=[_human_swipe(rng, 0.0) for _ in range(4)],
        fp_account_map={fp.device_id: ["u_human"]},
        account_fp_history={"u_human": [fp.device_id]},
        daily_active_s=3.6 * 3600, hour_of_day=21,
    )


def _watch(rng: random.Random, d: float, i: int, p_like: float, ts: float):
    from .models import WatchRecord
    return WatchRecord(
        duration_s=d, content_id=f"v{i:04d}",
        liked=rng.random() < p_like,
        followed=rng.random() < 0.002,
        commented=rng.random() < 0.01,
        is_live=False, ts=ts,
    )


def _bezier_bot_window(seed: int) -> BehaviorWindow:
    rng = random.Random(seed)
    swipes, watches = [], []
    ts, cursor_ms = 1_700_000_000.0, 1_700_000_000_000.0
    for i in range(N_VIDEOS):
        # 经典写法：gauss + 硬截断 + round(...,1) —— 统计破绽全在这里
        d = round(min(35.0, max(8.0, rng.gauss(21.5, 6.0))), 1)
        from .models import WatchRecord
        watches.append(WatchRecord(
            duration_s=d, content_id=f"v{i:04d}",
            liked=rng.random() < 0.15,      # 固定 15%，与内容/时长完全独立
            followed=rng.random() < 0.01,
            commented=rng.random() < 0.05,
            is_live=False, ts=ts,
        ))
        cursor_ms += d * 1000
        swipes.append(_bezier_bot_swipe(cursor_ms))
        cursor_ms += 450
        ts += d + 0.45                       # 无空闲停顿
    fp = _farm_fp("dev-farm-01", "u_bezier_bot")
    farm_accounts = [f"u_farm_{k:02d}" for k in range(40)]
    return BehaviorWindow(
        window_id="w-bezier", account_id="u_bezier_bot", device_id=fp.device_id,
        swipes=swipes, watches=watches, fingerprints=[fp],
        swipe_history=[_bezier_bot_swipe(0.0) for _ in range(4)],
        fp_account_map={fp.device_id: farm_accounts},
        account_fp_history={"u_bezier_bot": [f"fp_rot_{k}" for k in range(6)]},
        daily_active_s=19.2 * 3600, hour_of_day=3,
    )


def _fixed_bot_window(seed: int) -> BehaviorWindow:
    rng = random.Random(seed)
    swipes, watches = [], []
    ts, cursor_ms = 1_700_000_000.0, 1_700_000_000_000.0
    for i in range(N_VIDEOS):
        from .models import WatchRecord
        stuck_live = (i == 7)
        d = 90.0 if stuck_live else 12.0     # 没做直播识别 → 在直播间卡死 90s
        watches.append(WatchRecord(
            duration_s=d, content_id=f"v{i:04d}",
            liked=False, followed=False, commented=False,
            is_live=stuck_live, ts=ts,
        ))
        cursor_ms += d * 1000
        swipes.append(_linear_bot_swipe(cursor_ms))
        cursor_ms += 440
        ts += d + 0.44
    fp = _farm_fp("dev-farm-02", "u_fixed_bot")
    fp.screen_w, fp.screen_h = 2400, 1080  # 再添一条冲突：移动端横屏尺寸
    return BehaviorWindow(
        window_id="w-fixed", account_id="u_fixed_bot", device_id=fp.device_id,
        swipes=swipes, watches=watches, fingerprints=[fp],
        swipe_history=[_linear_bot_swipe(0.0) for _ in range(4)],
        fp_account_map={fp.device_id: [f"u_batch_{k:02d}" for k in range(28)]},
        account_fp_history={"u_fixed_bot": [f"fp_x_{k}" for k in range(5)]},
        daily_active_s=23.1 * 3600, hour_of_day=4,
    )


def build_scenarios(seed: int = 42) -> Dict[str, BehaviorWindow]:
    """返回三类样本。key 与看板上的标签一一对应。"""
    return {
        "human": _human_window(seed),
        "bezier_bot": _bezier_bot_window(seed + 1),
        "fixed_bot": _fixed_bot_window(seed + 2),
    }


LABELS = {
    "human": "真人用户（对照组）",
    "bezier_bot": "贝塞尔拟人脚本 + 指纹农场",
    "fixed_bot": "固定间隔脚本 + 批量群控",
}
