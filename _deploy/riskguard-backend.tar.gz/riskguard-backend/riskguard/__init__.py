# -*- coding: utf-8 -*-
"""
RiskGuard —— 短视频平台「刷量机器人」服务端行为风控检测引擎（防御侧）。

定位：只做检测与分级处置，不提供任何绕过验证、指纹伪造、自动化伪装能力。
所有输入均为服务端可合法采集的行为与设备信号；输出为风险分与处置建议。

模块：
    models        数据结构
    util          纯标准库统计工具
    touch         触控信号真实性（微颤 / 采样抖动 / 压力 / 轨迹模板复用）
    timing        观看时长与互动的统计合理性（量化痕迹 / 分布形态 / 自相关）
    fingerprint   设备指纹一致性与自动化运行时特征
    behavior      账号级行为合理性（在线时长 / 无间断 / 直播间卡死）
    engine        证据融合、迟滞与分级挑战
    synthetic     三类合成样本（真人 / 贝塞尔脚本 / 固定间隔脚本），用于演示与回归测试
"""
from .models import (  # noqa: F401
    Action, BehaviorWindow, Fingerprint, RiskLevel, RiskReport,
    SignalResult, Swipe, TouchPoint, WatchRecord,
)
from .engine import RiskEngine  # noqa: F401

__all__ = [
    "RiskEngine", "BehaviorWindow", "Fingerprint", "Swipe", "TouchPoint",
    "WatchRecord", "SignalResult", "RiskReport", "RiskLevel", "Action",
]
__version__ = "1.0.0"
