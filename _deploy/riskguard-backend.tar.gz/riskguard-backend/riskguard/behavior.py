# -*- coding: utf-8 -*-
"""
账号级行为合理性检测 —— 单帧信号可以伪装，长周期的物理约束伪装不了。

  - 单账号日活跃时长接近或超过 24h：脚本不会睡觉
  - 相邻视频之间永远没有空闲间隔（gap ≈ 滑动耗时）：真人会停顿、切后台、看通知
  - 直播间长时间停留：脚本没做直播识别时的典型"卡死"特征
  - 滑动次数与观看次数严格 1:1 且零方差：状态机式循环
  - 深夜时段仍保持满负荷且作息完全均匀：无昼夜节律
"""
from __future__ import annotations

from typing import Sequence

from .models import BehaviorWindow, SignalResult
from .util import clamp, decay, mean, pstdev, ramp


def score_behavior(w: BehaviorWindow) -> SignalResult:
    watches = [x for x in w.watches if x.duration_s > 0]
    n = len(watches)
    if n < 4:
        return SignalResult("behavior", 0.0, 0.0,
                            ["行为样本不足，跳过该信号"], {"samples": float(n)})

    # 1) 日活跃时长
    daily_h = w.daily_active_s / 3600.0

    # 2) 相邻记录之间的空闲间隙 = 下一条 ts - (上一条 ts + 观看时长)
    gaps = []
    for a, b in zip(watches, watches[1:]):
        if a.ts > 0 and b.ts > 0:
            gaps.append(b.ts - (a.ts + a.duration_s))
    if gaps:
        idle_ratio = sum(1 for g in gaps if g > 1.5) / len(gaps)   # >1.5s 视为一次真实停顿
        gap_cv = pstdev(gaps) / max(abs(mean(gaps)), 1e-6)
    else:
        idle_ratio, gap_cv = 0.0, 0.0

    # 3) 直播间长停留
    live_long = sum(1 for x in watches if x.is_live and x.duration_s > 30)
    live_ratio = live_long / n

    # 4) 滑看比例是否"过于精确"
    exact_ratio = 1.0 if (w.swipes and len(w.swipes) == n) else 0.0

    # 5) 深夜满负荷
    night_full = 1.0 if (2 <= w.hour_of_day <= 5 and daily_h >= 8.0) else 0.0

    m = {
        "daily_active_hours": daily_h,
        "idle_gap_ratio": idle_ratio,
        "idle_gap_cv": gap_cv,
        "live_long_dwell_ratio": live_ratio,
        "exact_swipe_watch_ratio": exact_ratio,
        "night_full_load": night_full,
        "samples": float(n),
    }

    e_daily = ramp(daily_h, 12.0, 21.0)
    e_idle = decay(idle_ratio, 0.02, 0.30)          # 几乎没有停顿
    e_gapcv = decay(gap_cv, 0.05, 0.60)             # 间隙高度均一
    e_live = ramp(live_ratio, 0.005, 0.10)          # 卡在直播间
    e_exact = exact_ratio * 0.6                     # 严格 1:1（弱证据）
    e_night = night_full * 0.7

    parts = {
        "日活跃时长超出人类物理上限": (e_daily, 0.30),
        "相邻视频间几乎无空闲停顿": (e_idle, 0.24),
        "切换间隔高度均一": (e_gapcv, 0.14),
        "直播间长时间停留（疑似卡死）": (e_live, 0.14),
        "滑动与观看次数严格 1:1": (e_exact, 0.08),
        "深夜满负荷且无昼夜节律": (e_night, 0.10),
    }
    score = sum(v * wgt for v, wgt in parts.values())
    reasons = [name for name, (v, _) in parts.items() if v > 0.60]
    if not reasons:
        reasons.append("存在自然停顿与作息节律，行为链条合理")

    conf = clamp(0.30 + 0.016 * n, 0.0, 1.0)
    return SignalResult("behavior", clamp(score), conf, reasons,
                        {k: round(v, 6) for k, v in m.items()})
