# -*- coding: utf-8 -*-
"""
公共数据结构与契约。

采集侧约定（生产环境通常由客户端埋点 SDK / 网关上报，服务端只消费）：
  - TouchPoint.t 为毫秒，单调递增；坐标为 CSS 像素
  - WatchRecord.duration_s 为秒，保留原始精度，**禁止在上报前 round()**
  - Fingerprint 为一次会话快照；同一账号跨会话快照用于一致性校验
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


class RiskLevel:
    LOW = "LOW"
    ELEVATED = "ELEVATED"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class Action:
    ALLOW = "ALLOW"                           # 放行
    OBSERVE = "OBSERVE"                       # 放行 + 加密采样 + 观察名单
    SILENT_CHALLENGE = "SILENT_CHALLENGE"     # 无感挑战：一次性 nonce / 时序扰动
    SLIDER = "SLIDER"                         # 显式滑块验证
    STEP_UP_AUTH = "STEP_UP_AUTH"             # 二次校验：短信 / 人脸，交由本人完成
    THROTTLE = "THROTTLE"                     # 限流 + 暂停激励结算
    BLOCK = "BLOCK"                           # 阻断会话 + 冻结争议收益 + 人工复核

    ORDER = [ALLOW, OBSERVE, SILENT_CHALLENGE, SLIDER, STEP_UP_AUTH, THROTTLE, BLOCK]


@dataclass(frozen=True)
class TouchPoint:
    x: float
    y: float
    t: float                     # ms
    pressure: float = 1.0        # 0..1；合成轨迹常恒为 1.0
    area: float = 0.0            # 接触面积
    pointer_id: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return {"x": self.x, "y": self.y, "t": self.t,
                "pressure": self.pressure, "area": self.area,
                "pointer_id": self.pointer_id}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TouchPoint":
        return cls(float(d["x"]), float(d["y"]), float(d["t"]),
                   float(d.get("pressure", 1.0)), float(d.get("area", 0.0)),
                   int(d.get("pointer_id", 1)))


@dataclass
class Swipe:
    """一次上滑手势的完整触控序列。"""
    points: List[TouchPoint]
    session_id: str = ""

    def __post_init__(self) -> None:
        self.points = sorted(self.points, key=lambda p: p.t)

    @property
    def duration_ms(self) -> float:
        return self.points[-1].t - self.points[0].t if len(self.points) > 1 else 0.0

    @property
    def path_length(self) -> float:
        return sum(math.hypot(b.x - a.x, b.y - a.y)
                   for a, b in zip(self.points, self.points[1:]))

    def normalized(self, n: int = 32) -> Optional[List[Tuple[float, float]]]:
        """
        按时间等距重采样为 n 点，并以本次位移量归一化，得到"形状指纹"。
        归一化后可跨不同分辨率/滑动距离比较 —— 这是抓"复用同一组贝塞尔控制点"的关键。
        """
        pts = self.points
        if len(pts) < 4:
            return None
        x0, y0 = pts[0].x, pts[0].y
        scale = math.hypot(pts[-1].x - x0, pts[-1].y - y0)
        if scale < 1e-6:
            return None
        t0, span = pts[0].t, pts[-1].t - pts[0].t
        if span <= 0:
            return None
        out: List[Tuple[float, float]] = []
        j = 0
        for i in range(n):
            target = t0 + span * i / (n - 1)
            while j < len(pts) - 2 and pts[j + 1].t < target:
                j += 1
            a, b = pts[j], pts[j + 1]
            w = 0.0 if b.t == a.t else (target - a.t) / (b.t - a.t)
            w = max(0.0, min(1.0, w))
            x, y = a.x + (b.x - a.x) * w, a.y + (b.y - a.y) * w
            out.append(((x - x0) / scale, (y - y0) / scale))
        return out

    def to_dict(self) -> Dict[str, Any]:
        return {"session_id": self.session_id, "points": [p.to_dict() for p in self.points]}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Swipe":
        return cls([TouchPoint.from_dict(p) for p in d.get("points", [])],
                   str(d.get("session_id", "")))


@dataclass
class WatchRecord:
    duration_s: float
    content_id: str
    liked: bool = False
    followed: bool = False
    commented: bool = False
    is_live: bool = False
    ts: float = 0.0                 # unix 秒

    def to_dict(self) -> Dict[str, Any]:
        return {"duration_s": self.duration_s, "content_id": self.content_id,
                "liked": self.liked, "followed": self.followed,
                "commented": self.commented, "is_live": self.is_live, "ts": self.ts}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "WatchRecord":
        return cls(float(d["duration_s"]), str(d.get("content_id", "")),
                   bool(d.get("liked", False)), bool(d.get("followed", False)),
                   bool(d.get("commented", False)), bool(d.get("is_live", False)),
                   float(d.get("ts", 0.0)))


@dataclass
class Fingerprint:
    device_id: str
    account_id: str
    ua: str
    platform: str                    # Windows / macOS / Android / iOS
    screen_w: int
    screen_h: int
    dpr: float
    webgl_vendor: str
    webgl_renderer: str
    timezone: str
    languages: List[str]
    hardware_concurrency: int
    device_memory: float
    webdriver: bool                  # navigator.webdriver
    plugins_count: int
    has_chrome_object: bool
    touch_max_points: int
    accelerometer: bool
    ip_region: str
    collected_at: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Fingerprint":
        keys = set(cls.__dataclass_fields__)
        clean = {k: v for k, v in d.items() if k in keys}
        clean.setdefault("collected_at", time.time())
        return cls(**clean)


@dataclass
class BehaviorWindow:
    """一个评测窗口（建议 5~10 分钟）内的全部服务端可见信号。"""
    window_id: str
    account_id: str
    device_id: str
    swipes: List[Swipe] = field(default_factory=list)
    watches: List[WatchRecord] = field(default_factory=list)
    fingerprints: List[Fingerprint] = field(default_factory=list)
    swipe_history: List[Swipe] = field(default_factory=list)      # 历史手势，用于模板复用比对
    fp_account_map: Dict[str, List[str]] = field(default_factory=dict)   # 指纹 -> 账号列表
    account_fp_history: Dict[str, List[str]] = field(default_factory=dict)  # 账号 -> 历史指纹
    daily_active_s: float = 0.0
    hour_of_day: int = 12

    def to_dict(self) -> Dict[str, Any]:
        return {
            "window_id": self.window_id, "account_id": self.account_id,
            "device_id": self.device_id,
            "swipes": [s.to_dict() for s in self.swipes],
            "watches": [w.to_dict() for w in self.watches],
            "fingerprints": [f.to_dict() for f in self.fingerprints],
            "swipe_history": [s.to_dict() for s in self.swipe_history],
            "fp_account_map": self.fp_account_map,
            "account_fp_history": self.account_fp_history,
            "daily_active_s": self.daily_active_s, "hour_of_day": self.hour_of_day,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "BehaviorWindow":
        return cls(
            window_id=str(d.get("window_id", "w")),
            account_id=str(d.get("account_id", "anon")),
            device_id=str(d.get("device_id", "")),
            swipes=[Swipe.from_dict(x) for x in d.get("swipes", [])],
            watches=[WatchRecord.from_dict(x) for x in d.get("watches", [])],
            fingerprints=[Fingerprint.from_dict(x) for x in d.get("fingerprints", [])],
            swipe_history=[Swipe.from_dict(x) for x in d.get("swipe_history", [])],
            fp_account_map=dict(d.get("fp_account_map", {})),
            account_fp_history=dict(d.get("account_fp_history", {})),
            daily_active_s=float(d.get("daily_active_s", 0.0)),
            hour_of_day=int(d.get("hour_of_day", 12)),
        )


@dataclass
class SignalResult:
    """单个检测器的输出。score 越高越像机器；confidence 表示证据是否充足。"""
    name: str
    score: float
    confidence: float
    reasons: List[str] = field(default_factory=list)
    metrics: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "score": round(self.score, 4),
                "confidence": round(self.confidence, 4),
                "reasons": self.reasons, "metrics": self.metrics}


@dataclass
class RiskReport:
    account_id: str
    window_id: str
    level: str
    action: str
    score: float
    signals: List[SignalResult]
    reasons: List[str]
    public_response: Dict[str, Any]
    ts: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "account_id": self.account_id, "window_id": self.window_id,
            "level": self.level, "action": self.action,
            "score": round(self.score, 4),
            "signals": [s.to_dict() for s in self.signals],
            "reasons": self.reasons,
            # 注意：public_response 是可下发给客户端的；reasons/signals 严禁下发
            "public_response": self.public_response,
            "ts": self.ts,
        }
