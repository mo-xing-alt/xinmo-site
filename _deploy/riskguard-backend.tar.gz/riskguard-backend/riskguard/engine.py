# -*- coding: utf-8 -*-
"""
证据融合 + 迟滞 + 分级挑战（风控决策层）。

三条工程原则：
  1) 不做单点判决：四路信号按置信度加权，同时用 max 项保留"某一路极强"的证据。
  2) 带迟滞：升级需要连续多个窗口命中，降级需要更多窗口，避免抖动误杀；
     生产环境状态应放 Redis 并按账号维度加 TTL。
  3) 不做判定预言机：无论内部命中了哪条规则，下发给客户端的响应结构完全一致
     （只有 challenge 类型不同），且**永不返回 reasons / 单项分数**，
     否则对方可以逐条探测规则边界。这也是"熔断"在防御侧的等价物：
     强校验一旦触发就交给本人完成，服务端绝不尝试代答。
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Dict, List

from .behavior import score_behavior
from .fingerprint import score_fingerprint
from .models import (Action, BehaviorWindow, RiskLevel, RiskReport,
                     SignalResult)
from .timing import score_timing
from .touch import score_touch
from .util import clamp

# 各信号权重：触控与指纹是最难伪造的物理层/环境层证据，权重最高
WEIGHTS = {"touch": 0.30, "timing": 0.22, "fingerprint": 0.28, "behavior": 0.20}

# 分数 -> 动作阈值（按分数降序匹配）
_THRESHOLDS = [
    (0.92, Action.BLOCK),
    (0.78, Action.STEP_UP_AUTH),
    (0.60, Action.SLIDER),
    (0.42, Action.SILENT_CHALLENGE),
    (0.25, Action.OBSERVE),
    (0.00, Action.ALLOW),
]

_CHALLENGE = {
    Action.ALLOW: None,
    Action.OBSERVE: None,
    Action.SILENT_CHALLENGE: "silent_nonce",
    Action.SLIDER: "slider",
    Action.STEP_UP_AUTH: "step_up_auth",   # 短信/人脸，由账号本人完成
    Action.THROTTLE: None,
    Action.BLOCK: None,
}

# 强校验及以上的动作，至少需要连续几个高风险窗口才允许升级
_ESCALATION_WINDOWS = 2
_DEESCALATION_WINDOWS = 3
_COOLDOWN_TICKS = 3          # 演示用逻辑时钟；生产用 wall-clock TTL


@dataclass
class _AccountState:
    ema: float = 0.0
    tick: int = 0
    high_streak: int = 0
    low_streak: int = 0
    last_action: str = Action.ALLOW
    cooldown_until: int = 0

    def to_dict(self) -> Dict[str, object]:
        return {"ema": self.ema, "tick": self.tick,
                "high_streak": self.high_streak, "low_streak": self.low_streak,
                "last_action": self.last_action, "cooldown_until": self.cooldown_until}

    @classmethod
    def from_dict(cls, d: Dict[str, object] | None) -> "_AccountState":
        if not d:
            return cls()
        return cls(float(d.get("ema", 0.0)), int(d.get("tick", 0)),
                   int(d.get("high_streak", 0)), int(d.get("low_streak", 0)),
                   str(d.get("last_action", Action.ALLOW)),
                   int(d.get("cooldown_until", 0)))


def _action_for(score: float, thresholds: List[tuple]) -> str:
    for th, act in thresholds:
        if score >= th:
            return act
    return Action.ALLOW


def _level_for(score: float) -> str:
    if score >= 0.85:
        return RiskLevel.CRITICAL
    if score >= 0.62:
        return RiskLevel.HIGH
    if score >= 0.35:
        return RiskLevel.ELEVATED
    return RiskLevel.LOW


class RiskEngine:
    """
    有状态的风险决策器。

    - weights / thresholds / challenge_map 均可由后台配置热更新；
    - state_store 为可选外部状态存储，需实现 load(account_id)->dict|None
      与 save(account_id, dict)；不传则使用进程内字典（便于单测与本地演示）。
      生产/多实例部署务必外置，否则迟滞状态会在重启后丢失。
    """

    def __init__(self, weights: Dict[str, float] | None = None,
                 thresholds: List[tuple] | None = None,
                 challenge_map: Dict[str, object] | None = None,
                 state_store=None) -> None:
        self.weights = dict(weights or WEIGHTS)
        self.thresholds = list(thresholds or _THRESHOLDS)
        self.challenge_map = dict(challenge_map or _CHALLENGE)
        self.state_store = state_store
        self._states: Dict[str, _AccountState] = {}

    def configure(self, weights=None, thresholds=None) -> None:
        """热更新配置；不重置迟滞状态，避免配置调整被用来'洗白'账号。"""
        if weights:
            self.weights = dict(weights)
        if thresholds:
            self.thresholds = list(thresholds)

    def reset(self, account_id: str = "") -> None:
        if account_id:
            self._states.pop(account_id, None)
            if self.state_store is not None:
                self.state_store.save(account_id, {})
        else:
            self._states.clear()
            if self.state_store is not None and hasattr(self.state_store, "clear"):
                self.state_store.clear()

    @staticmethod
    def collect_signals(w: BehaviorWindow) -> List[SignalResult]:
        """四路信号并行可算（纯函数），便于网关里做真正的并发。"""
        return [
            score_touch(w.swipes, w.swipe_history),
            score_timing(w.watches),
            score_fingerprint(w.fingerprints, w.fp_account_map, w.account_fp_history),
            score_behavior(w),
        ]

    @staticmethod
    def fuse(signals: List[SignalResult], weights: Dict[str, float]) -> float:
        num = den = 0.0
        peak = 0.0
        for s in signals:
            w = weights.get(s.name, 0.0)
            eff = w * max(s.confidence, 0.05)
            num += eff * s.score
            den += eff
            peak = max(peak, s.score * s.confidence)
        base = num / den if den > 1e-9 else 0.0
        return clamp(0.68 * base + 0.32 * peak)

    def evaluate(self, w: BehaviorWindow) -> RiskReport:
        signals = self.collect_signals(w)
        score = self.fuse(signals, self.weights)
        reasons = [f"[{s.name}] {r}" for s in signals for r in s.reasons]

        # 硬标记：自动化运行时特征命中时抬到下限并强制升级
        escalate = any(s.metrics.get("__escalate__", 0) >= 1 for s in signals)
        if escalate:
            score = max(score, 0.86)

        if self.state_store is not None:
            st = _AccountState.from_dict(self.state_store.load(w.account_id))
        else:
            st = self._states.setdefault(w.account_id, _AccountState())
        st.tick += 1
        st.ema = 0.60 * score + 0.40 * st.ema if st.tick > 1 else score
        effective = clamp(0.75 * score + 0.25 * st.ema)

        desired = _action_for(effective, self.thresholds)
        desired_rank = Action.ORDER.index(desired)
        current_rank = Action.ORDER.index(st.last_action)

        # 在冷却期内维持既有处置，不因单窗口分数回落而立即放行
        if st.tick <= st.cooldown_until and current_rank >= Action.ORDER.index(Action.SLIDER):
            action = st.last_action
            st.high_streak, st.low_streak = 0, 0
        elif desired_rank > current_rank:
            # 升级：强校验及以上要求连续命中
            st.high_streak += 1
            st.low_streak = 0
            # 硬自动化特征属于确定性证据，无需等待多窗口确认，立即升级；
            # 仅统计型证据才要求连续命中，避免正常用户被偶发抖动误伤。
            need = 1 if escalate else (
                _ESCALATION_WINDOWS if desired_rank >= Action.ORDER.index(Action.SLIDER) else 1)
            action = desired if st.high_streak >= need else st.last_action
        elif desired_rank < current_rank:
            st.low_streak += 1
            st.high_streak = 0
            action = desired if st.low_streak >= _DEESCALATION_WINDOWS else st.last_action
        else:
            st.high_streak = st.low_streak = 0
            action = desired

        if action != st.last_action and Action.ORDER.index(action) >= Action.ORDER.index(Action.SLIDER):
            st.cooldown_until = st.tick + _COOLDOWN_TICKS
        st.last_action = action
        if self.state_store is not None:
            self.state_store.save(w.account_id, st.to_dict())

        # 统一外形响应：不泄露任何判定理由、单项分数或命中的规则
        challenge = self.challenge_map.get(action)
        nonce = None
        if challenge:
            seed = f"{w.account_id}|{w.window_id}|{time.time_ns()}".encode()
            nonce = hashlib.sha256(seed).hexdigest()[:24]
        # response 的字段集合恒定；retry_after 只在限流/阻断时非零，
        # 且始终不携带 reasons / 单项分数 / 命中规则，避免沦为规则探测接口。
        public = {
            "status": "ok",
            "challenge": challenge,
            "nonce": nonce,
            "retry_after": 60 if action in (Action.THROTTLE, Action.BLOCK) else 0,
        }

        return RiskReport(
            account_id=w.account_id, window_id=w.window_id,
            level=_level_for(effective), action=action, score=effective,
            signals=signals, reasons=reasons, public_response=public,
        )
