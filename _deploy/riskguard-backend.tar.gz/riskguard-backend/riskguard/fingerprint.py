# -*- coding: utf-8 -*-
"""
设备指纹一致性与自动化运行时特征检测（防御侧）。

两类证据：
  A. 硬特征：navigator.webdriver=true、CDP 注入痕迹、无头浏览器指纹等。
     这类特征单独不足以定罪（企业托管浏览器也可能带），但足以触发强校验。
  B. 交叉一致性：UA / 平台 / 屏幕 / DPR / WebGL 渲染器 / 时区 / 语言 / IP 归属地
     之间必须自洽。动态轮换指纹最容易在这里露馅 —— 随机拼出来的设备
     几乎必然存在物理上不可能的组合（例如 Windows + Apple GPU）。
  C. 关联图：同一指纹挂大量账号、同一账号短期内指纹频繁漂移，是群控农场的强信号。

注意：这里做的是**校验**，不是采集更激进的指纹；落地时需符合《个人信息保护法》
最小必要原则，人脸等生物特征不进入本模块。
"""
from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

from .models import Fingerprint, SignalResult
from .util import clamp, ramp

# 极简的区域—时区—语言先验表，生产环境应替换为完整的 GeoIP / tzdata 映射
_REGION_PROFILE = {
    "CN": ({"Asia/Shanghai"}, {"zh", "zh-CN"}),
    "US": ({"America/New_York", "America/Los_Angeles", "America/Chicago"}, {"en", "en-US"}),
    "JP": ({"Asia/Tokyo"}, {"ja", "ja-JP"}),
}

_MOBILE_GPU = ("apple gpu", "mali", "adreno", "powervr", "mediatek")
_DESKTOP_GPU = ("nvidia", "geforce", "radeon", "intel", "angle (")
_PLAUSIBLE_MEMORY = {0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0}


def check_hard_automation(fp: Fingerprint) -> List[str]:
    """返回硬自动化特征列表。命中即触发 escalate=True。"""
    hits: List[str] = []
    ua = fp.ua.lower()
    if fp.webdriver:
        hits.append("navigator.webdriver=true")
    if "headless" in ua or "phantomjs" in ua or "electron/" in ua and fp.plugins_count == 0:
        hits.append("UA 含无头/自动化运行时标识")
    if "chrome/" in ua and "windows" in ua.lower() + fp.platform.lower() and not fp.has_chrome_object:
        hits.append("Chrome UA 但 window.chrome 对象缺失")
    if fp.plugins_count == 0 and not any(k in ua for k in ("android", "iphone", "mobile")):
        hits.append("桌面 UA 但 navigator.plugins 为空（典型无头环境）")
    if fp.touch_max_points < 2 and any(k in ua for k in ("android", "iphone", "mobile")):
        hits.append("移动端 UA 但不支持多点触控")
    if not fp.accelerometer and any(k in ua for k in ("android", "iphone", "mobile")):
        hits.append("移动端 UA 但加速度计不可用")
    return hits


def check_consistency(fp: Fingerprint) -> List[str]:
    """返回交叉一致性冲突列表，每条都是物理/逻辑上不该出现的组合。"""
    bad: List[str] = []
    ua, plat = fp.ua.lower(), fp.platform.lower()

    # 操作系统与 UA 冲突
    if "windows" in plat and any(k in ua for k in ("android", "iphone", "mac os x")):
        bad.append("platform 与 UA 声明的操作系统冲突")
    if ("android" in ua or "iphone" in ua) and ("windows" in plat or "mac" in plat):
        bad.append("移动 UA 却声明桌面 platform")

    # GPU 渲染器与操作系统冲突（指纹随机拼接最常见的破绽）
    r = fp.webgl_renderer.lower()
    v = fp.webgl_vendor.lower()
    if any(g in r for g in _MOBILE_GPU) and ("windows" in plat or "win32" in ua):
        bad.append("Windows 设备上报移动端 GPU 渲染器")
    if any(g in r for g in _DESKTOP_GPU) and ("android" in ua or "iphone" in ua):
        bad.append("移动设备上报桌面级 GPU 渲染器")
    if "swiftshader" in r or "llvmpipe" in r:
        bad.append("WebGL 使用软件渲染器（虚拟化/无头环境）")
    if not r.strip() or not v.strip():
        bad.append("WebGL vendor/renderer 为空（指纹抹除痕迹）")

    # 屏幕与 DPR
    if "iphone" in ua and (fp.screen_w > 1400 or fp.dpr not in (2.0, 3.0)):
        bad.append("iPhone UA 的分辨率/DPR 不符合机型枚举")
    if "android" in ua and fp.screen_w > 0 and fp.screen_h > 0 and fp.screen_w > fp.screen_h:
        bad.append("移动端竖屏场景下宽大于高")
    if fp.dpr <= 0 or fp.dpr > 5:
        bad.append("devicePixelRatio 超出物理合理范围")

    # 硬件参数枚举合理性
    if fp.device_memory not in _PLAUSIBLE_MEMORY:
        bad.append("deviceMemory 非标准枚举值（疑似随机生成）")
    if fp.hardware_concurrency <= 0 or fp.hardware_concurrency > 128:
        bad.append("hardwareConcurrency 超出合理范围")
    if fp.screen_w < 240 or fp.screen_h < 240:
        bad.append("屏幕尺寸低于可用设备下限")

    # 区域先验
    prof = _REGION_PROFILE.get(fp.ip_region.upper())
    if prof:
        tzs, langs = prof
        if fp.timezone not in tzs:
            bad.append("时区与 IP 归属地不一致")
        if fp.languages and fp.languages[0].split("-")[0].lower() not in {
                x.split("-")[0].lower() for x in langs}:
            bad.append("首选语言与 IP 归属地不一致")
    return bad


def graph_evidence(fp_account_map: Dict[str, List[str]],
                   account_fp_history: Dict[str, List[str]]) -> Tuple[float, float, List[str]]:
    """返回 (最大单指纹账号数, 最大单账号指纹漂移数, 原因列表)。"""
    reasons: List[str] = []
    max_accounts = max((len(v) for v in fp_account_map.values()), default=0)
    max_drift = max((len(set(v)) for v in account_fp_history.values()), default=0)
    if max_accounts >= 5:
        reasons.append(f"同一设备指纹关联 {max_accounts} 个账号（群控特征）")
    elif max_accounts >= 3:
        reasons.append(f"同一设备指纹关联 {max_accounts} 个账号，需观察")
    if max_drift >= 4:
        reasons.append(f"单账号短期内出现 {max_drift} 套指纹（轮换特征）")
    return float(max_accounts), float(max_drift), reasons


def score_fingerprint(fingerprints: Sequence[Fingerprint],
                      fp_account_map: Dict[str, List[str]],
                      account_fp_history: Dict[str, List[str]]) -> SignalResult:
    hard_hits: List[str] = []
    conflicts: List[str] = []
    for fp in fingerprints:
        hard_hits.extend(check_hard_automation(fp))
        conflicts.extend(f"{fp.device_id}: {c}" for c in check_consistency(fp))

    max_accounts, max_drift, graph_reasons = graph_evidence(fp_account_map, account_fp_history)
    m = {
        "fingerprint_samples": float(len(fingerprints)),
        "hard_automation_hits": float(len(hard_hits)),
        "consistency_conflicts": float(len(conflicts)),
        "max_accounts_per_fp": max_accounts,
        "max_fp_drift_per_account": max_drift,
    }

    e_hard = 1.0 if hard_hits else 0.0
    e_conflict = ramp(len(conflicts), 0.0, 4.0)
    e_farm = ramp(max_accounts, 2.0, 12.0)
    e_rotation = ramp(max_drift, 1.0, 6.0)

    parts = {
        "检测到自动化运行时特征": (e_hard, 0.42),
        "设备指纹存在交叉一致性冲突": (e_conflict, 0.24),
        "单指纹关联过多账号": (e_farm, 0.20),
        "单账号指纹频繁轮换": (e_rotation, 0.14),
    }
    score = sum(v * w for v, w in parts.values())
    # 硬特征命中时给一个下限，避免被其它信号稀释
    if hard_hits:
        score = max(score, 0.78)

    reasons = list(dict.fromkeys(
        (["检测到自动化运行时特征：" + "、".join(sorted(set(hard_hits)))] if hard_hits else [])
        + conflicts[:6] + graph_reasons
    ))
    if not reasons:
        reasons.append("设备指纹自洽，未见自动化运行时特征")

    conf = 0.45 if not fingerprints else clamp(0.65 + 0.05 * len(fingerprints), 0.0, 1.0)
    sig = SignalResult("fingerprint", clamp(score), conf, reasons,
                       {k: round(v, 6) for k, v in m.items()})
    # 供融合层读取的硬标记（不写入公开响应）
    sig.metrics["__escalate__"] = 1.0 if hard_hits else 0.0
    return sig
