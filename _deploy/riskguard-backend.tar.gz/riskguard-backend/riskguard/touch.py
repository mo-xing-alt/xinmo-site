# -*- coding: utf-8 -*-
"""
触控信号真实性检测 —— 对付"贝塞尔曲线拟人化"的核心模块。

为什么纯软件的拟人轨迹会被抓：
  合成轨迹再怎么加缓动，它仍然是**解析函数**。解析函数的高频残差接近 0、
  曲率符号恒定、采样间隔恒定、压力恒定，而且不同次手势归一化后几乎重合。
  真人的手是带生理性震颤（约 8~12Hz）的机械系统：有高频微颤、有采样抖动、
  压力随速度变化、每次轨迹形状都不同、中途有微小修正折点。

本模块不看"轨迹像不像曲线"，只看上述物理层信号的**是否存在**。
"""
from __future__ import annotations

import math
from typing import List, Optional, Sequence, Tuple

from .models import SignalResult, Swipe
from .util import clamp, decay, mean, pearson, pstdev, ramp


def high_frequency_residual(s: Swipe) -> Tuple[float, float]:
    """
    用 5 点二次 Savitzky-Golay 拟合剔除局部趋势，取残差。

    为什么不用简单二阶差分：带缓动的解析曲线（如 3u²-2u³）其二阶差分
    本身就不小，会与真人震颤混淆。局部二次拟合能把这类低频曲率整体吃掉，
    剩下的只有真正的高频分量 —— 真人约 0.5~1.5px，解析曲线接近浮点噪声。

    返回 (残差 RMS(px), y 方向残差符号翻转率)。真人的残差近似白噪声，
    翻转率接近 0.5；解析曲线残差符号连续，翻转率接近 0。
    """
    pts = s.points
    if len(pts) < 7:
        return 0.0, 0.0
    # SG(5,2) 平滑系数
    c = (-3.0 / 35, 12.0 / 35, 17.0 / 35, 12.0 / 35, -3.0 / 35)
    mags, signed_y = [], []
    for i in range(2, len(pts) - 2):
        sx = sum(w * pts[i + k].x for k, w in zip(range(-2, 3), c))
        sy = sum(w * pts[i + k].y for k, w in zip(range(-2, 3), c))
        rx, ry = pts[i].x - sx, pts[i].y - sy
        mags.append(math.hypot(rx, ry))
        signed_y.append(ry)
    if not mags:
        return 0.0, 0.0
    rms = math.sqrt(sum(m * m for m in mags) / len(mags))
    flips = sum(1 for a, b in zip(signed_y, signed_y[1:])
                if (a >= 0) != (b >= 0))
    flip_rate = flips / max(len(signed_y) - 1, 1)
    return rms, flip_rate


def sampling_jitter(s: Swipe) -> Tuple[float, float]:
    """采样间隔 dt 的变异系数与唯一值占比。恒 16ms 的注入序列 CV≈0。"""
    dts = [b.t - a.t for a, b in zip(s.points, s.points[1:])]
    dts = [d for d in dts if d > 0]
    if len(dts) < 5:
        return 0.0, 1.0
    m = mean(dts)
    cv = pstdev(dts) / m if m > 1e-9 else 0.0
    unique_ratio = len(set(round(d, 3) for d in dts)) / len(dts)
    return cv, unique_ratio


def pressure_dynamics(s: Swipe) -> Tuple[float, float, float]:
    """
    返回 (压力标准差, 面积标准差, 压力-速度相关系数)。
    注入式手势通常 pressure 恒为 1.0 / area 恒为 0 → 两个标准差都是 0。
    真人慢速段按得更实，压力与速度呈负相关。
    """
    pts = s.points
    if len(pts) < 6:
        return 0.0, 0.0, 0.0
    pres = [p.pressure for p in pts]
    areas = [p.area for p in pts]
    speeds = []
    for a, b in zip(pts, pts[1:]):
        dt = max(b.t - a.t, 1e-6)
        speeds.append(math.hypot(b.x - a.x, b.y - a.y) / dt)
    # 用相邻两点压力均值对齐速度序列
    pres_mid = [(a + b) / 2.0 for a, b in zip(pres, pres[1:])]
    corr = -pearson(speeds, pres_mid) if len(speeds) >= 4 else 0.0
    return pstdev(pres), pstdev(areas), corr


def curvature_corrections(s: Swipe) -> float:
    """
    统计方向角的符号翻转次数（归一化到点数），代表中途微修正。
    单一三次贝塞尔几乎不会翻转；真人会在滑动中做 1~3 次微调。
    """
    pts = s.points
    if len(pts) < 8:
        return 0.0
    angles = [math.atan2(b.y - a.y, b.x - a.x) for a, b in zip(pts, pts[1:])]
    diffs = [b - a for a, b in zip(angles, angles[1:])]
    # 归一化角度差到 [-pi, pi]
    diffs = [(d + math.pi) % (2 * math.pi) - math.pi for d in diffs]
    flips = sum(1 for a, b in zip(diffs, diffs[1:])
                if abs(a) > 1e-6 and abs(b) > 1e-6 and (a > 0) != (b > 0))
    return flips / max(len(diffs), 1)


def template_repetition(swipes: Sequence[Swipe]) -> Tuple[float, int]:
    """
    跨手势的"形状指纹"平均两两距离。

    这是最致命的判据之一：脚本为了拟人往往复用同一组贝塞尔控制点（或同一套
    随机种子范围），把轨迹按位移归一化后几乎完全重合；真人每次都不同。
    返回 (平均归一化 L2 距离, 参与比对的配对数)。
    """
    shapes: List[List[Tuple[float, float]]] = []
    for s in swipes:
        n = s.normalized(32)
        if n:
            shapes.append(n)
    if len(shapes) < 2:
        return 1.0, 0
    total, pairs = 0.0, 0
    for i in range(len(shapes)):
        for j in range(i + 1, len(shapes)):
            a, b = shapes[i], shapes[j]
            d = math.sqrt(sum((u[0] - v[0]) ** 2 + (u[1] - v[1]) ** 2
                              for u, v in zip(a, b)) / len(a))
            total += d
            pairs += 1
    return total / pairs, pairs


def score_touch(swipes: Sequence[Swipe],
                swipe_history: Sequence[Swipe] = ()) -> SignalResult:
    """
    汇总触控层证据。所有阈值都是**相对量**，与设备分辨率、DPI 无关，
    生产上线前需用自有标注数据重新标定（见 README 中的说明）。
    """
    # 历史手势一并纳入模板比对：跨窗口复用同一轨迹生成器照样会露馅
    pool: List[Swipe] = list(swipes) + list(swipe_history)
    valid = [s for s in pool if len(s.points) >= 7]
    if not valid:
        return SignalResult("touch", 0.0, 0.0,
                            ["无有效触控序列，跳过该信号"],
                            {"valid_swipes": 0})

    hf_list, flip_list, cv_list, uniq_list = [], [], [], []
    pstd_list, astd_list, pcorr_list, corr_list = [], [], [], []
    for s in valid[:40]:                      # 单窗口最多取 40 次，防止计算放大
        rms, fr = high_frequency_residual(s)
        hf_list.append(rms)
        flip_list.append(fr)
        cv, uq = sampling_jitter(s)
        cv_list.append(cv)
        uniq_list.append(uq)
        ps, ar, pc = pressure_dynamics(s)
        pstd_list.append(ps)
        astd_list.append(ar)
        pcorr_list.append(pc)
        corr_list.append(curvature_corrections(s))

    avg_tpl, pairs = template_repetition(pool[:40])
    m = {
        "hf_residual_px": mean(hf_list),
        "hf_sign_flip_rate": mean(flip_list),
        "dt_cv": mean(cv_list),
        "dt_unique_ratio": mean(uniq_list),
        "pressure_std": mean(pstd_list),
        "area_std": mean(astd_list),
        "pressure_speed_corr": mean(pcorr_list),
        "curvature_flip_rate": mean(corr_list),
        "template_distance": avg_tpl,
        "template_pairs": float(pairs),
        "valid_swipes": float(len(valid)),
    }

    reasons: List[str] = []
    # 各子判据 0..1，越高越像机器
    e_tremor = decay(m["hf_residual_px"], 0.02, 0.55)          # 残差太小 = 解析曲线
    e_flip = decay(m["hf_sign_flip_rate"], 0.10, 0.42)          # 不交替 = 平滑曲线
    e_jitter = decay(m["dt_cv"], 0.015, 0.12)                   # 采样间隔过于恒定
    e_unique = decay(m["dt_unique_ratio"], 0.55, 0.95)          # dt 取值高度重复
    e_pressure = decay(m["pressure_std"], 0.004, 0.05)          # 压力恒定
    e_area = decay(m["area_std"], 0.004, 0.05)                  # 接触面积恒定
    e_corr = decay(m["pressure_speed_corr"], 0.02, 0.30)        # 无"慢=按得实"关系
    e_curve = decay(m["curvature_flip_rate"], 0.010, 0.10)      # 没有中途修正
    e_template = decay(m["template_distance"], 0.004, 0.055)    # 轨迹形状复用

    parts = {
        "高频微颤缺失": (e_tremor, 0.18),
        "残差符号不交替（解析曲线特征）": (e_flip, 0.12),
        "采样间隔恒定": (e_jitter, 0.14),
        "采样间隔取值重复": (e_unique, 0.08),
        "压力恒定": (e_pressure, 0.14),
        "接触面积恒定": (e_area, 0.06),
        "压力-速度无相关": (e_corr, 0.06),
        "无中途方向修正": (e_curve, 0.08),
        "跨手势轨迹模板高度复用": (e_template, 0.14),
    }
    score = sum(v * w for v, w in parts.values())
    for name, (v, _) in parts.items():
        if v > 0.65:
            reasons.append(name)

    # 证据充足度：手势越多、模板配对越多，结论越稳
    conf = clamp(0.35 + 0.05 * len(valid) + 0.15 * min(pairs / 20.0, 1.0), 0.0, 1.0)
    if not reasons:
        reasons.append("触控信号存在生理性微颤与手间差异，未见合成特征")
    return SignalResult("touch", clamp(score), conf, reasons,
                        {k: round(v, 6) for k, v in m.items()})
