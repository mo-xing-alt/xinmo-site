# -*- coding: utf-8 -*-
"""
观看时长与互动行为的统计合理性检测。

脚本的典型破绽不在"时长太短"，而在于**随机数被写坏了**：
  1) round(random.gauss(...), 1) 会把连续时长压到 0.1s 网格上，
     小数第二位永远为 0 —— 真人的毫秒级时钟不可能这样；
  2) 截断到 [8, 35] 会在边界 8.0 / 35.0 堆积，且分布异常对称（偏度≈0），
     真人停留是右偏重尾（lognormal / 幂律截断）；
  3) 每帧 i.i.d. 采样 → 一阶自相关≈0，真人则有状态（疲劳、内容偏好连续）；
  4) "15% 概率点赞"与内容、观看时长完全独立，
     真人点赞概率与停留时长显著正相关（点二列相关 > 0.2）。
"""
from __future__ import annotations

from typing import List, Sequence

from .models import SignalResult, WatchRecord
from .util import (clamp, decay, ks_stat_vs_fitted_normal, lag1_autocorr,
                   mean, point_biserial, ramp, shannon_entropy, skewness)


def quantization_evidence(vals: Sequence[float]) -> tuple:
    """
    返回 (0.1s 网格占比, 整秒占比, 小数第二位熵, 重复值占比)。
    熵为 0 说明小数位完全确定 —— 几乎只可能是量化过的脚本数据。
    """
    if not vals:
        return 0.0, 0.0, 1.0, 0.0
    n = len(vals)
    grid01 = sum(1 for v in vals if abs(v - round(v, 1)) < 1e-6) / n
    grid1 = sum(1 for v in vals if abs(v - round(v)) < 1e-6) / n
    # 取小数第二位数字（0..9）；真实连续时长应接近均匀分布 → 熵≈1
    digits = [int(round((v - int(v)) * 100)) % 10 for v in vals]
    ent = shannon_entropy(digits, base=10)
    dup = 1.0 - len(set(round(v, 6) for v in vals)) / n
    return grid01, grid1, ent, dup


def distribution_evidence(vals: Sequence[float]) -> tuple:
    """返回 (偏度, 边界堆积比例, KS 拟合优度)。"""
    if len(vals) < 5:
        return 0.0, 0.0, 1.0
    sk = skewness(vals)
    lo, hi = min(vals), max(vals)
    # 截断实现通常写成 max(8, min(35, gauss()))，边界值会成批出现。
    # 注意：连续数据天然也会各有一个 min/max，因此只统计"重复出现"的边界值，
    # 否则会把真人样本误判成截断堆积。
    eps = 1e-6
    n_lo = sum(1 for v in vals if abs(v - lo) < eps)
    n_hi = sum(1 for v in vals if abs(v - hi) < eps)
    # 全常量序列时 lo==hi，只统计一次，避免 pile>1
    dup_boundary = (n_lo if n_lo >= 2 else 0)
    if n_hi >= 2 and hi - lo > eps:
        dup_boundary += n_hi
    pile = min(1.0, dup_boundary / len(vals))
    return sk, pile, ks_stat_vs_fitted_normal(vals)


def score_timing(watches: Sequence[WatchRecord]) -> SignalResult:
    vals = [w.duration_s for w in watches if not w.is_live and w.duration_s > 0]
    if len(vals) < 5:
        return SignalResult("timing", 0.0, 0.0,
                            ["有效观看样本不足，跳过该信号"], {"samples": float(len(vals))})

    g01, g1, ent, dup = quantization_evidence(vals)
    sk, pile, ks = distribution_evidence(vals)
    ac = lag1_autocorr(vals)
    liked = [1 if w.liked else 0 for w in watches if not w.is_live and w.duration_s > 0]
    pb = point_biserial(liked, vals) if 0 < sum(liked) < len(liked) else 0.0

    m = {
        "grid_0.1s_ratio": g01, "grid_1s_ratio": g1,
        "decimal_entropy": ent, "duplicate_ratio": dup,
        "skewness": sk, "boundary_pileup": pile,
        "ks_vs_normal": ks, "lag1_autocorr": ac,
        "duration_like_point_biserial": pb, "samples": float(len(vals)),
    }

    # 各子判据 0..1，越高越像机器
    e_grid = max(ramp(g01, 0.55, 0.98), ramp(g1, 0.35, 0.90))
    e_entropy = decay(ent, 0.12, 0.80)             # 小数位熵过低
    e_dup = ramp(dup, 0.05, 0.35)                 # 大量完全相同的值
    e_skew = decay(abs(sk), 0.15, 1.10)           # 过于对称（截断高斯）
    e_pile = ramp(pile, 0.06, 0.30)               # 上下界堆积 = 硬截断
    e_normal = decay(ks, 0.045, 0.16)             # 拟合正态拟合得"过好"
    e_iid = decay(abs(ac), 0.03, 0.28)            # 相邻时长完全独立
    # 弱信号：小窗口下点二列相关本身噪声就大，只作为长周期佐证，权重压低。
    e_indep = decay(pb, -0.10, 0.40) if sum(liked) >= 3 else 0.25

    parts = {
        "观看时长落在 0.1s/整秒网格（疑似 round()）": (e_grid, 0.22),
        "小数位熵接近 0（时长被量化）": (e_entropy, 0.18),
        "存在大量完全重复的时长值": (e_dup, 0.09),
        "时长分布异常对称，无真人右偏重尾": (e_skew, 0.13),
        "上下界出现截断堆积": (e_pile, 0.08),
        "时长过度贴合正态分布": (e_normal, 0.08),
        "相邻观看时长无状态相关性（i.i.d. 采样）": (e_iid, 0.12),
        "点赞与观看时长无关（固定概率触发）": (e_indep, 0.10),
    }
    score = sum(v * w for v, w in parts.values())
    reasons = [name for name, (v, _) in parts.items() if v > 0.62]
    if not reasons:
        reasons.append("时长为连续值且右偏、互动与内容相关，符合真人特征")

    conf = clamp(0.25 + 0.018 * len(vals), 0.0, 1.0)
    return SignalResult("timing", clamp(score), conf, reasons,
                        {k: round(v, 6) for k, v in m.items()})
