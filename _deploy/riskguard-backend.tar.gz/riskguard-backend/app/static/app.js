/* RiskGuard Console · 纯原生前端，无外部依赖 */
'use strict';

// 静态前端部署到其它源（例如 GitHub Pages）时，由 config.js 注入后端地址。
// 留空则同源，保持本地开发默认行为。
const API_BASE = (window.RISKGUARD_API_BASE || '').replace(/\/+$/, '');
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LV = {LOW:'低风险',ELEVATED:'需关注',HIGH:'高风险',CRITICAL:'严重'};
const AC = {ALLOW:'放行',OBSERVE:'加密采样',SILENT_CHALLENGE:'无感挑战',SLIDER:'滑块验证',STEP_UP_AUTH:'二次校验',THROTTLE:'限流',BLOCK:'阻断'};
const SL = {touch:'触控信号真实性',timing:'时长与互动统计',fingerprint:'设备指纹与运行时',behavior:'账号级行为约束'};
const LV_COLOR = {LOW:'#15a34a',ELEVATED:'#d99317',HIGH:'#e9681f',CRITICAL:'#d92d20'};
const scoreColor = s => s>=.62?'#d92d20':s>=.35?'#e9681f':s>=.15?'#d99317':'#15a34a';
const fmt = ts => { const d=new Date(ts*1000); const p=n=>String(n).padStart(2,'0');
  return `${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; };
const bar = (v,c) => `<div class="bar"><div style="width:${Math.round(Math.max(0,Math.min(1,v))*100)}%;background:${c||scoreColor(v)}"></div></div>`;

const S = {page:'overview', overview:null, events:[], cases:[], config:null,
  alerts:[], audit:[], demo:null, sample:null, caseStatus:'OPEN',
  filters:{level:'',action:'',account:''}, autoRefresh:false, timer:null};

/* ------------------------------------------------------------------ 基础 */
async function api(path, opts={}){
  const res = await fetch(API_BASE + path,
    {credentials: API_BASE ? 'include' : 'same-origin', ...opts,
    headers:{'Content-Type':'application/json', ...(opts.headers||{})}});
  let d={}; try{ d=await res.json(); }catch(e){}
  if(res.status===401 && !path.includes('/auth/login')){ showLogin(); throw new Error('未登录'); }
  if(!res.ok) throw new Error(d.error==='bad request' ? (d.detail||d.error) : (d.error||d.detail||('HTTP '+res.status)));
  return d;
}
const post = (p,b) => api(p,{method:'POST',body:JSON.stringify(b||{})});

function toast(msg,bad){
  const t=$('#toast'); t.textContent=msg; t.style.background=bad?'#b42318':'#1d2739';
  t.classList.remove('hidden'); clearTimeout(t._t); t._t=setTimeout(()=>t.classList.add('hidden'),2800);
}
function showLogin(){ $('#login').classList.remove('hidden'); $('#shell').classList.add('hidden'); }
function showShell(){ $('#login').classList.add('hidden'); $('#shell').classList.remove('hidden'); }
function openDrawer(html){ $('#drawer-body').innerHTML=html; $('#drawer').classList.remove('hidden'); $('#drawer-mask').classList.remove('hidden'); }
function closeDrawer(){ $('#drawer').classList.add('hidden'); $('#drawer-mask').classList.add('hidden'); }
function closeModal(){ $('#modal').classList.add('hidden'); }
function openModal(title,body,onOk){
  $('#modal-title').textContent=title; $('#modal-body').innerHTML=body;
  $('#modal').classList.remove('hidden'); $('#modal-ok').onclick=async()=>{ if(await onOk()!==false) closeModal(); };
}

/* -------------------------------------------------------------- 页面路由 */
const TITLES = {
  overview:['总览看板','近 24 小时行为窗口与处置概览'],
  events:['实时事件','全部判定窗口、信号明细与原始上报回放'],
  cases:['案件复核','高风险案件由人工最终裁决，系统不自动封号'],
  config:['规则配置','权重、阈值、告警渠道与演示数据热更新'],
  docs:['接入与调试','SDK 接入说明、字段契约与在线判定调试']
};
function go(page){
  if(!TITLES[page]) page='overview';
  S.page=page; if(location.hash.slice(1)!==page) location.hash=page;
  $$('#nav a').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  $('#page-title').textContent=TITLES[page][0]; $('#page-sub').textContent=TITLES[page][1];
  refresh();
}
async function refresh(){
  try{
    if(S.page==='overview') await loadOverview();
    else if(S.page==='events') await loadEvents();
    else if(S.page==='cases') await loadCases();
    else if(S.page==='config') await loadConfig();
    else if(S.page==='docs') await loadDocs();
  }catch(e){ toast('加载失败：'+e.message,true); }
}

/* ---------------------------------------------------------------- 总览 */
async function loadOverview(){
  S.overview = await api('/api/overview?hours=24');
  const o=S.overview;
  const kpi=(lab,val,sub,cls)=>`<div class="kpi ${cls}"><div class="lab"><span>${lab}</span></div>
     <div class="val">${val}</div><div class="sub">${sub}</div></div>`;
  const lv=o.levels||{}, ac=o.actions||{};
  const lvRows=['CRITICAL','HIGH','ELEVATED','LOW'].map(k=>
    `<div class="dist-row"><span class="k">${LV[k]}</span>${bar((lv[k]||0)/Math.max(1,o.windows),LV_COLOR[k])}<span class="v">${lv[k]||0}</span></div>`).join('');
  const acRows=Object.keys(AC).filter(k=>ac[k]).map(k=>
    `<div class="dist-row"><span class="k">${AC[k]}</span>${bar((ac[k]||0)/Math.max(1,o.windows),'#2f63f5')}<span class="v">${ac[k]||0}</span></div>`).join('') || '<div class="note">暂无处置记录</div>';
  const top=(o.top_accounts||[]).map(r=>`<tr><td class="mono">${esc(r.account_id)}</td><td>${r.n}</td>
    <td class="mono">${Number(r.avg_score).toFixed(3)}</td><td class="mono" style="color:${scoreColor(r.max_score)}">${Number(r.max_score).toFixed(3)}</td></tr>`).join('');
  const recent=(o.recent||[]).map(r=>`<tr><td class="mono">${fmt(r.received_at)}</td>
    <td class="mono">${esc(r.account_id)}</td><td class="mono">${Number(r.score).toFixed(3)}</td>
    <td><span class="badge lv-${r.level}">${LV[r.level]||r.level}</span></td>
    <td>${AC[r.action]||r.action}</td><td><button class="btn sm" onclick="openWindow(${r.id})">详情</button></td></tr>`).join('');
  $('#view').innerHTML=`
    <div class="grid g4">
      ${kpi('近 24h 判定窗口',o.windows,'累计 '+o.windows_total+' 条','blue')}
      ${kpi('高风险窗口',o.risky,'HIGH + CRITICAL','red')}
      ${kpi('待复核案件',(o.cases&&o.cases.OPEN)||0,'需人工裁决','amber')}
      ${kpi('告警送达率',((o.alerts.rate||0)*100).toFixed(0)+'%',o.alerts.total+' 次推送 / '+o.alerts.ok+' 次成功','green')}
    </div>
    <div class="grid g2" style="margin-top:16px">
      <div class="panel"><h2>24 小时事件趋势</h2><p class="desc">柱：全部窗口数　折线：高风险窗口数</p>
        ${trendSvg(o.trend||[])}
        <div class="legend"><span><i style="background:#c9d8ff"></i>全部窗口</span><span><i style="background:#d92d20"></i>高风险窗口</span></div></div>
      <div class="panel"><h2>风险等级与处置分布</h2><p class="desc">按近 24 小时窗口统计</p>
        <div class="section-title">风险等级</div>${lvRows}<div class="hr"></div>
        <div class="section-title">处置动作</div>${acRows}</div>
    </div>
    <div class="grid g2">
      <div class="panel"><h2>高风险账号 Top 8</h2><p class="desc">按窗口最高风险分排序</p>
        <table><thead><tr><th>账号</th><th>窗口数</th><th>均分</th><th>最高分</th></tr></thead><tbody>${top||'<tr><td colspan="4" class="empty">暂无数据</td></tr>'}</tbody></table></div>
      <div class="panel"><h2>最近判定</h2><p class="desc">点击「详情」查看四路信号与原始上报</p>
        <table><thead><tr><th>时间</th><th>账号</th><th>分数</th><th>等级</th><th>处置</th><th></th></tr></thead><tbody>${recent||'<tr><td colspan="6" class="empty">暂无数据</td></tr>'}</tbody></table></div>
    </div>`;
}
function trendSvg(rows){
  const W=700,H=190,pad=26,n=rows.length||1;
  const max=Math.max(1,...rows.map(r=>r.total));
  const bw=(W-pad*2)/n;
  let bars='',pts=[];
  rows.forEach((r,i)=>{
    const h=(r.total/max)*(H-42), x=pad+i*bw+bw*0.18, y=H-24-h;
    bars+=`<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${(bw*0.64).toFixed(1)}" height="${Math.max(0,h).toFixed(1)}" rx="2" fill="#c9d8ff"/>`;
    const ry=H-24-(r.risky/max)*(H-42);
    pts.push(`${(pad+i*bw+bw/2).toFixed(1)},${ry.toFixed(1)}`);
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">
    <line x1="${pad}" y1="${H-24}" x2="${W-pad}" y2="${H-24}" stroke="#e5eaf2"/>
    <line x1="${pad}" y1="12" x2="${W-pad}" y2="12" stroke="#f0f3f8"/>
    ${bars}<polyline points="${pts.join(' ')}" fill="none" stroke="#d92d20" stroke-width="2" stroke-linejoin="round"/>
    </svg>`;
}

/* -------------------------------------------------------------- 实时事件 */
async function loadEvents(){
  const f=S.filters;
  const q=new URLSearchParams({limit:'100',hours:'24'});
  if(f.level) q.set('level',f.level); if(f.action) q.set('action',f.action); if(f.account) q.set('account',f.account);
  S.events=(await api('/api/windows?'+q)).rows||[];
  const opts=(obj,cur,all)=>`<option value="">${all}</option>`+Object.entries(obj).map(([k,v])=>
    `<option value="${k}" ${cur===k?'selected':''}>${v}</option>`).join('');
  const rows=S.events.map(r=>`<tr><td class="mono">${fmt(r.received_at)}</td>
    <td class="mono">${esc(r.window_id)}</td><td class="mono">${esc(r.account_id)}</td>
    <td class="mono" style="color:${scoreColor(r.score)};font-weight:650">${Number(r.score).toFixed(3)}</td>
    <td><span class="badge lv-${r.level}">${LV[r.level]||r.level}</span></td>
    <td>${AC[r.action]||r.action}</td><td><span class="tag ${r.source==='seed'?'':'on'}">${esc(r.source)}</span></td>
    <td><button class="btn sm" onclick="openWindow(${r.id})">详情</button></td></tr>`).join('');
  $('#view').innerHTML=`<div class="panel">
    <div class="rowline"><div><h2>判定窗口</h2><p class="desc" style="margin:0">共 ${S.events.length} 条 · 近 24 小时</p></div>
      <div style="display:flex;gap:8px"><label style="margin:0;display:flex;align-items:center;gap:6px">
        <input type="checkbox" id="autoref" ${S.autoRefresh?'checked':''}> 自动刷新</label>
        <a class="btn sm" href="${API_BASE}/api/export?kind=windows">导出 CSV</a></div></div>
    <div class="filters">
      <select id="f-level">${opts(LV,f.level,'全部等级')}</select>
      <select id="f-action">${opts(AC,f.action,'全部处置')}</select>
      <input id="f-account" placeholder="账号关键字" value="${esc(f.account)}" style="width:190px">
      <button class="btn primary sm" id="f-go">筛选</button>
      <button class="btn sm" id="f-reset">重置</button></div>
    <table><thead><tr><th>时间</th><th>窗口 ID</th><th>账号</th><th>分数</th><th>等级</th><th>处置</th><th>来源</th><th></th></tr></thead>
      <tbody>${rows||'<tr><td colspan="8" class="empty">没有符合条件的事件</td></tr>'}</tbody></table></div>`;
  $('#f-go').onclick=()=>{S.filters={level:$('#f-level').value,action:$('#f-action').value,account:$('#f-account').value.trim()};loadEvents();};
  $('#f-reset').onclick=()=>{S.filters={level:'',action:'',account:''};loadEvents();};
  $('#autoref').onchange=e=>{S.autoRefresh=e.target.checked;setupAuto();};
  setupAuto();
}
function setupAuto(){
  clearInterval(S.timer);
  if(S.autoRefresh && S.page==='events') S.timer=setInterval(()=>{ if(S.page==='events') loadEvents().catch(()=>{}); },30000);
}
async function openWindow(id){
  try{
    const d=await api('/api/windows/'+id);
    const sigs=(d.signals||[]).map(s=>`<div class="sig-box"><div class="h"><span>${SL[s.name]||s.name}</span>
      <span style="color:${scoreColor(s.score)}">${(s.score*100).toFixed(0)}% · 置信 ${(s.confidence*100).toFixed(0)}%</span></div>
      ${bar(s.score)}
      <div class="metrics">${Object.entries(s.metrics||{}).filter(([k])=>!k.startsWith('__'))
        .map(([k,v])=>`${esc(k)} = ${typeof v==='number'?v.toFixed(4):v}`).join('<br>')}</div></div>`).join('');
    const reasons=(d.reasons||[]).map(r=>`<li>${esc(r)}</li>`).join('');
    openDrawer(`<div class="rowline"><h2>窗口 #${d.id} · ${esc(d.window_id)}</h2>
      <button class="btn sm" onclick="closeDrawer()">关闭</button></div>
      <p class="muted" style="margin:0 0 16px">账号 ${esc(d.account_id)} · 设备 ${esc(d.device_id)} · ${fmt(d.received_at)} · 来源 ${esc(d.source)}</p>
      <div class="grid g2" style="margin-bottom:16px"><div class="kpi"><div class="lab">综合风险分</div>
        <div class="val" style="color:${scoreColor(d.score)}">${(d.score*100).toFixed(1)}</div>
        <div class="sub"><span class="badge lv-${d.level}">${LV[d.level]}</span> &nbsp; ${AC[d.action]||d.action}</div></div>
        <div class="panel" style="margin:0"><div class="section-title">下发给 SDK 的响应</div>
          <div class="kv">${esc(JSON.stringify(d.public))}</div>
          <div class="note" style="margin-top:9px">字段集合恒定，不含分数、等级与判定依据。</div></div></div>
      <div class="section-title">四路信号明细</div>${sigs}
      <div class="section-title">判定依据（仅服务端可见）</div><ul class="note">${reasons}</ul>
      <details style="margin-top:14px"><summary class="muted" style="cursor:pointer;font-size:12.5px">查看原始上报 JSON（可回放）</summary>
        <pre class="pre" style="margin-top:10px">${esc(JSON.stringify(d.raw,null,2))}</pre></details>`);
  }catch(e){ toast('详情加载失败：'+e.message,true); }
}

/* -------------------------------------------------------------- 案件复核 */
async function loadCases(){
  const q=S.caseStatus?`?status=${S.caseStatus}`:'';
  S.cases=(await api('/api/cases'+q)).rows||[];
  const counts=(await api('/api/overview?hours=24')).cases||{};
  $('#case-dot').textContent=counts.OPEN||0;
  $('#case-dot').classList.toggle('hidden',!counts.OPEN);
  const tabs=[['OPEN','待处理'],['CONFIRMED','已确认作弊'],['DISMISSED','判定误判'],['ESCALATED','已升级'],['','全部']];
  const rows=S.cases.map(c=>`<tr><td class="mono">#${c.id}</td><td class="mono">${esc(c.account_id)}</td>
    <td class="mono" style="color:${scoreColor(c.score)}">${Number(c.score).toFixed(3)}</td>
    <td>${AC[c.action]||c.action}</td><td class="mono">${fmt(c.created_at)}</td>
    <td><span class="tag ${c.status==='OPEN'?'off':''}">${{OPEN:'待处理',CONFIRMED:'已确认',DISMISSED:'误判',ESCALATED:'已升级'}[c.status]||c.status}</span></td>
    <td class="muted">${esc((c.note||'').slice(0,28))}</td>
    <td><div class="case-actions">
      <button class="btn sm" onclick="caseAct(${c.id},'CONFIRMED')">确认作弊</button>
      <button class="btn sm" onclick="caseAct(${c.id},'DISMISSED')">判定误判</button>
      <button class="btn sm" onclick="caseAct(${c.id},'ESCALATED')">升级人工</button></div></td></tr>`).join('');
  $('#view').innerHTML=`<div class="panel"><div class="rowline">
    <div><h2>案件队列</h2><p class="desc" style="margin:0">自动建案仅针对高风险窗口；最终处置由管理员完成</p></div>
    <a class="btn sm" href="${API_BASE}/api/export?kind=cases">导出 CSV</a></div>
    <div class="seg" style="margin-bottom:14px">${tabs.map(([k,v])=>
      `<button class="${S.caseStatus===k?'on':''}" onclick="S.caseStatus='${k}';loadCases()">${v}${k==='OPEN'&&counts.OPEN?' ('+counts.OPEN+')':''}</button>`).join('')}</div>
    <table><thead><tr><th>案件</th><th>账号</th><th>分数</th><th>建议处置</th><th>创建时间</th><th>状态</th><th>备注</th><th>操作</th></tr></thead>
      <tbody>${rows||'<tr><td colspan="8" class="empty">该状态下暂无案件</td></tr>'}</tbody></table></div>
    <div class="panel"><h2>处置原则</h2>
      <div class="grid g3"><div class="note"><b>确认作弊</b><br>写入审计日志，可作为后续限制激励结算的依据。</div>
      <div class="note"><b>判定误判</b><br>保留原始信号用于阈值回归，避免同类正常用户再次被误伤。</div>
      <div class="note"><b>升级人工</b><br>转交专人复核；系统不自动封号，不自动提交申诉。</div></div></div>`;
}
function caseAct(id,status){
  const label={CONFIRMED:'确认作弊',DISMISSED:'判定误判',ESCALATED:'升级人工'}[status];
  openModal(label+` · 案件 #${id}`,`<label>复核备注（写入审计日志）</label>
    <textarea id="case-note" rows="4" placeholder="例如：已核对设备归属，确认群控；或：企业托管浏览器导致误判"></textarea>`,
    async()=>{ try{ await post('/api/cases/'+id,{status,note:$('#case-note').value});
      toast('案件 #'+id+' 已'+label); await loadCases(); }catch(e){ toast('操作失败：'+e.message,true); return false; } });
}

/* -------------------------------------------------------------- 规则配置 */
async function loadConfig(){
  const [cfg,al,au]=await Promise.all([api('/api/config'),api('/api/alerts'),api('/api/audit')]);
  S.config=cfg; S.alerts=al.rows||[]; S.audit=au.rows||[];
  const w=cfg.weights, a=cfg.alert||{}, p=cfg.policy||{};
  const wRows=Object.keys(SL).map(k=>`<div class="rowline"><span class="n">${SL[k]}</span>
    <div style="display:flex;align-items:center;gap:10px;width:62%">
      <input type="range" min="0" max="0.6" step="0.01" value="${w[k]}" data-w="${k}" style="flex:1">
      <b class="mono" id="wv-${k}" style="width:42px;text-align:right">${Number(w[k]).toFixed(2)}</b></div></div>`).join('');
  const thRows=cfg.thresholds.map((t,i)=>`<tr><td class="mono">阈值 ${i+1}</td>
    <td><input type="number" min="0" max="1" step="0.01" value="${t[0]}" data-th="${i}" style="width:90px"></td>
    <td><select data-ta="${i}">${Object.entries(AC).map(([k,v])=>
      `<option value="${k}" ${t[1]===k?'selected':''}>${v} · ${k}</option>`).join('')}</select></td></tr>`).join('');
  const lvlOpt=cur=>Object.keys(LV).map(k=>`<option value="${k}" ${cur===k?'selected':''}>${LV[k]} · ${k}</option>`).join('');
  const chOpt=Object.entries(cfg.channels||{}).map(([k,v])=>
    `<option value="${k}" ${a.channel===k?'selected':''}>${esc(v)}</option>`).join('');
  const alertRows=S.alerts.map(r=>`<tr><td class="mono">${fmt(r.created_at)}</td><td>${esc(r.channel)}</td>
    <td><span class="tag ${r.ok?'on':'off'}">${r.ok?'成功':'失败'}</span></td>
    <td class="muted">${esc((r.detail||'').slice(0,70))}</td></tr>`).join('');
  const auditRows=S.audit.slice(0,12).map(r=>`<tr><td class="mono">${fmt(r.created_at)}</td>
    <td class="mono">${esc(r.actor)}</td><td>${esc(r.action)}</td><td class="muted">${esc((r.detail||'').slice(0,64))}</td></tr>`).join('');

  $('#view').innerHTML=`
  <div class="grid g2">
    <div class="panel"><h2>信号权重</h2><p class="desc">热更新立即生效；不会重置账号迟滞状态</p>
      ${wRows}<div class="hr"></div>
      <div class="rowline"><span class="muted tiny">权重总和（无需等于 1，融合时会归一化）</span><b class="mono" id="wsum">--</b></div></div>
    <div class="panel"><h2>动作阈值</h2><p class="desc">分数降序匹配；最后一项必须为 0.00 / ALLOW 兜底</p>
      <table><thead><tr><th>#</th><th>分数 ≥</th><th>处置动作</th></tr></thead><tbody>${thRows}</tbody></table></div>
  </div>
  <div class="grid g2">
    <div class="panel"><h2>处置策略</h2><p class="desc">自动建案与告警的触发条件</p>
      <label style="display:flex;gap:8px;align-items:center;color:var(--ink);font-size:13px">
        <input type="checkbox" id="p-auto" ${p.auto_case?'checked':''}> 高风险窗口自动建立复核案件</label>
      <div class="grid g2" style="margin-top:10px">
        <div><label>自动建案最低等级</label><select id="p-case">${lvlOpt(p.case_min_level)}</select></div>
        <div><label>触发告警最低等级</label><select id="p-alert">${lvlOpt(p.alert_min_level)}</select></div></div>
      <div class="hr"></div><div class="section-title">接入 API Key</div>
      <div class="kv" id="key-box">${esc(cfg.ingest_key)}</div>
      <div style="display:flex;gap:8px;margin-top:10px">
        <button class="btn sm" id="key-copy">复制</button><button class="btn sm danger" id="key-rotate">重置 Key</button></div>
      <div class="hr"></div><div class="section-title">管理员密码</div>
      <div style="display:flex;gap:8px"><input id="new-pwd" type="password" placeholder="至少 10 位新密码" style="flex:1">
        <button class="btn sm" id="pwd-go">修改</button></div></div>
    <div class="panel"><h2>告警通道</h2><p class="desc">高风险时推送给管理员人工介入；系统不自动封号</p>
      <label style="display:flex;gap:8px;align-items:center;color:var(--ink);font-size:13px">
        <input type="checkbox" id="a-enabled" ${a.enabled?'checked':''}> 启用告警推送</label>
      <label>渠道</label><select id="a-channel" style="width:100%">${chOpt}</select>
      <label>企业微信机器人 Webhook</label><input id="a-wecom" value="${esc(a.wecom_webhook||'')}" style="width:100%" placeholder="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=...">
      <div class="grid g2"><div><label>Bark 地址</label><input id="a-bark" value="${esc(a.bark_url||'')}" style="width:100%" placeholder="https://api.day.app/xxxxx"></div>
        <div><label>Server 酱 SendKey</label><input id="a-sc" value="${esc(a.serverchan_key||'')}" style="width:100%"></div></div>
      <div class="grid g2"><div><label>SMTP 主机</label><input id="a-host" value="${esc(a.smtp_host||'')}" style="width:100%"></div>
        <div><label>SMTP 端口</label><input id="a-port" type="number" value="${a.smtp_port||465}" style="width:100%"></div></div>
      <div class="grid g2"><div><label>SMTP 账号</label><input id="a-user" value="${esc(a.smtp_user||'')}" style="width:100%"></div>
        <div><label>SMTP 密码</label><input id="a-pass" type="password" value="${esc(a.smtp_pass||'')}" style="width:100%"></div></div>
      <label>邮件收件人</label><input id="a-to" value="${esc(a.smtp_to||'')}" style="width:100%">
      <div class="note" style="margin-top:8px">留以 ******** 开头的掩码值表示保持原值不变。</div></div>
  </div>
  <div class="panel"><div class="rowline"><h2 style="margin:0">保存与维护</h2>
      <div style="display:flex;gap:8px"><button class="btn sm" id="test-alert">测试告警</button>
        <button class="btn sm" id="seed">重新生成演示数据</button>
        <button class="btn sm danger" id="clear">清空业务数据</button>
        <button class="btn primary sm" id="save">保存配置</button></div></div>
    <p class="desc" style="margin:8px 0 0">所有配置修改与案件处置均写入审计日志；阈值调整不会清除账号连续命中计数。</p></div>
  <div class="grid g2">
    <div class="panel"><h2>告警记录</h2><table><thead><tr><th>时间</th><th>渠道</th><th>结果</th><th>回执</th></tr></thead>
      <tbody>${alertRows||'<tr><td colspan="4" class="empty">暂无告警记录</td></tr>'}</tbody></table></div>
    <div class="panel"><h2>最近审计日志</h2><table><thead><tr><th>时间</th><th>操作者</th><th>动作</th><th>详情</th></tr></thead>
      <tbody>${auditRows||'<tr><td colspan="4" class="empty">暂无记录</td></tr>'}</tbody></table></div>
  </div>`;

  const upd=()=>{let s=0;$$('[data-w]').forEach(el=>{s+=parseFloat(el.value);$('#wv-'+el.dataset.w).textContent=parseFloat(el.value).toFixed(2)});
    $('#wsum').textContent=s.toFixed(2);};
  $$('[data-w]').forEach(el=>el.oninput=upd); upd();
  $('#key-copy').onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(S.config.ingest_key);toast('API Key 已复制');};
  $('#key-rotate').onclick=()=>openModal('重置接入 API Key',
    '<div class="note">旧 Key 将立即失效，请同步更新所有上报端配置。</div>',async()=>{
      try{const r=await post('/api/config/rotate-key',{});S.config.ingest_key=r.ingest_key;
        $('#key-box').textContent=r.ingest_key;toast('API Key 已重置');}catch(e){toast('失败：'+e.message,true);return false;}});
  $('#pwd-go').onclick=async()=>{try{await post('/api/auth/password',{new_password:$('#new-pwd').value});
    toast('密码已修改，请重新登录');setTimeout(showLogin,900);}catch(e){toast('失败：'+e.message,true);}};
  $('#test-alert').onclick=async()=>{try{const r=await post('/api/config/test-alert',{});
    toast(r.ok?'告警发送成功':'告警发送失败：'+r.detail,!r.ok);await loadConfig();}catch(e){toast('失败：'+e.message,true);}};
  $('#seed').onclick=()=>openModal('重新生成演示数据',
    '<div class="note">将清空现有事件、案件、告警与迟滞状态，并重新灌入近 24 小时的演示数据。</div>',async()=>{
      toast('正在生成…');try{await post('/api/demo/seed',{count:72});toast('演示数据已重新生成');await loadConfig();}
      catch(e){toast('失败：'+e.message,true);return false;}});
  $('#clear').onclick=()=>openModal('清空业务数据',
    '<div class="note">将删除全部事件、案件、告警与账号迟滞状态，配置与账号保留。</div>',async()=>{
      try{await post('/api/demo/clear',{});toast('已清空');await loadConfig();}catch(e){toast('失败：'+e.message,true);return false;}});
  $('#save').onclick=async()=>{
    const weights={};$$('[data-w]').forEach(el=>weights[el.dataset.w]=parseFloat(el.value));
    const thresholds=S.config.thresholds.map((t,i)=>[parseFloat($(`[data-th="${i}"]`).value),$(`[data-ta="${i}"]`).value]);
    const payload={weights,thresholds,
      policy:{auto_case:$('#p-auto').checked,case_min_level:$('#p-case').value,
              alert_min_level:$('#p-alert').value,retention_days:(S.config.policy||{}).retention_days||30},
      alert:{enabled:$('#a-enabled').checked,channel:$('#a-channel').value,
        wecom_webhook:$('#a-wecom').value,bark_url:$('#a-bark').value,serverchan_key:$('#a-sc').value,
        smtp_host:$('#a-host').value,smtp_port:parseInt($('#a-port').value||'465'),
        smtp_user:$('#a-user').value,smtp_pass:$('#a-pass').value,smtp_to:$('#a-to').value}};
    try{await post('/api/config',payload);toast('配置已保存并热更新');await loadConfig();}
    catch(e){toast('保存失败：'+e.message,true);}
  };
}

/* -------------------------------------------------------------- 接入文档 */
async function loadDocs(){
  const [demo,cfg]=await Promise.all([api('/api/demo'),api('/api/config')]);
  S.demo=demo; S.config=cfg;
  const key=cfg.ingest_key;
  const curl=`curl -X POST http://127.0.0.1:8791/api/v1/ingest \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: ${key}" \\
  -d @window.json`;
  const py=`import json, urllib.request

window = {
  "window_id": "w-0001", "account_id": "u_10086",
  "device_id": "dev-abc", "daily_active_s": 7200, "hour_of_day": 21,
  "swipes": [], "watches": [], "fingerprints": [],
  "swipe_history": [], "fp_account_map": {}, "account_fp_history": {}
}
req = urllib.request.Request(
    "http://127.0.0.1:8791/api/v1/ingest",
    data=json.dumps(window).encode(),
    headers={"Content-Type": "application/json", "X-API-Key": "${key}"})
print(urllib.request.urlopen(req).read().decode())`;
  const cards=Object.entries(demo.scenarios).map(([k,v])=>{
    const r=v.report;return `<div class="kpi"><div class="lab"><span>${esc(v.label)}</span></div>
      <div class="val" style="color:${scoreColor(r.score)}">${(r.score*100).toFixed(1)}</div>
      <div class="sub"><span class="badge lv-${r.level}">${LV[r.level]}</span> &nbsp; ${AC[r.action]||r.action}</div></div>`;}).join('');
  $('#view').innerHTML=`
    <div class="grid g2">
      <div class="panel"><h2>上报接口</h2><p class="desc">POST /api/v1/ingest · 单条或 {"batch":[...]}（最多 50 条）</p>
        <div class="doc-h">请求头</div><div class="kv">Content-Type: application/json
X-API-Key: &lt;接入 Key&gt;</div>
        <div class="doc-h">cURL 示例</div><pre class="pre">${esc(curl)}</pre>
        <div class="doc-h">Python 示例</div><pre class="pre">${esc(py)}</pre></div>
      <div class="panel"><h2>响应契约（重要）</h2><p class="desc">SDK 侧只能拿到统一外形响应</p>
        <pre class="pre">${esc(JSON.stringify({status:'ok',accepted:1,results:[{status:'ok',challenge:null,nonce:null,retry_after:0,request_id:'rg-00000123'}]},null,2))}</pre>
        <div class="doc-h">三条不可破例的原则</div>
        <div class="note">1. 分数、等级、单项信号、判定依据<b>永不</b>下发给客户端，否则等于把规则边界交给对方逐条探测。<br>
        2. 无论命中哪条规则，字段集合完全一致，只有 challenge 类型不同。<br>
        3. 命中滑块 / 短信 / 人脸等二次校验时，交由账号本人完成；服务端不代答、不绕过。</div>
        <div class="doc-h">关键字段</div>
        <div class="kv">swipes[].points[]  : x, y, t(ms), pressure, area
watches[]        : duration_s(原始精度!), ts, liked, is_live ...
fingerprints[]   : UA / 屏幕 / WebGL / 时区 / webdriver ...</div></div>
    </div>
    <div class="panel"><h2>内置样本对照</h2><p class="desc">每次刷新由独立内存引擎重新评估，不影响线上迟滞状态</p>
      <div class="grid g3">${cards}</div></div>
    <div class="panel"><h2>在线判定调试</h2><p class="desc">管理员专用：不落库，返回完整报告（含四路信号与判定依据）</p>
      <div style="display:flex;gap:8px;margin-bottom:10px">
        <button class="btn sm" id="doc-load">载入精简示例</button>
        <button class="btn primary sm" id="doc-run">评估</button>
        <span class="muted tiny" id="doc-hint" style="align-self:center">POST /api/evaluate</span></div>
      <textarea id="doc-payload" rows="9" placeholder='粘贴 BehaviorWindow JSON'></textarea>
      <pre class="pre" id="doc-out" style="display:none;margin-top:12px"></pre></div>`;
  $('#doc-load').onclick=async()=>{const d=await api('/api/sample');$('#doc-payload').value=JSON.stringify(d,null,2);
    $('#doc-hint').textContent='已载入示例';};
  $('#doc-run').onclick=async()=>{
    try{const body=JSON.parse($('#doc-payload').value);const r=await post('/api/evaluate',body);
      $('#doc-out').style.display='block';$('#doc-out').textContent=JSON.stringify(r,null,2);
      $('#doc-hint').textContent=`判定：${r.level} / ${r.action} / ${(r.score*100).toFixed(1)}`;}
    catch(e){toast('评估失败：'+e.message,true);}
  };
}

/* ------------------------------------------------------------------ 启动 */
async function boot(){
  try{
    const me=await api('/api/auth/me'); $('#who').textContent=me.username;
    showShell(); go(location.hash.slice(1)||'overview');
  }catch(e){ showLogin(); }
}
$('#lg-go').onclick=async()=>{
  try{await post('/api/auth/login',{username:$('#lg-user').value,password:$('#lg-pass').value});
    $('#lg-err').textContent='';$('#lg-pass').value='';await boot();}
  catch(e){$('#lg-err').textContent=e.message==='未登录'?'用户名或密码错误':e.message;}
};
$('#lg-pass').onkeydown=e=>{if(e.key==='Enter')$('#lg-go').click();};
$('#logout').onclick=async()=>{try{await post('/api/auth/logout',{});}catch(e){}showLogin();};
$$('#nav a').forEach(a=>a.onclick=()=>go(a.dataset.page));
$('#refresh').onclick=()=>{refresh();toast('已刷新');};
setInterval(()=>{const d=new Date(),p=n=>String(n).padStart(2,'0');
  $('#clock').textContent=`${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;},1000);
boot();
