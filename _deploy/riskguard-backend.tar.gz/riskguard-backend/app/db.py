# -*- coding: utf-8 -*-
"""
SQLite 数据层。

之所以用 SQLite + WAL 而不是内存字典：
  - 判定结果、原始上报、案件处置和审计日志都必须可回溯；
  - 迟滞状态（EMA / 连续命中计数）必须跨进程重启保留，否则重启即可"洗白"账号；
  - 纯标准库，无需安装任何依赖，开箱即用。

生产规模上量后，可把 windows 表迁到 ClickHouse / Elasticsearch，
account_state 迁到 Redis 并加 TTL，DAO 接口保持不变即可。
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("RISKGUARD_DATA", str(ROOT / "data")))
DB_PATH = DATA_DIR / "riskguard.db"

DEFAULT_WEIGHTS = {"touch": 0.30, "timing": 0.22, "fingerprint": 0.28, "behavior": 0.20}
DEFAULT_THRESHOLDS = [
    [0.92, "BLOCK"], [0.78, "STEP_UP_AUTH"], [0.60, "SLIDER"],
    [0.42, "SILENT_CHALLENGE"], [0.25, "OBSERVE"], [0.00, "ALLOW"],
]
DEFAULT_POLICY = {
    "auto_case": True,
    "case_min_level": "HIGH",
    "alert_min_level": "CRITICAL",
    "retention_days": 30,
}
DEFAULT_ALERT = {
    "enabled": False, "channel": "wecom",
    "wecom_webhook": "", "bark_url": "", "serverchan_key": "",
    "smtp_host": "", "smtp_port": 465, "smtp_user": "",
    "smtp_pass": "", "smtp_to": "",
}
LEVEL_RANK = {"LOW": 0, "ELEVATED": 1, "HIGH": 2, "CRITICAL": 3}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY, value TEXT NOT NULL,
  updated_at REAL NOT NULL, updated_by TEXT NOT NULL DEFAULT 'system');
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
  salt TEXT NOT NULL, pwd_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin',
  created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL,
  expires_at REAL NOT NULL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS account_state(
  account_id TEXT PRIMARY KEY, state_json TEXT NOT NULL, updated_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS windows(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  window_id TEXT NOT NULL, account_id TEXT NOT NULL, device_id TEXT NOT NULL,
  received_at REAL NOT NULL, score REAL NOT NULL, level TEXT NOT NULL,
  action TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'sdk',
  signals_json TEXT NOT NULL, reasons_json TEXT NOT NULL,
  public_json TEXT NOT NULL, raw_json TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_windows_time ON windows(received_at);
CREATE INDEX IF NOT EXISTS idx_windows_account ON windows(account_id);
CREATE INDEX IF NOT EXISTS idx_windows_level ON windows(level);
CREATE TABLE IF NOT EXISTS cases(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  window_pk INTEGER NOT NULL UNIQUE, account_id TEXT NOT NULL,
  score REAL NOT NULL, action TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'OPEN',
  assignee TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
  created_at REAL NOT NULL, updated_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS idx_cases_status ON cases(status);
CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT, window_pk INTEGER,
  channel TEXT NOT NULL, ok INTEGER NOT NULL, detail TEXT NOT NULL,
  created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL,
  action TEXT NOT NULL, detail TEXT NOT NULL, created_at REAL NOT NULL);
"""


@contextmanager
def connect():
    """
    上下文管理器：退出时**显式关闭连接**。
    sqlite3.Connection 自带的 __exit__ 只提交事务、并不 close，
    直接用 `with sqlite3.connect(...)` 会在高并发下堆积文件句柄。
    """
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=15.0)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=10000")
        conn.execute("PRAGMA foreign_keys=ON")
        yield conn
    finally:
        conn.close()


def hash_password(password: str, salt: str = "") -> tuple:
    """PBKDF2-HMAC-SHA256，返回 (salt_hex, hash_hex)。"""
    s = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(s), 120_000).hex()
    return s, h


def verify_password(password: str, salt: str, expected: str) -> bool:
    _, h = hash_password(password, salt)
    return hmac.compare_digest(h, expected)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def init_db() -> str:
    """
    建库 + 写入默认配置 + 创建首个管理员。
    返回首次创建时的初始密码（后续启动返回空串）。
    """
    with connect() as c:
        c.executescript(SCHEMA)
        defaults = {
            "weights": DEFAULT_WEIGHTS,
            "thresholds": DEFAULT_THRESHOLDS,
            "policy": DEFAULT_POLICY,
            "alert": DEFAULT_ALERT,
            "ingest_key": secrets.token_urlsafe(32),
        }
        for k, v in defaults.items():
            c.execute("INSERT OR IGNORE INTO settings(key,value,updated_at,updated_by) VALUES(?,?,?,?)",
                      (k, json.dumps(v, ensure_ascii=False), time.time(), "system"))
        row = c.execute("SELECT COUNT(*) AS n FROM users").fetchone()
        initial = ""
        if row["n"] == 0:
            # 不硬编码任何默认口令：首次启动随机生成并落盘到数据目录，
            # 由启动日志告知管理员；也可用 RISKGUARD_ADMIN_PASSWORD 显式指定。
            initial = os.environ.get("RISKGUARD_ADMIN_PASSWORD") or ("RG-" + secrets.token_urlsafe(12))
            salt, h = hash_password(initial)
            c.execute("INSERT INTO users(username,salt,pwd_hash,role,created_at) VALUES(?,?,?,?,?)",
                      ("admin", salt, h, "admin", time.time()))
            cred = DATA_DIR / "INITIAL_ADMIN.txt"
            cred.write_text(
                "# RiskGuard 首次启动凭据，登录后请立即在「规则配置」修改密码，然后删除本文件。\n"
                f"username: admin\npassword: {initial}\n", encoding="utf-8")
        c.execute("DELETE FROM sessions WHERE expires_at < ?", (time.time(),))
        c.commit()
    return initial


# ------------------------------------------------------------------ settings
def get_setting(key: str, default: Any = None) -> Any:
    with connect() as c:
        r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return json.loads(r["value"]) if r else default


def set_setting(key: str, value: Any, actor: str) -> None:
    with connect() as c:
        c.execute("INSERT INTO settings(key,value,updated_at,updated_by) VALUES(?,?,?,?) "
                  "ON CONFLICT(key) DO UPDATE SET value=excluded.value,"
                  "updated_at=excluded.updated_at,updated_by=excluded.updated_by",
                  (key, json.dumps(value, ensure_ascii=False), time.time(), actor))
        c.commit()
    add_audit(actor, "config.update", f"{key} 已更新")


def all_settings() -> Dict[str, Any]:
    with connect() as c:
        rows = c.execute("SELECT key,value,updated_at,updated_by FROM settings").fetchall()
    return {r["key"]: {"value": json.loads(r["value"]),
                       "updated_at": r["updated_at"], "updated_by": r["updated_by"]}
            for r in rows}


# --------------------------------------------------------------------- users
def get_user(username: str) -> Optional[sqlite3.Row]:
    with connect() as c:
        return c.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()


def change_password(username: str, new_password: str, actor: str) -> None:
    salt, h = hash_password(new_password)
    with connect() as c:
        c.execute("UPDATE users SET salt=?,pwd_hash=? WHERE username=?", (salt, h, username))
        c.execute("DELETE FROM sessions")
        c.commit()
    add_audit(actor, "auth.password_changed", "管理员密码已修改，所有会话已失效")


def create_session(username: str, ttl: int = 8 * 3600) -> str:
    token = secrets.token_urlsafe(32)
    u = get_user(username)
    with connect() as c:
        c.execute("INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
                  (token_hash(token), u["id"], time.time() + ttl, time.time()))
        c.commit()
    return token


def session_user(token: str) -> Optional[str]:
    if not token:
        return None
    with connect() as c:
        r = c.execute("SELECT u.username AS username FROM sessions s "
                      "JOIN users u ON u.id=s.user_id "
                      "WHERE s.token_hash=? AND s.expires_at>?",
                      (token_hash(token), time.time())).fetchone()
    return r["username"] if r else None


def drop_session(token: str) -> None:
    with connect() as c:
        c.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash(token),))
        c.commit()


# ------------------------------------------------------- engine state store
class DbStateStore:
    """把迟滞状态持久化，重启后不会丢失连续命中计数。"""

    def load(self, account_id: str) -> Optional[Dict[str, Any]]:
        with connect() as c:
            r = c.execute("SELECT state_json FROM account_state WHERE account_id=?",
                          (account_id,)).fetchone()
        return json.loads(r["state_json"]) if r else None

    def save(self, account_id: str, state: Dict[str, Any]) -> None:
        with connect() as c:
            c.execute("INSERT INTO account_state(account_id,state_json,updated_at) VALUES(?,?,?) "
                      "ON CONFLICT(account_id) DO UPDATE SET state_json=excluded.state_json,"
                      "updated_at=excluded.updated_at",
                      (account_id, json.dumps(state), time.time()))
            c.commit()

    def clear(self) -> None:
        with connect() as c:
            c.execute("DELETE FROM account_state")
            c.commit()


# ------------------------------------------------------------------- windows
def insert_window(w, report, source: str = "sdk", received_at: float | None = None) -> int:
    with connect() as c:
        cur = c.execute(
            "INSERT INTO windows(window_id,account_id,device_id,received_at,score,level,"
            "action,source,signals_json,reasons_json,public_json,raw_json) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (w.window_id, w.account_id, w.device_id,
             time.time() if received_at is None else received_at,
             report.score, report.level, report.action, source,
             json.dumps([s.to_dict() for s in report.signals], ensure_ascii=False),
             json.dumps(report.reasons, ensure_ascii=False),
             json.dumps(report.public_response, ensure_ascii=False),
             json.dumps(w.to_dict(), ensure_ascii=False)))
        c.commit()
        return int(cur.lastrowid)


def list_windows(level: str = "", action: str = "", account: str = "",
                 limit: int = 50, offset: int = 0, since: float = 0.0) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM windows WHERE received_at>=?"
    args: List[Any] = [since]
    if level:
        sql += " AND level=?"
        args.append(level)
    if action:
        sql += " AND action=?"
        args.append(action)
    if account:
        sql += " AND account_id LIKE ?"
        args.append(f"%{account}%")
    sql += " ORDER BY received_at DESC LIMIT ? OFFSET ?"
    args += [limit, offset]
    with connect() as c:
        rows = c.execute(sql, args).fetchall()
    return [dict(r) for r in rows]


def get_window(pk: int) -> Optional[Dict[str, Any]]:
    with connect() as c:
        r = c.execute("SELECT * FROM windows WHERE id=?", (pk,)).fetchone()
    return dict(r) if r else None


def count_windows(since: float = 0.0) -> int:
    with connect() as c:
        return int(c.execute("SELECT COUNT(*) AS n FROM windows WHERE received_at>=?",
                             (since,)).fetchone()["n"])


def level_distribution(since: float = 0.0) -> Dict[str, int]:
    with connect() as c:
        rows = c.execute("SELECT level,COUNT(*) AS n FROM windows WHERE received_at>=? "
                         "GROUP BY level", (since,)).fetchall()
    return {r["level"]: r["n"] for r in rows}


def action_distribution(since: float = 0.0) -> Dict[str, int]:
    with connect() as c:
        rows = c.execute("SELECT action,COUNT(*) AS n FROM windows WHERE received_at>=? "
                         "GROUP BY action", (since,)).fetchall()
    return {r["action"]: r["n"] for r in rows}


def hourly_trend(hours: int = 24) -> List[Dict[str, Any]]:
    """按小时分桶，返回风险窗口数与平均风险分，供看板画趋势图。"""
    now = time.time()
    start = now - hours * 3600
    with connect() as c:
        rows = c.execute("SELECT received_at,score,level FROM windows WHERE received_at>=?",
                         (start,)).fetchall()
    buckets = [{"t": start + i * 3600, "total": 0, "risky": 0, "sum": 0.0}
               for i in range(hours)]
    for r in rows:
        idx = int((r["received_at"] - start) // 3600)
        if 0 <= idx < hours:
            b = buckets[idx]
            b["total"] += 1
            b["sum"] += r["score"]
            if r["level"] in ("HIGH", "CRITICAL"):
                b["risky"] += 1
    for b in buckets:
        b["avg"] = round(b["sum"] / b["total"], 4) if b["total"] else 0.0
        del b["sum"]
    return buckets


def top_accounts(since: float = 0.0, limit: int = 8) -> List[Dict[str, Any]]:
    with connect() as c:
        rows = c.execute("SELECT account_id,COUNT(*) AS n,ROUND(AVG(score),3) AS avg_score, "
                         "MAX(score) AS max_score FROM windows WHERE received_at>=? "
                         "GROUP BY account_id ORDER BY max_score DESC LIMIT ?",
                         (since, limit)).fetchall()
    return [dict(r) for r in rows]


# --------------------------------------------------------------------- cases
def create_case(window_pk: int, account_id: str, score: float, action: str) -> Optional[int]:
    with connect() as c:
        cur = c.execute("INSERT OR IGNORE INTO cases(window_pk,account_id,score,action,"
                        "status,created_at,updated_at) VALUES(?,?,?,?,'OPEN',?,?)",
                        (window_pk, account_id, score, action, time.time(), time.time()))
        c.commit()
        return int(cur.lastrowid) if cur.rowcount else None


def list_cases(status: str = "", limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
    sql = ("SELECT c.*,w.window_id,w.level,w.received_at FROM cases c "
           "JOIN windows w ON w.id=c.window_pk")
    args: List[Any] = []
    if status:
        sql += " WHERE c.status=?"
        args.append(status)
    sql += " ORDER BY c.created_at DESC LIMIT ? OFFSET ?"
    args += [limit, offset]
    with connect() as c:
        return [dict(r) for r in c.execute(sql, args).fetchall()]


def update_case(case_id: int, status: str, note: str, actor: str) -> bool:
    with connect() as c:
        cur = c.execute("UPDATE cases SET status=?,note=?,assignee=?,updated_at=? WHERE id=?",
                        (status, note, actor, time.time(), case_id))
        c.commit()
    if cur.rowcount:
        add_audit(actor, f"case.{status.lower()}", f"案件 #{case_id} 处置为 {status}；备注：{note}")
    return bool(cur.rowcount)


def case_stats() -> Dict[str, int]:
    with connect() as c:
        rows = c.execute("SELECT status,COUNT(*) AS n FROM cases GROUP BY status").fetchall()
    return {r["status"]: r["n"] for r in rows}


# -------------------------------------------------------------------- alerts
def insert_alert(window_pk: Optional[int], channel: str, ok: bool, detail: str) -> None:
    with connect() as c:
        c.execute("INSERT INTO alerts(window_pk,channel,ok,detail,created_at) VALUES(?,?,?,?,?)",
                  (window_pk, channel, 1 if ok else 0, detail[:500], time.time()))
        c.commit()


def list_alerts(limit: int = 30) -> List[Dict[str, Any]]:
    with connect() as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM alerts ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()]


def alert_stats(since: float = 0.0) -> Dict[str, int]:
    with connect() as c:
        r = c.execute("SELECT COUNT(*) AS total, SUM(ok) AS ok FROM alerts "
                      "WHERE created_at>=?", (since,)).fetchone()
    return {"total": int(r["total"] or 0), "ok": int(r["ok"] or 0)}


# --------------------------------------------------------------------- audit
def add_audit(actor: str, action: str, detail: str) -> None:
    with connect() as c:
        c.execute("INSERT INTO audit(actor,action,detail,created_at) VALUES(?,?,?,?)",
                  (actor, action, detail[:1000], time.time()))
        c.commit()


def list_audit(limit: int = 50) -> List[Dict[str, Any]]:
    with connect() as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM audit ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()]


# ------------------------------------------------------------------ 维护操作
def purge_all_events() -> None:
    """清空业务数据但保留配置与账号，用于重置演示数据。"""
    with connect() as c:
        for t in ("windows", "cases", "alerts", "account_state"):
            c.execute(f"DELETE FROM {t}")
        c.commit()


def purge_older_than(days: int) -> Dict[str, int]:
    """按 retention_days 清理过期数据；案件随其窗口一并删除，避免孤儿记录。"""
    if days <= 0:
        return {}
    cutoff = time.time() - days * 86400
    with connect() as c:
        c.execute("DELETE FROM cases WHERE window_pk IN "
                  "(SELECT id FROM windows WHERE received_at < ?)", (cutoff,))
        c.execute("DELETE FROM windows WHERE received_at < ?", (cutoff,))
        w = c.execute("SELECT changes()").fetchone()[0]
        c.execute("DELETE FROM alerts WHERE created_at < ?", (cutoff,))
        a = c.execute("SELECT changes()").fetchone()[0]
        c.commit()
    return {"windows": int(w), "alerts": int(a)}
