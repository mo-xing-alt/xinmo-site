# -*- coding: utf-8 -*-
"""
业务服务层：把检测引擎、持久化、案件、告警、配置串成一条完整链路。

    SDK 上报 → /api/v1/ingest → 检测 → 落库 → 自动建案 → 告警 → 人工复核
                                   ↓
                        只回 public_response（不泄露判定依据）
"""
from __future__ import annotations

import json
import random
import threading
import time
from typing import Any, Dict, List, Optional

from riskguard.engine import RiskEngine
from riskguard.models import Action, BehaviorWindow

from . import alerts, db

_LOCK = threading.Lock()
_ENGINE: Optional[RiskEngine] = None


def get_engine() -> RiskEngine:
    """按数据库中的当前配置构建（并缓存）引擎；配置变更时调用 refresh_engine。"""
    global _ENGINE
    with _LOCK:
        if _ENGINE is None:
            weights = db.get_setting("weights", db.DEFAULT_WEIGHTS)
            raw_th = db.get_setting("thresholds", db.DEFAULT_THRESHOLDS)
            thresholds = [(float(a), str(b)) for a, b in raw_th]
            _ENGINE = RiskEngine(weights=weights, thresholds=thresholds,
                                 state_store=db.DbStateStore())
        return _ENGINE


def refresh_engine() -> None:
    eng = get_engine()
    weights = db.get_setting("weights", db.DEFAULT_WEIGHTS)
    thresholds = [(float(a), str(b)) for a, b in
                  db.get_setting("thresholds", db.DEFAULT_THRESHOLDS)]
    with _LOCK:
        eng.configure(weights=weights, thresholds=thresholds)


def reset_engine() -> None:
    global _ENGINE
    with _LOCK:
        _ENGINE = None


# ---------------------------------------------------------------- 告警派发
def dispatch_alert(window_pk: int, level: str, action: str, account_id: str,
                   score: float, sync: bool = False) -> None:
    cfg = db.get_setting("alert", db.DEFAULT_ALERT)
    policy = db.get_setting("policy", db.DEFAULT_POLICY)
    if not cfg.get("enabled"):
        return
    if db.LEVEL_RANK.get(level, 0) < db.LEVEL_RANK.get(policy.get("alert_min_level", "CRITICAL"), 3):
        return
    title = f"RiskGuard 高风险告警 · {level}"
    body = (f"账号：{account_id}\n风险分：{score:.3f}\n等级：{level}\n"
            f"处置：{action}\n窗口主键：#{window_pk}\n"
            f"时间：{time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"请登录控制台进入「案件复核」人工处置。系统不会自动封号。")

    def _run() -> None:
        ok, detail = alerts.send(cfg, title, body)
        db.insert_alert(window_pk, cfg.get("channel", "wecom"), ok, detail)

    if sync:
        _run()
    else:
        threading.Thread(target=_run, daemon=True,
                         name=f"rg-alert-{window_pk}").start()


# ------------------------------------------------------------------ 接入链路
def ingest(window: BehaviorWindow, source: str = "sdk",
           received_at: float | None = None,
           skip_alert: bool = False) -> Dict[str, Any]:
    """
    评估并持久化一个窗口。返回内部结果；HTTP 层只把 public 部分下发给 SDK。
    """
    report = get_engine().evaluate(window)
    pk = db.insert_window(window, report, source=source, received_at=received_at)

    policy = db.get_setting("policy", db.DEFAULT_POLICY)
    if (policy.get("auto_case", True)
            and db.LEVEL_RANK.get(report.level, 0)
            >= db.LEVEL_RANK.get(policy.get("case_min_level", "HIGH"), 2)):
        db.create_case(pk, window.account_id, report.score, report.action)

    if not skip_alert:
        dispatch_alert(pk, report.level, report.action, window.account_id, report.score)

    return {
        "pk": pk, "level": report.level, "action": report.action,
        "score": report.score, "public": report.public_response,
        "request_id": f"rg-{pk:08d}",
    }


def ingest_public(result: Dict[str, Any]) -> Dict[str, Any]:
    """下发 SDK 的响应：字段集合恒定，不含分数/等级/理由。"""
    p = dict(result["public"])
    p["request_id"] = result["request_id"]
    return p


def debug_evaluate(window: BehaviorWindow) -> Dict[str, Any]:
    """管理员在线调试：不落库，返回完整报告（含信号明细与判定依据）。"""
    return get_engine().evaluate(window).to_dict()


# -------------------------------------------------------------------- 概览
def overview(hours: int = 24) -> Dict[str, Any]:
    since = time.time() - hours * 3600
    levels = db.level_distribution(since)
    recent = db.list_windows(limit=10, since=since)
    a = db.alert_stats(since)
    return {
        "generated_at": time.time(),
        "range_hours": hours,
        "windows": db.count_windows(since),
        "windows_total": db.count_windows(0),
        "risky": levels.get("HIGH", 0) + levels.get("CRITICAL", 0),
        "levels": levels,
        "actions": db.action_distribution(since),
        "trend": db.hourly_trend(hours),
        "top_accounts": db.top_accounts(since),
        "cases": db.case_stats(),
        "alerts": {"total": a["total"], "ok": a["ok"],
                   "rate": round(a["ok"] / a["total"], 3) if a["total"] else 0.0},
        "recent": [{"id": r["id"], "window_id": r["window_id"],
                    "account_id": r["account_id"], "received_at": r["received_at"],
                    "score": r["score"], "level": r["level"], "action": r["action"],
                    "source": r["source"]} for r in recent],
    }


def window_detail(pk: int) -> Optional[Dict[str, Any]]:
    r = db.get_window(pk)
    if not r:
        return None
    for k in ("signals_json", "reasons_json", "public_json", "raw_json"):
        r[k.replace("_json", "")] = json.loads(r.pop(k))
    return r


# ------------------------------------------------------------------ 配置管理
VALID_ACTIONS = set(Action.ORDER)


def _validate_weights(w: Any) -> Dict[str, float]:
    if not isinstance(w, dict) or set(w) != {"touch", "timing", "fingerprint", "behavior"}:
        raise ValueError("weights 必须包含 touch/timing/fingerprint/behavior 四项")
    out = {k: float(v) for k, v in w.items()}
    if any(v < 0 for v in out.values()) or sum(out.values()) <= 0:
        raise ValueError("权重必须非负且总和大于 0")
    return out


def _validate_thresholds(t: Any) -> List[List[Any]]:
    if not isinstance(t, list) or len(t) < 2:
        raise ValueError("thresholds 至少需要两项")
    out = []
    prev = 2.0
    for item in t:
        if not isinstance(item, (list, tuple)) or len(item) != 2:
            raise ValueError("每个阈值必须是 [分数, 动作]")
        th, act = float(item[0]), str(item[1])
        if act not in VALID_ACTIONS:
            raise ValueError(f"未知动作：{act}")
        if not (0.0 <= th <= 1.0) or th > prev:
            raise ValueError("分数必须在 0..1 且按降序排列")
        out.append([th, act])
        prev = th
    if out[-1][0] > 0:
        raise ValueError("最后一项阈值必须为 0.00 / ALLOW，作为兜底")
    return out


def get_config() -> Dict[str, Any]:
    alert = dict(db.get_setting("alert", db.DEFAULT_ALERT))
    for k in ("wecom_webhook", "bark_url", "serverchan_key", "smtp_pass", "smtp_user"):
        v = str(alert.get(k, ""))
        if v:
            alert[k] = "********" + v[-4:]
            alert[k + "_set"] = True
        else:
            alert[k + "_set"] = False
    return {
        "weights": db.get_setting("weights", db.DEFAULT_WEIGHTS),
        "thresholds": db.get_setting("thresholds", db.DEFAULT_THRESHOLDS),
        "policy": db.get_setting("policy", db.DEFAULT_POLICY),
        "alert": alert,
        "ingest_key": db.get_setting("ingest_key", ""),
        "channels": alerts.CHANNEL_LABELS,
        "level_rank": db.LEVEL_RANK,
    }


def update_config(payload: Dict[str, Any], actor: str) -> Dict[str, Any]:
    """热更新配置。掩码字段未变更时保留原值，避免被前端回写覆盖成星号。"""
    if "weights" in payload:
        db.set_setting("weights", _validate_weights(payload["weights"]), actor)
    if "thresholds" in payload:
        db.set_setting("thresholds", _validate_thresholds(payload["thresholds"]), actor)
    if "policy" in payload:
        p = dict(db.get_setting("policy", db.DEFAULT_POLICY))
        for k in ("auto_case", "case_min_level", "alert_min_level", "retention_days"):
            if k in payload["policy"]:
                p[k] = payload["policy"][k]
        if p.get("alert_min_level") not in db.LEVEL_RANK:
            raise ValueError("告警等级不合法")
        if p.get("case_min_level") not in db.LEVEL_RANK:
            raise ValueError("建案等级不合法")
        db.set_setting("policy", p, actor)
    if "alert" in payload:
        cur = dict(db.get_setting("alert", db.DEFAULT_ALERT))
        for k, v in payload["alert"].items():
            if k.endswith("_set") or k not in cur:
                continue
            if isinstance(v, str) and v.startswith("********"):
                continue                      # 前端回传的掩码，保留原值
            cur[k] = v
        cur["channel"] = str(cur.get("channel", "wecom"))
        cur["enabled"] = bool(cur.get("enabled", False))
        db.set_setting("alert", cur, actor)
    refresh_engine()
    return get_config()


def rotate_ingest_key(actor: str) -> str:
    import secrets
    key = secrets.token_urlsafe(32)
    db.set_setting("ingest_key", key, actor)
    return key


def test_alert(actor: str) -> Dict[str, Any]:
    cfg = db.get_setting("alert", db.DEFAULT_ALERT)
    ch = cfg.get("channel", "wecom")
    ok, detail = alerts.send(cfg, "RiskGuard 测试告警",
                             "这是一条来自风控控制台的连通性测试消息。\n"
                             "收到即表示告警通道配置正确。", ch)
    db.insert_alert(None, ch, ok, "[测试] " + detail)
    db.add_audit(actor, "alert.test", f"{ch} 测试发送：{'成功' if ok else '失败'}")
    return {"ok": ok, "detail": detail, "channel": ch}


# ------------------------------------------------------------------ 演示数据
def _borderline_window(seed: int, rng: random.Random) -> BehaviorWindow:
    """
    「灰区」样本：只有部分信号异常（半数量化时长、半数合成手势、两项指纹冲突、
    日活偏高）。用来演示中风险分级挑战，避免看板上只有 LOW / CRITICAL 两级。
    """
    from riskguard.synthetic import _bezier_bot_swipe, _human_window

    w = _human_window(seed)
    # 每个窗口的合成手势占比不同，形成从 ELEVATED 到 HIGH 的连续分布
    inject_ratio = rng.uniform(0.55, 0.85)
    for i, s in enumerate(w.swipes):
        if rng.random() < inject_ratio:
            w.swipes[i] = _bezier_bot_swipe(1000.0 * i)
    ts = w.watches[0].ts
    for i, rec in enumerate(w.watches):
        if i % 2 == 0:
            rec.duration_s = round(rec.duration_s, 1)
        rec.ts = ts
        ts += rec.duration_s + 0.45          # 去掉空闲停顿
    fp = w.fingerprints[0]
    fp.timezone = "America/New_York"
    fp.languages = ["en-US"]
    w.daily_active_s = 14.0 * 3600
    w.hour_of_day = 13
    w.swipe_history = []
    return w


def seed_demo(actor: str = "system", count: int = 72) -> Dict[str, Any]:
    """
    清空业务数据并灌入近 24 小时的演示事件。
    只用于首次启动让控制台有内容可看，可在「规则配置」页一键清除。
    """
    from riskguard.synthetic import (_bezier_bot_window, _fixed_bot_window,
                                     _human_window)

    db.purge_all_events()
    db.DbStateStore().clear()
    reset_engine()

    rng = random.Random(2026)
    now = time.time()
    made = 0
    for i in range(count):
        roll = rng.random()
        kind = ("human" if roll < 0.55 else
                "borderline" if roll < 0.72 else
                "bezier_bot" if roll < 0.90 else "fixed_bot")
        seed = 1000 + i * 7
        if kind == "human":
            w = _human_window(seed)
            hour = rng.choice([8, 9, 10, 12, 13, 15, 18, 19, 20, 21, 22])
            w.daily_active_s = rng.uniform(1.2, 5.5) * 3600
            prefix = "u_real_"
        elif kind == "borderline":
            w = _borderline_window(seed, rng)
            hour = rng.choice([10, 11, 13, 16, 20])
            prefix = "u_gray_"
        elif kind == "bezier_bot":
            w = _bezier_bot_window(seed)
            hour = rng.choice([1, 2, 3, 4, 11, 14, 23])
            w.daily_active_s = rng.uniform(16, 21) * 3600
            prefix = "u_bot_b_"
        else:
            w = _fixed_bot_window(seed)
            hour = rng.choice([0, 2, 3, 5, 23])
            w.daily_active_s = rng.uniform(20, 23.5) * 3600
            prefix = "u_bot_f_"
        idx = i // 3
        w.account_id = f"{prefix}{idx:02d}"
        w.window_id = f"w_seed_{i:04d}"
        w.hour_of_day = hour
        # 在近 24 小时内随机分布；白天样本更多
        age = rng.uniform(0, 24 * 3600)
        ingest(w, source="seed", received_at=now - age, skip_alert=True)
        made += 1

    # 造几条告警记录（明确标注为演示，未真实发送），让告警页有内容
    for i in range(5):
        db.insert_alert(None, "wecom", True,
                        f"[演示] 第 {i+1} 条告警记录，未真实发送；配置渠道后可测试连通性")

    db.add_audit(actor, "demo.seed", f"已生成 {made} 条演示窗口事件")
    return {"seeded": made}


def clear_demo(actor: str) -> Dict[str, Any]:
    db.purge_all_events()
    db.DbStateStore().clear()
    reset_engine()
    db.add_audit(actor, "demo.clear", "已清空全部事件/案件/告警与迟滞状态")
    return {"cleared": True}


def start_retention_worker() -> None:
    """后台按 retention_days 清理过期数据；启动时立即跑一次，之后每小时一次。"""
    def _loop() -> None:
        while True:
            try:
                days = int(db.get_setting("policy", db.DEFAULT_POLICY)
                           .get("retention_days", 30))
                db.purge_older_than(days)
            except Exception:
                pass                       # 清理失败不影响主服务
            threading.Event().wait(3600)
    threading.Thread(target=_loop, daemon=True, name="rg-retention").start()
