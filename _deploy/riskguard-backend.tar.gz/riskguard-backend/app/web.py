# -*- coding: utf-8 -*-
"""
HTTP 路由与 API。

对外分两类调用方：
  1) 客户端 SDK：POST /api/v1/ingest，用 X-API-Key 鉴权，
     **只返回 public_response**（字段集合恒定，不含分数/等级/判定依据）。
  2) 风控管理员：Cookie 会话鉴权，可读取全量明细、复核案件、热更新规则。

这两条路径刻意隔离：即使 SDK 拿到自己的 API Key，也无法查询任何其它账号的判定结果。
"""
from __future__ import annotations

import csv
import hmac
import io
import json
import os
import sys
import threading
import time
from collections import defaultdict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict
from urllib.parse import parse_qs, unquote, urlsplit

from riskguard.engine import RiskEngine
from riskguard.models import BehaviorWindow
from riskguard.synthetic import LABELS, build_scenarios

from . import alerts, auth, db, service

STATIC_DIR = Path(__file__).resolve().parent / "static"
MAX_BODY = 16 * 1024 * 1024
MIME = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".svg": "image/svg+xml", ".ico": "image/x-icon"}

_RATE: Dict[str, deque] = defaultdict(deque)
_RATE_LOCK = threading.Lock()
RATE_LIMIT = 300          # 每个来源 IP 每分钟最多 300 次接入请求

# ---- 部署参数（全部由环境变量控制，默认值仍为安全的本地开发模式） ----------
ENV = os.environ.get("RISKGUARD_ENV", "dev").strip().lower()
IS_PROD = ENV in ("prod", "production")
BIND_HOST = os.environ.get("RISKGUARD_BIND", "127.0.0.1")
BIND_PORT = int(os.environ.get("RISKGUARD_PORT", "8791"))
# 静态前端放在别的源（如 GitHub Pages）时，必须显式列出该源；不使用通配符，
# 因为管理接口依赖 Cookie，通配符与 Allow-Credentials 不兼容且不安全。
CORS_ORIGINS = tuple(x.strip().rstrip("/") for x in
                     os.environ.get("RISKGUARD_CORS_ORIGINS", "").split(",") if x.strip())
FRAME_ANCESTORS = os.environ.get("RISKGUARD_FRAME_ANCESTORS", "").strip()


def _rate_ok(ip: str) -> bool:
    now = time.time()
    with _RATE_LOCK:
        dq = _RATE[ip]
        while dq and dq[0] < now - 60:
            dq.popleft()
        if len(dq) >= RATE_LIMIT:
            return False
        dq.append(now)
        return True


def sample_payload() -> Dict[str, Any]:
    """在线调试面板的精简示例窗口。"""
    swipes = []
    for k in range(2):
        pts = [{"x": 360 + 6 * (i / 11), "y": 640 - 450 * (i / 11),
                "t": 1000 * k + i * 16.0, "pressure": 1.0, "area": 0.0,
                "pointer_id": 1} for i in range(12)]
        swipes.append({"session_id": f"s{k}", "points": pts})
    watches = [{"duration_s": 12.0, "content_id": f"v{i}", "liked": False,
                "followed": False, "commented": False, "is_live": False,
                "ts": 1700000000.0 + i * 12.44} for i in range(6)]
    fp = {
        "device_id": "dev-demo-01", "account_id": "u_demo",
        "ua": "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
        "platform": "Windows", "screen_w": 1080, "screen_h": 2400, "dpr": 3.0,
        "webgl_vendor": "Google Inc.",
        "webgl_renderer": "ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11)",
        "timezone": "America/New_York", "languages": ["en-US"],
        "hardware_concurrency": 6, "device_memory": 3.0,
        "webdriver": True, "plugins_count": 0, "has_chrome_object": False,
        "touch_max_points": 1, "accelerometer": False, "ip_region": "CN",
    }
    return {
        "window_id": "w-demo", "account_id": "u_demo", "device_id": "dev-demo-01",
        "swipes": swipes, "watches": watches, "fingerprints": [fp],
        "swipe_history": [], "fp_account_map": {"dev-demo-01": ["u_demo"]},
        "account_fp_history": {"u_demo": ["dev-demo-01"]},
        "daily_active_s": 18.0 * 3600, "hour_of_day": 3,
    }


def _csv(rows, columns) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(columns)
    for r in rows:
        writer.writerow([r.get(c, "") for c in columns])
    return "\ufeff" + buf.getvalue()


def _demo_payload() -> Dict[str, Any]:
    eng = RiskEngine()                     # 独立内存引擎，不污染线上迟滞状态
    return {"scenarios": {k: {"label": LABELS[k], "report": eng.evaluate(w).to_dict()}
                          for k, w in build_scenarios().items()}}


class Handler(BaseHTTPRequestHandler):
    server_version = "RiskGuardConsole/2.0"
    protocol_version = "HTTP/1.1"

    # ------------------------------------------------------------ 底层响应
    def log_message(self, fmt: str, *args) -> None:
        msg = str(args[0]) if args else ""
        if msg.startswith("GET /static/") or msg.startswith("GET /api/health"):
            return
        sys.stderr.write("  %s\n" % (fmt % args))

    def _common_headers(self) -> Dict[str, str]:
        """统一附加 CORS 与安全响应头。"""
        h: Dict[str, str] = {
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
            "Content-Security-Policy": (
                "default-src 'self'; script-src 'self'; "
                "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                "connect-src 'self'; frame-ancestors "
                + (FRAME_ANCESTORS or "'self'")),
        }
        # CSP frame-ancestors 与 X-Frame-Options 不能同时表达第三方来源，
        # 允许指定父页面时交给 CSP 处理。
        if not FRAME_ANCESTORS or FRAME_ANCESTORS.strip() == "'self'":
            h["X-Frame-Options"] = "SAMEORIGIN"
        if IS_PROD and self.headers.get("X-Forwarded-Proto", "").lower() == "https":
            h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        origin = (self.headers.get("Origin", "") or "").rstrip("/")
        if origin and origin in CORS_ORIGINS:
            h["Access-Control-Allow-Origin"] = origin
            h["Access-Control-Allow-Credentials"] = "true"
            h["Vary"] = "Origin"
        return h

    def _bytes(self, raw: bytes, ctype: str, status: int = 200,
               extra: Dict[str, str] | None = None) -> None:
        headers = self._common_headers()
        headers.update(extra or {})
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        for k, v in headers.items():
            self.send_header(k, v)
        self.end_headers()
        if status != 204:
            try:
                self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def do_OPTIONS(self) -> None:
        """CORS 预检：只允许已配置来源，且不允许任意 Origin 通配。"""
        origin = (self.headers.get("Origin", "") or "").rstrip("/")
        extra = {}
        if origin and origin in CORS_ORIGINS:
            extra = {
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, X-API-Key, Authorization",
                "Access-Control-Max-Age": "600",
            }
        self._bytes(b"", "text/plain; charset=utf-8", 204, extra)

    def _json(self, obj: Any, status: int = 200,
              extra: Dict[str, str] | None = None) -> None:
        self._bytes(json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"),
                    "application/json; charset=utf-8", status, extra)

    def _file(self, name: str) -> None:
        target = (STATIC_DIR / name).resolve()
        if not str(target).startswith(str(STATIC_DIR.resolve())) or not target.is_file():
            self._json({"error": "not found"}, 404)
            return
        self._bytes(target.read_bytes(), MIME.get(target.suffix, "application/octet-stream"))

    def _read_raw(self) -> bytes:
        """进入路由前一次性读完请求体，避免 401/429 等早退分支留下未消费字节
        污染 HTTP/1.1 长连接上的下一个请求。"""
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            n = 0
        if n <= 0:
            return b""
        if n > MAX_BODY:
            raise ValueError("invalid body size")
        return self.rfile.read(n)

    def _body(self) -> Any:
        raw = getattr(self, "_raw", None)
        if raw is None:
            raw = self._read_raw()
        if not raw:
            raise ValueError("invalid body size")
        return json.loads(raw.decode("utf-8"))

    def _maybe_body(self) -> Any:
        """部分管理接口（重置演示数据等）允许无请求体。"""
        raw = getattr(self, "_raw", None)
        if raw is None:
            raw = self._read_raw()
        return json.loads(raw.decode("utf-8")) if raw else {}

    # ------------------------------------------------------------- 鉴权辅助
    def _actor(self):
        return auth.current_user(self.headers.get("Cookie", ""))

    def _require(self):
        u = self._actor()
        if not u:
            self._json({"error": "unauthorized"}, 401)
            return None
        return u

    def _api_key_ok(self) -> bool:
        supplied = (self.headers.get("X-API-Key", "")
                    or self.headers.get("Authorization", "").removeprefix("Bearer ").strip())
        expected = str(db.get_setting("ingest_key", ""))
        return bool(supplied) and bool(expected) and hmac.compare_digest(supplied, expected)

    # ------------------------------------------------------------------ GET
    def do_GET(self) -> None:
        u = urlsplit(self.path)
        path, q = u.path, parse_qs(u.query)
        try:
            if path in ("/", "/index.html"):
                return self._file("index.html")
            if path.startswith("/static/"):
                return self._file(unquote(path[len("/static/"):]))
            if path == "/api/health":
                return self._json({"ok": True, "version": "2.0.0", "ts": time.time()})
            actor = self._require()
            if not actor:
                return
            self._get_auth(path, q, actor)
        except Exception as exc:
            self._json({"error": "internal error", "detail": str(exc)}, 500)

    def _get_auth(self, path: str, q, actor: str) -> None:
        one = lambda k, d="": (q.get(k, [d])[0])
        if path == "/api/auth/me":
            return self._json({"username": actor, "role": "admin"})
        if path == "/api/overview":
            return self._json(service.overview(int(one("hours", "24") or 24)))
        if path == "/api/windows":
            rows = db.list_windows(level=one("level"), action=one("action"),
                                   account=one("account"),
                                   limit=min(int(one("limit", "50")), 200),
                                   offset=int(one("offset", "0")),
                                   since=time.time() - int(one("hours", "24")) * 3600)
            return self._json({"rows": [{k: r[k] for k in
                                        ("id", "window_id", "account_id", "device_id",
                                         "received_at", "score", "level", "action", "source")}
                                       for r in rows]})
        if path.startswith("/api/windows/"):
            d = service.window_detail(int(path.rsplit("/", 1)[1]))
            return self._json(d if d else {"error": "not found"}, 200 if d else 404)
        if path == "/api/cases":
            return self._json({"rows": db.list_cases(status=one("status"),
                                                     limit=min(int(one("limit", "100")), 300))})
        if path == "/api/config":
            return self._json(service.get_config())
        if path == "/api/alerts":
            return self._json({"rows": db.list_alerts(40)})
        if path == "/api/audit":
            return self._json({"rows": db.list_audit(60)})
        if path == "/api/demo":
            return self._json(_demo_payload())
        if path == "/api/sample":
            return self._json(sample_payload())
        if path == "/api/export":
            kind = one("kind", "windows")
            if kind == "cases":
                rows = db.list_cases(limit=10000)
                cols = ["id", "account_id", "status", "score", "action", "note", "created_at"]
            else:
                rows = db.list_windows(limit=10000, since=0)
                cols = ["id", "window_id", "account_id", "device_id",
                        "received_at", "score", "level", "action", "source"]
            raw = _csv(rows, cols).encode("utf-8")
            return self._bytes(raw, "text/csv; charset=utf-8", 200,
                               {"Content-Disposition": f'attachment; filename="riskguard_{kind}.csv"'})
        self._json({"error": "not found"}, 404)

    # ----------------------------------------------------------------- POST
    def do_POST(self) -> None:
        path = urlsplit(self.path).path
        try:
            self._raw = self._read_raw()      # 无论走哪个分支都先排空请求体
            # --- 公开：登录 ---
            if path == "/api/auth/login":
                body = self._body()
                token = auth.login(str(body.get("username", "")), str(body.get("password", "")))
                if not token:
                    return self._json({"error": "用户名或密码错误"}, 401)
                db.add_audit(str(body.get("username", "")), "auth.login", "登录成功")
                return self._json({"ok": True, "username": body.get("username")},
                                  200, {"Set-Cookie": auth.set_cookie(token)})
            # --- 公开：登出 ---
            if path == "/api/auth/logout":
                self._maybe_body()            # 排空请求体，避免 HTTP/1.1 连接复用时残留字节
                auth.logout(self.headers.get("Cookie", ""))
                return self._json({"ok": True}, 200, {"Set-Cookie": auth.clear_cookie()})
            # --- 公开：SDK 接入（API Key 鉴权） ---
            if path == "/api/v1/ingest":
                return self._ingest()
            # --- 以下均需管理员会话 ---
            actor = self._require()
            if not actor:
                return
            self._post_auth(path, actor)
        except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
            self._json({"error": "bad request", "detail": str(exc)}, 400)
        except Exception as exc:
            self._json({"error": "internal error", "detail": str(exc)}, 500)

    def _client_ip(self) -> str:
        """反代部署时 client_address 恒为 127.0.0.1，需从可信代理的 XFF 取真实来源。"""
        trust = (IS_PROD or os.environ.get("RISKGUARD_TRUST_PROXY", "")
                 in ("1", "true", "True"))
        if trust:
            xff = self.headers.get("X-Forwarded-For", "")
            if xff:
                return xff.split(",")[0].strip()
        return self.client_address[0] if self.client_address else "?"

    def _ingest(self) -> None:
        ip = self._client_ip()
        if not _rate_ok(ip):
            return self._json({"error": "rate limited"}, 429)
        if not self._api_key_ok():
            return self._json({"error": "unauthorized"}, 401)
        body = self._body()
        items = body.get("batch") if isinstance(body, dict) and "batch" in body else [body]
        if not isinstance(items, list) or not items or len(items) > 50:
            return self._json({"error": "bad request"}, 400)
        results = []
        for item in items:
            w = BehaviorWindow.from_dict(item)
            results.append(service.ingest_public(service.ingest(w, source="sdk")))
        # 统一外形：无论命中哪条规则，SDK 看到的字段集合完全一样
        return self._json({"status": "ok", "accepted": len(results), "results": results})

    def _post_auth(self, path: str, actor: str) -> None:
        body = self._maybe_body()
        if path == "/api/auth/password":
            pwd = str(body.get("new_password", ""))
            if len(pwd) < 10:
                return self._json({"error": "新密码至少 10 位"}, 400)
            db.change_password(actor, pwd, actor)
            return self._json({"ok": True, "message": "密码已更新，请重新登录"},
                              200, {"Set-Cookie": auth.clear_cookie()})
        if path == "/api/evaluate":
            return self._json(service.debug_evaluate(BehaviorWindow.from_dict(body)))
        if path == "/api/config":
            return self._json(service.update_config(body, actor))
        if path == "/api/config/rotate-key":
            return self._json({"ok": True, "ingest_key": service.rotate_ingest_key(actor)})
        if path == "/api/config/test-alert":
            return self._json(service.test_alert(actor))
        if path.startswith("/api/cases/"):
            cid = int(path.rsplit("/", 1)[1])
            status = str(body.get("status", "")).upper()
            if status not in ("OPEN", "CONFIRMED", "DISMISSED", "ESCALATED"):
                return self._json({"error": "非法状态"}, 400)
            ok = db.update_case(cid, status, str(body.get("note", "")), actor)
            return self._json({"ok": ok} if ok else {"error": "not found"}, 200 if ok else 404)
        if path == "/api/demo/seed":
            return self._json(service.seed_demo(actor, int(body.get("count", 72))))
        if path == "/api/demo/clear":
            return self._json(service.clear_demo(actor))
        self._json({"error": "not found"}, 404)


def main(port: int | None = None, host: str | None = None) -> None:
    # 平台托管注入 PORT 时自动切换为对外绑定；本地开发仍只监听回环地址。
    env_port = os.environ.get("PORT", "").strip()
    port = port if port is not None else (int(env_port) if env_port.isdigit() else BIND_PORT)
    host = (host or os.environ.get("RISKGUARD_BIND")
            or ("0.0.0.0" if env_port else BIND_HOST))

    # 生产模式硬门槛：禁止默认口令、禁止自动灌演示数据、Cookie 强制 Secure。
    if IS_PROD:
        admin_pwd = os.environ.get("RISKGUARD_ADMIN_PASSWORD", "")
        first_run = not db.DB_PATH.exists()
        if first_run and len(admin_pwd) < 12:
            print("[拒绝启动] 生产模式首次运行必须通过 RISKGUARD_ADMIN_PASSWORD "
                  "设置不少于 12 位的初始管理员密码。")
            sys.exit(2)
        if not os.environ.get("RISKGUARD_COOKIE_SECURE"):
            os.environ["RISKGUARD_COOKIE_SECURE"] = "1"
        if host not in ("127.0.0.1", "localhost", "::1"):
            print("[警告] 生产模式请保持绑定回环地址，由 nginx 反向代理对外暴露；"
                  "当前绑定 %s" % host)

    initial = db.init_db()
    service.start_retention_worker()
    srv = ThreadingHTTPServer((host, port), Handler)
    srv.daemon_threads = True
    print("=" * 66)
    print("  RiskGuard 风控控制台  http://%s:%d" % (host, port))
    print("  运行模式  %s   数据目录  %s" % ("PROD" if IS_PROD else "DEV", db.DATA_DIR))
    if CORS_ORIGINS:
        print("  CORS 允许来源  %s" % ", ".join(CORS_ORIGINS))
    if initial:
        print("  初始管理员  admin / %s   （登录后请立即修改密码）" % initial)
        print("  凭据文件    %s  （改密后请删除）" % (db.DATA_DIR / "INITIAL_ADMIN.txt"))
    # 生产环境绝不自动灌入演示数据：那会把假案件混进真实风控队列
    seed = os.environ.get("RISKGUARD_SEED_DEMO", "")
    auto_seed = (seed == "1") or (not IS_PROD and seed != "0" and db.count_windows(0) == 0)
    if auto_seed:
        print("  正在生成演示数据…", service.seed_demo("system", 72))
    print("=" * 66)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 8791)
