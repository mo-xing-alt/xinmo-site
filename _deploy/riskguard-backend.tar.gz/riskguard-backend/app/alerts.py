# -*- coding: utf-8 -*-
"""
告警推送（防御侧的"人工介入"通道）。

命中高风险时把案件推给管理员，由人来决定后续处置；系统不自动封号、不自动申诉。
支持：企业微信机器人 / Bark / Server 酱 / SMTP 邮件。全部走标准库，超时 6 秒，
在任何渠道故障下都只记录失败、不影响主判定链路。
"""
from __future__ import annotations

import json
import smtplib
import ssl
import urllib.parse
import urllib.request
from email.message import EmailMessage
from typing import Tuple

TIMEOUT = 6


def _post_json(url: str, payload: dict) -> str:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read().decode("utf-8", "replace")[:300]


def _post_form(url: str, fields: dict) -> str:
    data = urllib.parse.urlencode(fields).encode("utf-8")
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return resp.read().decode("utf-8", "replace")[:300]


def send(cfg: dict, title: str, body: str, channel: str = "") -> Tuple[bool, str]:
    """返回 (是否成功, 渠道回执/错误摘要)。"""
    ch = channel or cfg.get("channel", "wecom")
    try:
        if ch == "wecom":
            url = cfg.get("wecom_webhook", "").strip()
            if not url:
                return False, "未配置企业微信 Webhook"
            raw = _post_json(url, {"msgtype": "markdown",
                                   "markdown": {"content": f"### {title}\n\n{body}"}})
            res = json.loads(raw)
            return (res.get("errcode") == 0, raw)

        if ch == "bark":
            base = cfg.get("bark_url", "").strip().rstrip("/")
            if not base:
                return False, "未配置 Bark 地址"
            url = f"{base}/{urllib.parse.quote(title)}/{urllib.parse.quote(body)}"
            with urllib.request.urlopen(url, timeout=TIMEOUT) as resp:
                return True, resp.read().decode("utf-8", "replace")[:300]

        if ch == "serverchan":
            key = cfg.get("serverchan_key", "").strip()
            if not key:
                return False, "未配置 Server 酱 SendKey"
            raw = _post_form(f"https://sctapi.ftqq.com/{key}.send",
                             {"title": title, "desp": body.replace("\n", "\n\n")})
            return True, raw

        if ch == "smtp":
            host = cfg.get("smtp_host", "").strip()
            to = cfg.get("smtp_to", "").strip()
            if not host or not to:
                return False, "未配置 SMTP 主机或收件人"
            msg = EmailMessage()
            msg["Subject"] = title
            msg["From"] = cfg.get("smtp_user", "") or "riskguard@localhost"
            msg["To"] = to
            msg.set_content(body)
            port = int(cfg.get("smtp_port", 465))
            ctx = ssl.create_default_context()
            with smtplib.SMTP_SSL(host, port, context=ctx, timeout=TIMEOUT) as s:
                user, pwd = cfg.get("smtp_user", ""), cfg.get("smtp_pass", "")
                if user and pwd:
                    s.login(user, pwd)
                s.send_message(msg)
            return True, "SMTP 已投递"

        return False, f"未知渠道：{ch}"
    except Exception as exc:                     # 告警失败不能拖垮判定链路
        return False, f"{type(exc).__name__}: {exc}"[:300]


CHANNEL_LABELS = {
    "wecom": "企业微信机器人",
    "bark": "Bark",
    "serverchan": "Server 酱",
    "smtp": "SMTP 邮件",
}
