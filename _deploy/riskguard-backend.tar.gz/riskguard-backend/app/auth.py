# -*- coding: utf-8 -*-
"""轻量会话鉴权：PBKDF2 口令 + 随机 token（数据库只存 token 哈希）+ HttpOnly Cookie。"""
from __future__ import annotations

from http.cookies import SimpleCookie
from typing import Optional

from . import db

COOKIE = "rg_session"
SESSION_TTL = 8 * 3600


def cookie_token(cookie_header: str) -> str:
    try:
        jar = SimpleCookie()
        jar.load(cookie_header or "")
        m = jar.get(COOKIE)
        return m.value if m else ""
    except Exception:
        return ""


def current_user(cookie_header: str) -> Optional[str]:
    return db.session_user(cookie_token(cookie_header))


def login(username: str, password: str) -> Optional[str]:
    u = db.get_user(username)
    if not u or not db.verify_password(password, u["salt"], u["pwd_hash"]):
        return None
    return db.create_session(username, SESSION_TTL)


def logout(cookie_header: str) -> None:
    t = cookie_token(cookie_header)
    if t:
        db.drop_session(t)


def cookie_attrs() -> str:
    """
    由环境变量控制，适配反向代理 / 跨子域部署：
      RISKGUARD_COOKIE_SAMESITE  Strict(默认) | Lax | None
      RISKGUARD_COOKIE_SECURE    1 强制 Secure（HTTPS 反代下必须）
    SameSite=None 时浏览器强制要求 Secure，这里自动补上。
    """
    import os
    same = os.environ.get("RISKGUARD_COOKIE_SAMESITE", "Strict").strip() or "Strict"
    secure = os.environ.get("RISKGUARD_COOKIE_SECURE", "").strip() in ("1", "true", "True")
    if same.lower() == "none":
        secure = True
    bits = ["HttpOnly", f"SameSite={same}", "Path=/"]
    if secure:
        bits.append("Secure")
    return "; ".join(bits)


def set_cookie(token: str) -> str:
    return f"{COOKIE}={token}; {cookie_attrs()}; Max-Age={SESSION_TTL}"


def clear_cookie() -> str:
    return f"{COOKIE}=; {cookie_attrs()}; Max-Age=0"
