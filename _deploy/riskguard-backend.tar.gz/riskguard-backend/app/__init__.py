# -*- coding: utf-8 -*-
"""RiskGuard Console —— 防御侧风控后台（纯标准库实现）。"""
__version__ = "2.0.0"
